/*
 * Copyright (c) 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
 
package com.ge.aircraft.entity;

/**
 * 
 * @author predix -
 */
import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the FLIGHT_MASTER database table.
 * 
 */
@Entity
@Table(name="FLIGHT_MASTER")
@NamedQuery(name="FlightMaster.findAll", query="SELECT f FROM FlightMaster f")
public class FlightMaster implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="FLIGHT_MASTER_FLIGHTID_GENERATOR", sequenceName="FLEET_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="FLIGHT_MASTER_FLIGHTID_GENERATOR")
	@Column(name="FLIGHT_ID")
	private long flightId;

	@Column(name="START_DATE")
	private String startDate;

	@Column(name="START_TIME")
	private String startTime;

	//bi-directional many-to-one association to FleetData
	@OneToMany(mappedBy="flightMaster")
	private List<FleetData> fleetData;

	public FlightMaster() {
	}

	public long getFlightId() {
		return this.flightId;
	}

	public void setFlightId(long flightId) {
		this.flightId = flightId;
	}

	public String getStartDate() {
		return this.startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getStartTime() {
		return this.startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public List<FleetData> getFleetData() {
		return this.fleetData;
	}

	public void setFleetData(List<FleetData> fleetData) {
		this.fleetData = fleetData;
	}

	public FleetData addFleetData(FleetData fleetData) {
		getFleetData().add(fleetData);
		fleetData.setFlightMaster(this);

		return fleetData;
	}

	public FleetData removeFleetData(FleetData fleetData) {
		getFleetData().remove(fleetData);
		fleetData.setFlightMaster(null);

		return fleetData;
	}

}
