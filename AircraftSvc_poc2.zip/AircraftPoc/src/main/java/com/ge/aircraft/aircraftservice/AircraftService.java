package com.ge.aircraft.aircraftservice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.aircraft.dto.AircraftDTO;
import com.ge.aircraft.dto.FleetDataDTO;
import com.ge.aircraft.dto.FlightMasterDTO;
import com.ge.aircraft.entity.AircraftData;
import com.ge.aircraft.entity.FleetData;
import com.ge.aircraft.entity.FlightMaster;
import com.ge.aircraft.repository.IAircraftRepository;
import com.ge.aircraft.repository.IFlightFleetRepository;
import com.ge.aircraft.repository.IFlightMasterRepository;

@RestController
public class AircraftService {

	@Autowired
	private IAircraftRepository aircraftRepository;

	@Autowired
	private IFlightMasterRepository flightMasterRepo;

	@Autowired
	private IFlightFleetRepository filghtFleetrepo;

	@RequestMapping(value = "/getaircraftDetails", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<AircraftDTO> getaircraftDetails() {
		
		List<AircraftDTO> aircraftLists = new ArrayList<AircraftDTO>();
		AircraftDTO aircraftVo = null;
		try {
			List<AircraftData> dataList = (List<AircraftData>) aircraftRepository.findAll();
			for (AircraftData aircraftList : dataList) {
				aircraftVo = new AircraftDTO();
				BeanUtils.copyProperties(aircraftList, aircraftVo);
				System.out.println("WithOutfilterEntity Result" + aircraftList);
				System.out.println("WithOutAfterCopy Result" + aircraftVo);
				aircraftLists.add(aircraftVo);
			}
		}
		catch (Exception e) {
			System.out.println("HospitalAlarmService.getsupplierconnectWithFilter()"+ e);
		}
		return aircraftLists;
	}

	@RequestMapping(value = "/getFlightTimeStampDetails/{startdate}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FlightMasterDTO> getFlightTimeStampDetails(
			@PathVariable("startdate") String startdate) {
		
		List<FlightMasterDTO> aircraftLists = new ArrayList<FlightMasterDTO>();
		FlightMasterDTO flightTimeStamp = null;
		try {
			System.out.println("AircraftService.getFlightTimeStampDetails()");

			List<FlightMaster> dataList = (List<FlightMaster>) flightMasterRepo.findByStartDate(startdate);
			for (FlightMaster flightMstr : dataList) {
				flightTimeStamp = new FlightMasterDTO();
				BeanUtils.copyProperties(flightMstr, flightTimeStamp);
				aircraftLists.add(flightTimeStamp);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return aircraftLists;
	}

	@RequestMapping(value = "/view/getFlightDetailsWithoutparameter", method = RequestMethod.GET, produces = "application/json")
	List<Map<String, Object>> getFlightDetailsWithoutparameter() {
		List<FlightMasterDTO> aircraftLists = new ArrayList<FlightMasterDTO>();
		FlightMasterDTO flightTimeStamp = null;
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			List<Object[]> retList = filghtFleetrepo.getFlightDetailss();

			for (int i = 0; i < retList.size(); i++) {
				objMap = new HashMap<String, Object>();
				objMap.put("fleetId", (retList.get(i))[0]);
				objMap.put("airspeed", (retList.get(i))[1]);
				objMap.put("armRetardantTankDoor", (retList.get(i))[2]);
				objMap.put("beaconStartStopRecording", (retList.get(i))[3]);
				objMap.put("elapsedTime", (retList.get(i))[4]);
				objMap.put("elevatorPosition", (retList.get(i))[5]);
				objMap.put("flapPosition", (retList.get(i))[6]);
				objMap.put("gearUpAndLocked", (retList.get(i))[7]);
				objMap.put("leftAileronPosition", (retList.get(i))[8]);
				objMap.put("peakValleyIndicator", (retList.get(i))[9]);
				objMap.put("pressureAltitude", (retList.get(i))[10]);
				objMap.put("recordType", (retList.get(i))[11]);
				objMap.put("retardantDoorOpen", (retList.get(i))[12]);
				objMap.put("retardantTankFloat", (retList.get(i))[13]);
				objMap.put("rollAcceleration", (retList.get(i))[14]);
				objMap.put("strainGauge1", (retList.get(i))[15]);
				objMap.put("strainGauge2", (retList.get(i))[16]);
				objMap.put("strainGauge3", (retList.get(i))[17]);
				objMap.put("strainGauge4", (retList.get(i))[18]);
				objMap.put("strainGauge5", (retList.get(i))[19]);
				objMap.put("strainGauge6", (retList.get(i))[20]);
				objMap.put("strainGauge7", (retList.get(i))[21]);
				objMap.put("strainGauge8", (retList.get(i))[22]);
				objMap.put("timestamp", (retList.get(i))[23]);
				objMap.put("triggerChannel", (retList.get(i))[24]);
				objMap.put("verticalAcceleration", (retList.get(i))[25]);
				objMap.put("startDate", (retList.get(i))[26]);
				objMap.put("startTime", (retList.get(i))[27]);
				objMap.put("flightId", (retList.get(i))[28]);

				list.add(objMap);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	@RequestMapping(value = "/view/getFlightDetails/{flightDate}/{flightTime}/{recordType}/{triggerChannel}/{startTime}/{endTime}", 
			method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getFlightDetails(
			@PathVariable("flightDate") String flightDate,
			@PathVariable("flightTime") String flightTime,
			@PathVariable("recordType") String recordType,
			@PathVariable("triggerChannel") String triggerChannel,
			@PathVariable("startTime") String startTime,
			@PathVariable("endTime") String endTime) {
		
		List<FlightMasterDTO> aircraftLists = new ArrayList<FlightMasterDTO>();
		FlightMasterDTO flightTimeStamp = null;
		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		try {
			String filterQueryMnfctr = "";
			List<Object[]> retList = filghtFleetrepo.getFlightDetails(flightDate, flightTime, 
					recordType, triggerChannel, startTime, endTime);

			for (int i = 0; i < retList.size(); i++) {

				objMap = new HashMap<String, Object>();
				objMap.put("fleetId", (retList.get(i))[0]);
				objMap.put("airspeed", (retList.get(i))[1]);
				objMap.put("armRetardantTankDoor", (retList.get(i))[2]);
				objMap.put("beaconStartStopRecording", (retList.get(i))[3]);
				objMap.put("elapsedTime", (retList.get(i))[4]);
				objMap.put("elevatorPosition", (retList.get(i))[5]);
				objMap.put("flapPosition", (retList.get(i))[6]);
				objMap.put("gearUpAndLocked", (retList.get(i))[7]);
				objMap.put("leftAileronPosition", (retList.get(i))[8]);
				objMap.put("peakValleyIndicator", (retList.get(i))[9]);
				objMap.put("pressureAltitude", (retList.get(i))[10]);
				objMap.put("recordType", (retList.get(i))[11]);
				objMap.put("retardantDoorOpen", (retList.get(i))[12]);
				objMap.put("retardantTankFloat", (retList.get(i))[13]);
				objMap.put("rollAcceleration", (retList.get(i))[14]);
				objMap.put("strainGauge1", (retList.get(i))[15]);
				objMap.put("strainGauge2", (retList.get(i))[16]);
				objMap.put("strainGauge3", (retList.get(i))[17]);
				objMap.put("strainGauge4", (retList.get(i))[18]);
				objMap.put("strainGauge5", (retList.get(i))[19]);
				objMap.put("strainGauge6", (retList.get(i))[20]);
				objMap.put("strainGauge7", (retList.get(i))[21]);
				objMap.put("strainGauge8", (retList.get(i))[22]);
				objMap.put("timestamp", (retList.get(i))[23]);
				objMap.put("triggerChannel", (retList.get(i))[24]);
				objMap.put("verticalAcceleration", (retList.get(i))[25]);
				objMap.put("startDate", (retList.get(i))[26]);
				objMap.put("startTime", (retList.get(i))[27]);
				objMap.put("flightId", (retList.get(i))[28]);

				list.add(objMap);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		return list;
	}
	
	@RequestMapping(value = "/view/getFlightPlottingData/{flightId}", 
			method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FleetDataDTO> getFlightPlottingData(
			@PathVariable("flightId") String flightId) {
		
		List<FleetDataDTO> fleetDataDtoList = new ArrayList<FleetDataDTO>();
		FleetDataDTO fleetDataDto = null;
		try {
			System.out.println("AircraftService.getFlightPlottingData() : start");

			List<FleetData> fleetDataList = (List<FleetData>) filghtFleetrepo.getFlightPlottingData(flightId);
			for (FleetData fleetData : fleetDataList) {
				fleetDataDto = new FleetDataDTO();
				BeanUtils.copyProperties(fleetData, fleetDataDto);
				fleetDataDtoList.add(fleetDataDto);
			}
			System.out.println("AircraftService.getFlightPlottingData() : end");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return fleetDataDtoList;
	}
}
