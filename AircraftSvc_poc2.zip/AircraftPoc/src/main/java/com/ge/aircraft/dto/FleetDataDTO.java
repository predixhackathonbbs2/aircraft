/*
 * Copyright (c) 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
 
package com.ge.aircraft.dto;

/**
 * 
 * @author predix -
 */
import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement
public class FleetDataDTO {
	
	private long fleetId;
	private String airspeed;
	private String armRetardantTankDoor;
	private String beaconStartStopRecording;
	private String elapsedTime;
	private String elevatorPosition;
	private String flapPosition;
	private String gearUpAndLocked;
	private String leftAileronPosition;
	private String peakValleyIndicator;
	private String pressureAltitude;
	private String recordType;
	private String retardantDoorOpen;
	private String retardantTankFloat;
	private String rollAcceleration;
	private String strainGauge1;
	private String strainGauge2;
	private String strainGauge3;
	private String strainGauge4;
	private String strainGauge5;
	private String strainGauge6;
	private String strainGauge7;
	private String strainGauge8;
	private String timestamp;
	private String triggerChannel;
	private String verticalAcceleration;
	private long flightId;
	
	
	/**
	 * @return the fleetId
	 */
	public long getFleetId() {
		return this.fleetId;
	}
	/**
	 * @param fleetId the fleetId to set
	 */
	public void setFleetId(long fleetId) {
		this.fleetId = fleetId;
	}
	/**
	 * @return the airspeed
	 */
	public String getAirspeed() {
		return this.airspeed;
	}
	/**
	 * @param airspeed the airspeed to set
	 */
	public void setAirspeed(String airspeed) {
		this.airspeed = airspeed;
	}
	/**
	 * @return the armRetardantTankDoor
	 */
	public String getArmRetardantTankDoor() {
		return this.armRetardantTankDoor;
	}
	/**
	 * @param armRetardantTankDoor the armRetardantTankDoor to set
	 */
	public void setArmRetardantTankDoor(String armRetardantTankDoor) {
		this.armRetardantTankDoor = armRetardantTankDoor;
	}
	/**
	 * @return the beaconStartStopRecording
	 */
	public String getBeaconStartStopRecording() {
		return this.beaconStartStopRecording;
	}
	/**
	 * @param beaconStartStopRecording the beaconStartStopRecording to set
	 */
	public void setBeaconStartStopRecording(String beaconStartStopRecording) {
		this.beaconStartStopRecording = beaconStartStopRecording;
	}
	/**
	 * @return the elapsedTime
	 */
	public String getElapsedTime() {
		return this.elapsedTime;
	}
	/**
	 * @param elapsedTime the elapsedTime to set
	 */
	public void setElapsedTime(String elapsedTime) {
		this.elapsedTime = elapsedTime;
	}
	/**
	 * @return the elevatorPosition
	 */
	public String getElevatorPosition() {
		return this.elevatorPosition;
	}
	/**
	 * @param elevatorPosition the elevatorPosition to set
	 */
	public void setElevatorPosition(String elevatorPosition) {
		this.elevatorPosition = elevatorPosition;
	}
	/**
	 * @return the flapPosition
	 */
	public String getFlapPosition() {
		return this.flapPosition;
	}
	/**
	 * @param flapPosition the flapPosition to set
	 */
	public void setFlapPosition(String flapPosition) {
		this.flapPosition = flapPosition;
	}
	/**
	 * @return the gearUpAndLocked
	 */
	public String getGearUpAndLocked() {
		return this.gearUpAndLocked;
	}
	/**
	 * @param gearUpAndLocked the gearUpAndLocked to set
	 */
	public void setGearUpAndLocked(String gearUpAndLocked) {
		this.gearUpAndLocked = gearUpAndLocked;
	}
	/**
	 * @return the leftAileronPosition
	 */
	public String getLeftAileronPosition() {
		return this.leftAileronPosition;
	}
	/**
	 * @param leftAileronPosition the leftAileronPosition to set
	 */
	public void setLeftAileronPosition(String leftAileronPosition) {
		this.leftAileronPosition = leftAileronPosition;
	}
	/**
	 * @return the peakValleyIndicator
	 */
	public String getPeakValleyIndicator() {
		return this.peakValleyIndicator;
	}
	/**
	 * @param peakValleyIndicator the peakValleyIndicator to set
	 */
	public void setPeakValleyIndicator(String peakValleyIndicator) {
		this.peakValleyIndicator = peakValleyIndicator;
	}
	/**
	 * @return the pressureAltitude
	 */
	public String getPressureAltitude() {
		return this.pressureAltitude;
	}
	/**
	 * @param pressureAltitude the pressureAltitude to set
	 */
	public void setPressureAltitude(String pressureAltitude) {
		this.pressureAltitude = pressureAltitude;
	}
	/**
	 * @return the recordType
	 */
	public String getRecordType() {
		return this.recordType;
	}
	/**
	 * @param recordType the recordType to set
	 */
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	/**
	 * @return the retardantDoorOpen
	 */
	public String getRetardantDoorOpen() {
		return this.retardantDoorOpen;
	}
	/**
	 * @param retardantDoorOpen the retardantDoorOpen to set
	 */
	public void setRetardantDoorOpen(String retardantDoorOpen) {
		this.retardantDoorOpen = retardantDoorOpen;
	}
	/**
	 * @return the retardantTankFloat
	 */
	public String getRetardantTankFloat() {
		return this.retardantTankFloat;
	}
	/**
	 * @param retardantTankFloat the retardantTankFloat to set
	 */
	public void setRetardantTankFloat(String retardantTankFloat) {
		this.retardantTankFloat = retardantTankFloat;
	}
	/**
	 * @return the rollAcceleration
	 */
	public String getRollAcceleration() {
		return this.rollAcceleration;
	}
	/**
	 * @param rollAcceleration the rollAcceleration to set
	 */
	public void setRollAcceleration(String rollAcceleration) {
		this.rollAcceleration = rollAcceleration;
	}
	/**
	 * @return the strainGauge1
	 */
	public String getStrainGauge1() {
		return this.strainGauge1;
	}
	/**
	 * @param strainGauge1 the strainGauge1 to set
	 */
	public void setStrainGauge1(String strainGauge1) {
		this.strainGauge1 = strainGauge1;
	}
	/**
	 * @return the strainGauge2
	 */
	public String getStrainGauge2() {
		return this.strainGauge2;
	}
	/**
	 * @param strainGauge2 the strainGauge2 to set
	 */
	public void setStrainGauge2(String strainGauge2) {
		this.strainGauge2 = strainGauge2;
	}
	/**
	 * @return the strainGauge3
	 */
	public String getStrainGauge3() {
		return this.strainGauge3;
	}
	/**
	 * @param strainGauge3 the strainGauge3 to set
	 */
	public void setStrainGauge3(String strainGauge3) {
		this.strainGauge3 = strainGauge3;
	}
	/**
	 * @return the strainGauge4
	 */
	public String getStrainGauge4() {
		return this.strainGauge4;
	}
	/**
	 * @param strainGauge4 the strainGauge4 to set
	 */
	public void setStrainGauge4(String strainGauge4) {
		this.strainGauge4 = strainGauge4;
	}
	/**
	 * @return the strainGauge5
	 */
	public String getStrainGauge5() {
		return this.strainGauge5;
	}
	/**
	 * @param strainGauge5 the strainGauge5 to set
	 */
	public void setStrainGauge5(String strainGauge5) {
		this.strainGauge5 = strainGauge5;
	}
	/**
	 * @return the strainGauge6
	 */
	public String getStrainGauge6() {
		return this.strainGauge6;
	}
	/**
	 * @param strainGauge6 the strainGauge6 to set
	 */
	public void setStrainGauge6(String strainGauge6) {
		this.strainGauge6 = strainGauge6;
	}
	/**
	 * @return the strainGauge7
	 */
	public String getStrainGauge7() {
		return this.strainGauge7;
	}
	/**
	 * @param strainGauge7 the strainGauge7 to set
	 */
	public void setStrainGauge7(String strainGauge7) {
		this.strainGauge7 = strainGauge7;
	}
	/**
	 * @return the strainGauge8
	 */
	public String getStrainGauge8() {
		return this.strainGauge8;
	}
	/**
	 * @param strainGauge8 the strainGauge8 to set
	 */
	public void setStrainGauge8(String strainGauge8) {
		this.strainGauge8 = strainGauge8;
	}
	/**
	 * @return the timestamp
	 */
	public String getTimestamp() {
		return this.timestamp;
	}
	/**
	 * @param timestamp the timestamp to set
	 */
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	/**
	 * @return the triggerChannel
	 */
	public String getTriggerChannel() {
		return this.triggerChannel;
	}
	/**
	 * @param triggerChannel the triggerChannel to set
	 */
	public void setTriggerChannel(String triggerChannel) {
		this.triggerChannel = triggerChannel;
	}
	/**
	 * @return the verticalAcceleration
	 */
	public String getVerticalAcceleration() {
		return this.verticalAcceleration;
	}
	/**
	 * @param verticalAcceleration the verticalAcceleration to set
	 */
	public void setVerticalAcceleration(String verticalAcceleration) {
		this.verticalAcceleration = verticalAcceleration;
	}
	/**
	 * @return the flightId
	 */
	public long getFlightId() {
		return this.flightId;
	}
	/**
	 * @param flightId the flightId to set
	 */
	public void setFlightId(long flightId) {
		this.flightId = flightId;
	}
}
