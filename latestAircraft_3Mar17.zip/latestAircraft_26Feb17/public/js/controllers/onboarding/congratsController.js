
app.controller('congratsController', function($scope, $filter, $http, $rootScope,$state,Auth,$timeout,toaster,constants,
		$cookies,$cookieStore,$location, WorkFlow, supplier) {

		if(!WorkFlow.getRequestId()){
			toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
			//$state.go('supplierHome');
			return;		
		}
		/*
		supplier.riskLevel(WorkFlow.getRequestId()).then(function(data) {
				$scope.riskData = data;
				
			}, function(data) {
			toaster.pop('error', "Approve api", "server not responding");
			$state.go('supplierReview');
		}); */
		
		
});
	