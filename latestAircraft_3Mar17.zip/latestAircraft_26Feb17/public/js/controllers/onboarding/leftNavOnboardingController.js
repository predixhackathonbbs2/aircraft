
app.controller('leftNavOnboardingController', function($scope, $filter, $http, $rootScope,constants,
		$state, Auth, $timeout, toaster, $cookies, $cookieStore, WorkFlow, supplier) {
        $scope.stateName=$state.current.name;
        
        if($scope.stateName=="supplierProfileCompany" && $rootScope.saveCompleteProfile==true){
        	$rootScope.saveCompleteProfileActive=true;
        }

        
        if($scope.stateName=="supplierProfileAddress.legal" && $rootScope.saveCompleteProfile==true){
        	$rootScope.saveCompleteProfileActive=true;
        }

       
        if($scope.stateName=="supplierProfileBank" && $rootScope.saveCompleteBank==true){
        	$rootScope.saveCompleteAddressActive=true;
        	$rootScope.saveCompleteProfileActive=true;
        }

        
       
        if($scope.stateName=="supplierProfileContacts" && $rootScope.saveCompleteBank==true){
        	$rootScope.saveCompleteAddressActive=true;
        	$rootScope.saveCompleteProfileActive=true;
        	$rootScope.saveCompleteBankActive=true;
        	$rootScope.saveCompleteAddressCurrent=false;
        }

       
        if($scope.stateName=="supplierProfileDiversity"){
        	$rootScope.saveCompleteAddressActive=true;
        	$rootScope.saveCompleteProfileActive=true;
        	$rootScope.saveCompleteBankActive=true;
        	$rootScope.saveCompleteContactActive=true;

        }

        if($scope.stateName=="supplierProfileDueDiligence" && $rootScope.saveCompleteDiversity==true){
        	$rootScope.saveCompleteAddressActive=true;
        	$rootScope.saveCompleteProfileActive=true;
        	$rootScope.saveCompleteBankActive=true;
        	$rootScope.saveCompleteContactActive=true;
        	$rootScope.saveCompleteDiversityActive=true;

        }
	


});