'use strict';

app.factory('Auth', ['$q', '$http','$rootScope','$cookies','$cookieStore','constants',
	function ($q, $http,$rootScope,$cookies,$cookieStore,constants) {
	  var supplierId;
	  var cookie = $cookieStore.get("sc_token");
		var Auth = {
				getCookieVal:function(){	
					return $cookieStore.get("sc_token");						
				 },		
			login:function(login) { 
				/*'https://supplierconnect-auth.run.asv-pr.ice.predix.io/supplierconnect/login*/
				var url = constants.supplierLoginUrl;
				var d = $q.defer();
				var req = {
					headers: {
						'Content-Type': 'application/json'
					},
					url: url,
					method: 'POST',
					data:{
						username : login.email,
						password : login.password	
					}
				};
				$http(req).then(function(reply) {
			     d.resolve(reply.data);
			     var token  = reply.data.token_type + " " +reply.data.access_token;
			     $cookies['sc_token'] = token;
			     console.log("SC",$cookies['sc_token'])
			     
	             localStorage.setItem("token",token);
	            }, function(reply) {
	                d.reject();
	            });
	            return d.promise;
	
			},
			isRoleExists: function(roles, privillage){
				var flag = false;
				angular.forEach(roles, function(value, key) {
					
					if (value.authority == privillage){
						flag = true;
					}
				});
				return flag;
			},
			isSupplierRole: function(roles, privillage){
				var flag = false;
				angular.forEach(roles, function(value, key) {
					if (value.name == "Supplier Accounts Receivable" || value.name == "Supplier Order Fulfillment" || value.name == "Supplier Sales" || value.name == "Supplier") {
						flag = true;
					}
				});
				return flag;
			},
			getRoles:function(id) {
				/*'https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/userroles'*/
			 	var url = constants.GET_ROLES;
			 	var d = $q.defer();
			 	var req = {
			 		headers: {
			 			'Content-Type': 'application/json',
			 			//'Authorization' : 'Basic ' + authData
			 			'Authorization' : Auth.getCookieVal()
			 		},
			 		url: url,
			 		method: 'GET',
					cache:true
					
			 	};
			 	$http(req).then(function(reply) {				
			      d.resolve(reply.data);
	             }, function(reply) {
	                 d.reject();
	             });
	             return d.promise;
			}

       
		};    

		return Auth;
	}
]);