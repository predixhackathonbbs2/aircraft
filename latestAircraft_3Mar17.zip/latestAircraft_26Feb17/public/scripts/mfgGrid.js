var selected = [];
//var mfgDatatable;
var myJsonString;
var jsonObj;
var arr = new Array();      
var data;
        //var selected = [];
var table;
var dtTable;
var myArrayNew;
var sliderMinval=0;
var sliderMaxval=1000;
$(document).ready(function() {

	$(".signImage").click(function () {

    $signImage = $(this);
    $content1 = $signImage.next();
    $content1.slideToggle(500, function () {
        $signImage.text(function () {
            return $content1.is(":visible") ? "- Filter Parameters" : "+ Filter Parameters";
        });
    });

});

	
	
	$( "#slider-range" ).slider({
			range: true,
			min: sliderMinval,
			max: sliderMaxval,
			values: [ sliderMinval, sliderMaxval ],
			slide: function( event, ui ) {
				$( "#elapseTime111" ).val( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
			}
		});
		$( "#elapseTime111" ).val( $( "#slider-range" ).slider( "values", 0 ) +
			" - " + $( "#slider-range" ).slider( "values", 1 ) );
	
	clearFlightFileds();
	$("#srcflighttableID").show();
	$("#srcflightFiltertableID").hide();
	$("#loading").hide();
     myArrayNew = [
                { "sTitle": "Flight Id", "mData": "flightId" },
                { "sTitle": "Air Speed", "mData": "airspeed" },
                { "sTitle": "Elevator Position", "mData": "elevatorPosition" },
                { "sTitle": "Peak Valley Indicator ", "mData": "peakValleyIndicator" },
				 { "sTitle": "Flap Position", "mData": "flapPosition" },
                { "sTitle": "Fleet Id", "mData": "fleetId" },
                { "sTitle": "Vertical Acceleration", "mData": "verticalAcceleration" },
                { "sTitle": "Roll Acceleration ", "mData": "rollAcceleration" },
				 { "sTitle": "Left Aileron Position", "mData": "leftAileronPosition" },
                { "sTitle": "Start Time", "mData": "startTime" },
                { "sTitle": "Retardant Door Open", "mData": "retardantDoorOpen" },
                { "sTitle": "Timestamp", "mData": "timestamp" },
				 { "sTitle": "Pressure Altitude", "mData": "pressureAltitude" },
                { "sTitle": "Strain Gauge 3", "mData": "strainGauge3" },
                { "sTitle": "Retardant Tank Float", "mData": "retardantTankFloat" },
                { "sTitle": "Strain Gauge 2", "mData": "strainGauge2" },
				{ "sTitle": "Strain Gauge 1", "mData": "strainGauge1" },
                { "sTitle": "Trigger Channel", "mData": "triggerChannel" },
                { "sTitle": "Record Type", "mData": "recordType" },
                { "sTitle": "Gear Up And Locked ", "mData": "gearUpAndLocked" },
				 { "sTitle": "Arm Retardant Tank Door", "mData": "armRetardantTankDoor" },
                { "sTitle": "Strain Gauge 8", "mData": "strainGauge8" },
                { "sTitle": "Beacon Start Stop Recording", "mData": "beaconStartStopRecording" },
                { "sTitle": "Strain Gauge 7", "mData": "strainGauge7" },
				 { "sTitle": "Strain Gauge 6", "mData": "strainGauge6" },
                { "sTitle": "Strain Gauge 5", "mData": "strainGauge5" },
                { "sTitle": "Start Date", "mData": "startDate" },
                { "sTitle": "Elapsed Time ", "mData": "elapsedTime" },
				 { "sTitle": "Strain Gauge 4", "mData": "strainGauge4" }
               
            ];  	
function refreshMFGTable(jsonData){
     $('#invoicedataTable').dataTable({
     "aaData": jsonData,
                  dom: 'lBfrtip',
				  "bFilter" : false, 
				  "bPaginate": true,
				 "lengthMenu": [10,25,50,100,500],
                 buttons: ['excel' , 'print','copyHtml5'],
                  "aoColumns":myArrayNew,
			   
			   "initComplete": function(settings){
					$('#invoicedataTable thead th').each(function () {
					   var $td = $(this);
					   $td.attr('title', $td.text());
					});

					/* Apply the tooltips */
					$('#invoicedataTable thead th[title]').tooltip(
					{
					   "container": 'body'
					}); 
							//var detail=data.poNumber;       
							//alert('detail'+detail);							
				} 

               }

);

$('#invoicedataTable_filter').addClass("pull-right");
$('#invoicedataTable_paginate').css({"font-size":"12px"});
$('#invoicedataTable_info').css({"font-size":"12px","font-weight": "bold"});
$('#invoicedataTable_length').find('label').css({"margin-left": "900px"})

}
$("#flightClearBtnID").click(function (event) {
clearFlightFileds();
 });
function clearFlightFileds(){
	
	$("#datepicker").val('');
	jQuery("#errorVaildDate").text('');
	$('#FlighttimeID').empty();
	$("#startMinute").val('');
	$("#startSecond").val('');
	$("#startMS").val('');
	$("#EndMinute").val('');
	$("#EndSecond").val('');
	$("#EndMS").val('');
	

}

	refreshMFGTable(data);
		//loadInvoiceDataTable(data,myArrayNew);
	function refreshGridInvoiceDataTable(responseData) {
		
	$('#invoicedataTable').dataTable().fnDestroy();

         //'#invoicedataTable').dataTable.fnDestroy();		   
           
		   //console.log('jsonDataresponseData:::::::::'+JSON.stringify(responseData));
		   
		   refreshMFGTable(responseData);
		   
    }
	//table = $('#invoicedataTable1').dataTable();
	/*function refreshInvoiceDataTable(jsonData,myArray) {
		// $('#invoicedataTable1').dataTable.fnDestroy();
		   console.log('columndata'+JSON.stringify(myArray)+JSON.stringify(jsonData));
		   
		   loadInvoiceDataTable(jsonData,myArray);
		   
    }
	
function loadInvoiceDataTable(jsonData,myArray){
    $('#invoicedataTable1').dataTable({
				  "aaData": jsonData,
				  "aoColumns":myArray,
                 dom: 'Bfrtip',
				  "bFilter" : false, 
				  "bPaginate": true,
				  "lengthMenu": [10, 25, 50, "All"],
                  buttons: ['excel' ],
                  
			      "initComplete": function(settings){
					$('#invoicedataTable1 thead th').each(function () {
					   var $td = $(this);
					   $td.attr('title', $td.text());
					});

					 Apply the tooltips *
					$('#invoicedataTable1 thead th[title]').tooltip(
					{
					   "container": 'body'
					}); 
							//var detail=data.poNumber;       
							//alert('detail'+detail);							
				} 

               }

);

$('#invoicedataTable1_filter').addClass("pull-right");
$('#invoicedataTable1_paginate').css({"font-size":"12px"});
$('#invoicedataTable1_info').css({"font-size":"12px","font-weight": "bold"});
}*/


	
	
	
	 $( function() {
   $( "#datepicker" ).datepicker();
	var searcheDateID = $("#datepicker").val();
	});

  $('#datepicker').datepicker({
   changeMonth: true,
   changeYear: true,
   onSelect: function(dateText,inst) {	
	var searcheDateID = $("#datepicker").val();
	  searcheDateID = dateFormatt(searcheDateID);
	  //$('#loaderID').show();
	 getFlightDataTime(searcheDateID); 

	}

	});

	$("#recordTypeID").change(function () {
        var recordTypeValue = $("#recordTypeID option:selected").text();
       // alert(recordTypeValue);
		$('#chanelTypeID').empty();
		if (recordTypeValue == 'PE'){
			$('#chanelTypeID').empty();			
		}
		if (recordTypeValue == 'TR'){
			$('#chanelTypeID').empty();
			$('#chanelTypeID').append($('<option>', { 
	//alert(responseData.startTime
	
			value: "10",
			text : "10"
		}));
$('#chanelTypeID').append($('<option>', { 
	//alert(responseData.startTime
	
			value: "20",
			text : "20"
		}));
$('#chanelTypeID').append($('<option>', { 
	//alert(responseData.startTime
	
			value: "30",
			text : "30"
		}));		
		}
    });
	
	$("#submitSrcFltID").click(function (event) {
		var searchstartTime='';
		var searchendTime='';
		var splitelapseTime;
		var elapseTimeLegend=$("#elapseTime111").val();
		splitelapseTime=elapseTimeLegend.split("-");
		searchstartTime=splitelapseTime[0].trim();
		searchendTime=splitelapseTime[1].trim();
		
	var searchDate = $("#datepicker").val();
	if(searchDate == ''){
	jQuery("#errorVaildDate").text('Please enter Date.');
	return;
	}else{
	searchDate = dateFormatt(searchDate);
	var searchTime = $("#FlighttimeID option:selected").text();
	var srchRecordTypeID = $("#recordTypeID option:selected").text();
    var srcchanelType = $("#chanelTypeID option:selected").text();	
	if(srchRecordTypeID =="PE"){
		srcchanelType ="''";
	}
	//var searchMinute = $("#startMinute").val();
	//var searchStartSecond = $("#startSecond").val();
	//var searchStartMS = $("#startMS").val();
	//if (searchMinute != '' &&  searchStartSecond != '' && searchStartMS != ''){
	//searchstartTime = searchMinute+':'+searchStartSecond+'.'+searchStartMS;
	//}
	//else{
	//	searchstartTime="''";
	//}
	//var searchEndMinute = $("#EndMinute").val();
	//var searchEndSecond = $("#EndSecond").val();
	//var searchEndMS = $("#EndMS").val();
	//if (searchEndMinute != '' &&  searchEndSecond != '' && searchEndMS != ''){
	// searchendTime = searchEndMinute+':'+searchEndSecond+'.'+searchEndMS;
	//}
	//else{
	//	searchendTime="''";
	//}
	//var searchendTime = $("#EndMinute").val()+':'+$("#EndSecond").val()+'.'+$("#EndMS").val();
	
	console.log('data'+searchDate+searchTime+recordTypeID+srcchanelType+searchstartTime+searchendTime);
	
	searchGridData(searchDate,searchTime,srchRecordTypeID,srcchanelType,searchstartTime,searchendTime);
	$("#loading").show();
	}
	//alert("searchPO"+searchPONbr);
//searchGridData(searchstartDate, searchstartTime, searchrecordType, searchstartTimeId, searchendTime);

   });
   
    
   
   
  		function searchGridData(searchDate,searchTime,srchRecordTypeID,srcchanelType,searchstartTime,searchendTime){
			var serviceURL = "https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/view/getFlightDetailsWithDynamicfilter/"+searchDate+"/"+searchTime+"/"+srchRecordTypeID+"/"+srcchanelType+"/"+searchstartTime+"/"+searchendTime;
			
			//alert(serviceURL);
			console.log("serviceURL"+serviceURL);
			
		$.ajax({
 
	url: serviceURL,
	//url: "https://predix-aircraft-demo2.run.aws-usw02-pr.ice.predix.io/view/getFlightDetailsWithDynamicfilter/"+searchDate+"/"+searchTime+"/"+srchRecordTypeID+"/"+srcchanelType+"/"+searchstartTime+"/"+searchendTime,
	//url:"https://predix-aircraft-demo2.run.aws-usw02-pr.ice.predix.io/view/getFlightDetailsWithDynamicfilter/6-26-2004/22:49/TR/10/10:29.8/10:30.6",
 
                type: "get", //send it through post method
			//	type: "GET", //send it through post methodOfPayment

   //	data : postData,

				headers : {

			   'Content-Type' : 'application/json'
				},
                success: function(responseData) {
 
				console.log('responseData'+JSON.stringify(responseData));
				data=responseData;
				  $("#loading").hide();
				var checked;
				var i = 0;
                $('input[type=checkbox]').each(function () {
                   if (this.checked) {
					   i=i+1;
					   
                   }
				  
               });
			    if(i >0){
					  // alert('cheked');
					   checkBoxfilter();
					    $("#srcflighttableID").hide();
				        $("#srcflightFiltertableID").show();
				   }
				   else{
					  // alert('unchekced');
				  refreshGridInvoiceDataTable(responseData)
				  $("#srcflighttableID").show();
				   $("#srcflightFiltertableID").hide();
				  
				   }
				//refreshMFGTable(responseData);
				
 
},
                error: function ( xhr, status, error) {
   
      console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
	 $("#loading").hide();
    }
 
  });
 
  }

   function checkBoxfilter(){
		   
		   
            //  $("#invoicedataTable1").find('thead tr th').remove(); 
			if (dtTable != null){
			dtTable.fnDestroy();
			}
			  
                $('input[type=checkbox]').each(function () {
                   if (this.checked) {
				  // alert($(this).attr("ColumnName"));
                       $("#invoicedataTable1").find('thead tr').append("<th>" + $(this).attr("ColumnName") + "</th>");
                   }
               });
              var i = 0;
              $("#invoicedataTable1").empty();
                var myArray = [];
                $('input[type=checkbox]').each(function () {
                    if (this.checked) {
                        i = i + 1;
						for(j=0;j< myArrayNew.length;j++){
							//alert(myArrayNew[j].mData)
							if($(this).attr("ColumnValueName") == myArrayNew[j].mData){
                        myArray.push(
                             myArrayNew[j]
                         );
                    }
						}
					}
                });
                //myArray = "[" + myArray + "]";
				//alert($(this).attr("ColumnName"));
				console.log(JSON.stringify(myArray));
				console.log(data);
               // if (i == 0) {
                   // var myArray = [
                      // { "sTitle": "Name", "mData": "name" },
                     //  { "sTitle": "Position", "mData": "position" },
                     ///  { "sTitle": "Office", "mData": "office" },
                     //  { "sTitle": "Salary", "mData": "salary" }
                      //      ];
               // }
			   
                dtTable=$('#invoicedataTable1').dataTable({
                    "aaData": data,
                    "aoColumns": myArray,
                    dom: 'lBfrtip',
					"bFilter" : false, 
					"bPaginate": true,
				 "lengthMenu": [10,25,50,100,500],
                  buttons: ['excel' , 'print','copyHtml5'],
				     "initComplete": function(settings){
					$('#invoicedataTable1 thead th').each(function () {
					   var $td = $(this);
					   $('#invoicedataTable1 thead').css('background-color','rgb(70,130,180);');
					   $('#invoicedataTable1 thead').css('color','white');
					   $td.attr('title', $td.text());
					});

					/* Apply the tooltips */
					$('#invoicedataTable1 thead th[title]').tooltip(
					{
					   "container": 'body'
					}); 
							//var detail=data.poNumber;       
							//alert('detail'+detail);							
				} 
                });
				$('#invoicedataTable1_length').find('label').css({"margin-left": "900px"})
				}



 
function getFlightDataTime(date){
 console.log("response data with filter"+date);
 //06-27-2004",
 $('#FlighttimeID').empty();
$('#FlighttimeID').find('option:not(:first)').remove();
$('#FlighttimeID').append($("<option></option>").attr("value",0).text('-Select-')); 
       $.ajax({

   	url: "https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/getFlightTimeStampDetails/"+date,
	
	

   	type: "GET", //send it through post methodOfPayment

   //	data : postData,

   	headers : {

   'Content-Type' : 'application/json'
    },
   success: function(responseData) {
       //  alert("search data available "+ JSON.stringify(responseData).length);
   console.log("response data with filter"+JSON.stringify(responseData));   
	
if(responseData.length){
//var items = JSON.(responseData));   



   $.each(responseData, function (i, item) {
	 //  alert(item.startTime);
    $('#FlighttimeID').append($('<option>', { 
	//alert(responseData.startTime
	
        value: item.startTime,
       text : item.startTime
    }));
	 $('#loaderID').hide();
	  jQuery("#errorVaildDate").text('');
});
}
else{
	 $('#loaderID').hide();
	 jQuery("#errorVaildDate").text('Please enter valid Date.');
	//alert('Enter valid Date')
}
  // refreshInvoiceDataTable(responseData);
   },

   error: function ( xhr, status, error) {
    console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
    });
 
   
    }

     function dateFormatt(searcheDateID) {
		//alert(searcheDateID);
   
				//var s = '2016-04-30';
			var fields = searcheDateID.split("/");
			var datenew = fields[0];			
			var mon = fields[1];
			var yr = fields[2];
			var newDate=datenew+'-'+mon+'-'+yr;
			newDate = newDate.replace(/\b0(?=\d)/g, '')
			console.log('newDate'+newDate)
			return newDate;
}
 jQuery('[data-toggle="invNmberTooltip"]').tooltip(); 

      
		$("#myTab a").click(function(e){
    	e.preventDefault();
    	$(this).tab('show');
    });
	
	$("#FlighttimeID").change(function() {
	$("#loading").show();
		var date=dateFormatt($("#datepicker").val());
		var flightTime=$(this).val();
		//alert(date);
		//alert(flightTime);
		      $.ajax({
			url: "https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/view/getFlightMinMaxElapsedTimeForStartTime/"+date+"/"+flightTime,
			type: "GET",
			headers : {
			'Content-Type' : 'application/json'
			},
			success: function(responseData) {
			$("#loading").hide();
			//console.log("response data with filter"+JSON.stringify(responseData));   
			var obj = jQuery.parseJSON(JSON.stringify(responseData));
			//sliderMinval=obj.minElapsedTime;
			sliderMaxval=obj.maxElapsedTime;
			$( "#slider-range" ).slider({
			range: true,
			min: 0,
			max: obj.maxElapsedTime,
			values: [ sliderMinval, sliderMaxval ],
			slide: function( event, ui ) {
				$( "#elapseTime111" ).val( ui.values[ 0 ] + " - " + ui.values[ 1 ] );
			}
		});
		$( "#elapseTime111" ).val( $( "#slider-range" ).slider( "values", 0 ) +
			" - " + $( "#slider-range" ).slider( "values", 1 ) );
			
	
  // refreshInvoiceDataTable(responseData);
   },

   error: function ( xhr, status, error) {
    console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
    }
    });
	});
	
	
	
 }); 


	