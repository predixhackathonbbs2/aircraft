app.controller('homeController', function($scope, $filter, $http,$q, $rootScope,constants,
		$state, Auth, $timeout, toaster, $cookies, $cookieStore, WorkFlow, supplier) {
	
	$scope.advSearch=false;	
    $scope.showFilter=true;
    $scope.hideFilter=false;
    $cookieStore.remove("instanceId");
    $cookieStore.remove("taskId");
    $cookieStore.remove("requestId");
    //$cookieStore.remove("uId");
    $cookieStore.remove("commodityFamilyId");	
    $cookieStore.remove("email");	
    $cookieStore.remove("supplierName");	
    $cookieStore.remove("supplierFirstName");	
    $cookieStore.remove("supplierLastName");

    Auth.getRoles().then(function(roles){ 
        if (Auth.isSupplierRole(roles.roles)){
            $state.go('supplierHome');
        }

    }, function(data){
        $scope.loader=false;
    });
    $scope.inviteSupplier = function () {
	    Auth.getRoles().then(function(roles){	
		    if (Auth.isRoleExists(roles.authorities , 'ADD_SUPPLIER')){
		    	$scope.inviteEnabled = true;
		    	// $cookieStore.put("Persona","Sourcing");
		    }
			$cookieStore.put("uId", roles.id);
			//localStorage.setItem("uId", roles.id); 
			console.log($scope.inviteEnabled);
			//$scope.inviteEnabled= true;
			if($scope.inviteEnabled) {
				 
				WorkFlow.startInstanceV2().then(function(data){
					
					if(data.requestId){
								console.log(data);
								WorkFlow.setInstance(data.instanceId);
								WorkFlow.setTask(data.taskId);
								WorkFlow.setRequestId(data.requestId);
								$state.go('supplierInfo');
					}
					else{
						toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
						$state.go('homePage');
						return
					}
							},function(data){});

					
					
				
			} else {
				toaster.pop('error', "Access Denied", "You don't have permission to add supplier");
			}
			
		}, function() {
			toaster.pop('error', "Role list", "server not responding");
		});		
	}

	//search options (External vs Internal)
	$scope.changeSearch={};
	$scope.changeSearch.searchOptions = true;
	$rootScope.activeSearch="true";
	$scope.placeholder = "ID, Supplier Name, DBA, Country, Address";
	$scope.changeSearchOptions = function(changeSearch){
		$scope.loader=true;
		if(changeSearch.searchOptions == true){
			$scope.placeholder = "ID, Supplier Name, DBA, Country, Address";
			$rootScope.activeSearch="true";
			$scope.loader=false;
			
		}else if(changeSearch.searchOptions == false){
			$scope.placeholder = "Business Unit Code (BUC), Company Code";
			$rootScope.activeSearch="false";
			$scope.loader=false;
			
		}
	}
	
	$scope.showFilterClick=function(){
		$scope.advSearch=true;
	    $scope.showFilter=false;
	    $scope.hideFilter=true;
		  
	}

	$scope.hideFilterClick=function(){
		$scope.advSearch=false;
	    $scope.showFilter=true;
	    $scope.hideFilter=false;
	}

	// $scope.typeAhead = function(text){
	// 	supplier.getTypeAhead($scope.text).then(function(data){
	// 		$scope.typeAheadData = data.data.suggestions;	
			
	// 	}); 	
	// }
	// $scope.removeTag = function(){
	// 	var b = document.getElementsByClassName('b');
	// 	while(b.length) {
	// 	    var parent = b[ 0 ].parentNode;
	// 	    while( b[ 0 ].firstChild ) {
	// 	        parent.insertBefore(  b[ 0 ].firstChild, b[ 0 ] );
	// 	    }
	// 	     parent.removeChild( b[ 0 ] );
	// 	}
	// }

	$scope.typeAhead = function(viewValue) {
		if($scope.changeSearch.searchOptions){
			var url = constants.LOOKHEAD_SEARCH;
			var searchTerms = {text: viewValue,highlight: true, limit: 15};
		}else{
			var url = constants.INTERNAL_LOOKHEAD_SEARCH;
			var searchTerms = {text: viewValue,highlight: true, limit: 10};
		}
	  	var cookie = $cookieStore.get("sc_token");
	  	var auth = {
	  		headers:{
		  		'Content-Type':  'application/json',
				'Authorization': cookie
			}
	  	};
	  	return $http.post(url, searchTerms, auth
	  	).then(function(result){
		    return result.data.data.suggestions;
		    var resultdata = result.data.data.suggestions;
		});
	};

	$scope.redirect = function(){
		window.location = "#/search";
	}
	$scope.onSelect = function($item, $model, $label, $event){	
		$scope.query = $label.replace(/<b>/g,'').replace(/<\/b>/g,'');
		console.log($scope.query);
		var obj = {
		  "text": ($scope.text.indexId)?$scope.text.indexId:'',
		  "query": ($scope.query)?$scope.query:''			 
		}
		supplier.setSearchParams(obj);		
		$state.go('supplierSearch', {query: $scope.query, activeSearch: $rootScope.activeSearch});
	}
	$scope.doSearch = function() {
		$scope.query = document.getElementById('search').value;
		$scope.query = $scope.query.replace(/<b>/g,'').replace(/<\/b>/g,'');
		var obj = {
		  "text": ($scope.text.indexId)?$scope.text.indexId:'',
		  "query": ($scope.query)?$scope.query:''			 
		}
		supplier.setSearchParams(obj);		
		$state.go('supplierSearch', {query: $scope.query,  activeSearch: $rootScope.activeSearch});
	}
	
	$scope.magnifierClick = function() {
    	$scope.doSearch();
    }
	
   $scope.clearData=function(){
	   $scope.supplierInfo = {};
   } 

});
