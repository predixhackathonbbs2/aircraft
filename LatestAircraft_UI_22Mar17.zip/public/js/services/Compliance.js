'use strict';

app.factory('Compliance', ['$q', '$http','$rootScope','$cookies','$cookieStore','constants','toaster', 'WorkFlow',
	function ($q, $http,$rootScope,$cookies,$cookieStore,constants,toaster, WorkFlow) {
	  var cookie = $cookieStore.get("sc_token");
		var Compliance = {
				getCookieVal:function(){	
					return $cookieStore.get("sc_token");						
				 },	
				getComplianceDetails:function() { 
				
					var data={
						    "commodityFamilyId": $cookieStore.get("commodityFamilyId"), 
						    "is3TG" :false,
						    "isGovFacing": false
						}
				var url = constants.COMPLIANCE_URL;
				var d = $q.defer();
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : Compliance.getCookieVal()
					},
					url: url,
					method: 'POST',
					data:data
				};
				console.log(req);
				$http(req).then(function(reply) {
			     d.resolve(reply.data);
		     
	            }, function(reply) {
	                d.resolve();
	                toaster.pop('error', "Compliance Resolve API", "server not responding");
	            });
	            return d.promise;
	
			},
			getComplianceRules:function() { 
				
				var data={"requestId": WorkFlow.getRequestId()};
				var url = constants.COMPLIANCE_RULES;
				var d = $q.defer();
				var req = {
					headers: {
						'Content-Type': 'application/json',
						'Authorization' : Compliance.getCookieVal()
					},
					url: url,
					method: 'POST',
					data:data
				};
				console.log(req);
				$http(req).then(function(reply) {
			     d.resolve(reply.data);
		     
	            }, function(reply) {
	                d.resolve();
	                toaster.pop('error', "Compliance Rules API", "server not responding");
	            });
	            return d.promise;
	
			},
			smelterOrGovernment:function(data){
				
				var url = constants.COMPLIANCE_URL;
			 	var d = $q.defer();
			 	var req = {
			 		headers: {
			 			'Content-Type': 'application/json',
			 			//'Authorization' : 'Basic ' + authData
			 			'Authorization' : Compliance.getCookieVal()
			 		},
			 		url: url,
			 		method: 'POST',
			 		data:data
					
			 	};
			 	$http(req).then(function(reply) {				
			      d.resolve(reply.data);
	             }, function(reply) {
	            	 d.resolve();
	            	 toaster.pop('error', "Compliance Resolve API", "server not responding");
	             });
	             return d.promise;
			},
			getPerform:function(){
				
				var url = constants.COMPLIANCE_PERFORM;
			 	var d = $q.defer();
			 	var req = {
			 		headers: {
			 			'Content-Type': 'application/json',
			 			//'Authorization' : 'Basic ' + authData
			 			'Authorization' : Compliance.getCookieVal()
			 		},
			 		url: url,
			 		method: 'GET'
			 	};
			 	$http(req).then(function(reply) {				
			      d.resolve(reply.data);
	             }, function(reply) {
	            	 d.resolve();
	            	 toaster.pop('error', "Compliance Resolve API", "server not responding");
	             });
	             return d.promise;
			}

       
		};    

		return Compliance;
	}
]);