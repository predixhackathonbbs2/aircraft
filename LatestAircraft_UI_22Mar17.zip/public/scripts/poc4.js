var clusterData;
var airspeedArray;
var verticalAccelartion;
var clusterArray1;
var clusterArray2;
var clusterArray3;
var clusterArray4;
var clusterArray5;



$(document).ready(function () {
	
 
   $("#flightIdPoc4").change(function(){
   jQuery("#errorVaildcluster").text('');
		var flightType='fireFighter';
		var radioButtonid=$('input[name=chartPoc4]:checked').val();
		var numberofRecords=$("#numberofRecodForcluster").val();
		
		if(numberofRecords==0){
		jQuery("#errorVaildcluster").text('please enter number records');
		$("#flightIdPoc4").val(0);
		return false;
		}else{
		$("#loadingChart7").show();
		var flightId=$(this).val();
		loadClusterData(flightId,radioButtonid,flightType,numberofRecords);
	
		}
		
		}); 
		
		
		
		$("#flightIdPoc4DivForCargoFlight").change(function(){
		jQuery("#errorVaildcluster").text('');
			var flightType='cargoFlight';
			var radioButtonid=$('input[name=chartPoc4]:checked').val();
			var numberofRecords=$("#numberofRecodForcluster").val();
			if(numberofRecords==0){
				jQuery("#errorVaildcluster").text('please enter number records');
				$("#flightIdPoc4DivForCargoFlight").val(0);
				return false;
			}else{
				$("#loadingChart7").show();
				var flightId=$(this).val();
				loadClusterData(flightId,radioButtonid,flightType,numberofRecords);
			}
		
		
		});
		
		
		jQuery("input[name='chartPoc4']").click(function() {
			$("#loadingChart7").show();
			var radioButtonid=$('input[name=chartPoc4]:checked').val();
			var fireFighterflighId=$("#flightIdPoc4 option:selected").text();
		    var cargoFlighId=$("#flightIdPoc4DivForCargoFlight option:selected").text();
			
			var numberofRecords=$("#numberofRecodForcluster").val();
			
			if(radioButtonid==4){
		     loadclusterDataFor4clusterFireFighter(fireFighterflighId,radioButtonid,numberofRecords);
			 loadclusterDataFor4cargoFighter(cargoFlighId,radioButtonid,numberofRecords);
			}else if(radioButtonid==5){
				 loadclusterDataFor5clusterFireFighter(fireFighterflighId,radioButtonid,numberofRecords);
			     loadclusterDataFor5cargoFighter(fireFighterflighId,radioButtonid,numberofRecords);
			}else if(radioButtonid==3){
				var flightTypeData=['fireFighter','cargoFlight'];
				loadClusterData(fireFighterflighId,radioButtonid,flightTypeData[0],numberofRecords);
				loadClusterData(cargoFlighId,radioButtonid,flightTypeData[1],numberofRecords);
			}
		
				
		});
		
		
		
   
 });
 
 function loadClusterData(flightId,radioId,flightType,numberofRecords){
 	 var predixurl="https://mfg-regression-cluster-dynamic.run.aws-usw02-pr.ice.predix.io/getClusterAnalyticsWithDataDynamic";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId+"/"+numberofRecords,
                type: "get", //send it through post method
                success: function(responseData) {
				
				clusterData=responseData;
				$("#loadingChart7").hide();
				drawclusterChart(flightType);
			
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
 

 
 
 
  function loadclusterDataFor5clusterFireFighter(flightId,radioId,numberofRecords){
 	 var predixurl="https://mfg-regression-cluster-dynamic.run.aws-usw02-pr.ice.predix.io/getClusterAnalyticsWithDataDynamic";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId+"/"+numberofRecords,
                type: "get", //send it through post method
                success: function(responseData) {
				
				clusterData=responseData;
				$("#loadingChart7").hide();
				drawloadFor5clusterFireFighter(responseData);
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
 
 
 function loadclusterDataFor5cargoFighter(flightId,radioId,numberofRecords){
 	 var predixurl="https://mfg-regression-cluster-dynamic.run.aws-usw02-pr.ice.predix.io/getClusterAnalyticsWithDataDynamic";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId+"/"+numberofRecords,
                type: "get", //send it through post method
                success: function(responseData) {
				clusterData=responseData;
				$("#loadingChart7").hide();
				drawloadFor5clustercargo(responseData);
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
 
 
 function loadclusterDataFor4clusterFireFighter(flightId,radioId,numberofRecords){
 	 var predixurl="https://mfg-regression-cluster-dynamic.run.aws-usw02-pr.ice.predix.io/getClusterAnalyticsWithDataDynamic";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId+"/"+numberofRecords,
                type: "get", //send it through post method
                success: function(responseData) {
				
				clusterData=responseData;
				$("#loadingChart7").hide();
				drawloadFor4clusterFireFighter(responseData);
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
  function loadclusterDataFor4cargoFighter(flightId,radioId,numberofRecords){
   var predixurl="https://mfg-regression-cluster-dynamic.run.aws-usw02-pr.ice.predix.io/getClusterAnalyticsWithDataDynamic";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId+"/"+numberofRecords,
                type: "get", //send it through post method
                success: function(responseData) {
				
				$("#loadingChart7").hide();
				drawloadFor4clustercargo(responseData);
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
  
  
  }
  
  function drawloadFor5clustercargo(responseData){
  
		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		clusterArray4=new Array();
		clusterArray5=new Array();
		var obj = jQuery.parseJSON(responseData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='3'){
		   clusterArray4.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='4'){
		   clusterArray5.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

      	clusterPlot5ForCargo(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
  
  
  }
  
  function drawloadFor5clusterFireFighter(responseData){
		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		clusterArray4=new Array();
		clusterArray5=new Array();
		var obj = jQuery.parseJSON(responseData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='3'){
		   clusterArray4.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='4'){
		   clusterArray5.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

      	clusterPlot5ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
  
  }
  
 
	function drawloadFor4clusterFireFighter(responseData){

		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		clusterArray4=new Array();
		var obj = jQuery.parseJSON(responseData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='3'){
		   clusterArray4.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

      	clusterPlot4ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
	


}
 
 function drawloadFor4clustercargo(responseData){
 	clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		clusterArray4=new Array();
		var obj = jQuery.parseJSON(responseData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='3'){
		   clusterArray4.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

      	clusterPlot4ForCargoFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
 
 }
 
 
 
 function drawclusterChart(flightType){
		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		var obj = jQuery.parseJSON(clusterData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}
	if(flightType=='fireFighter'){
	clusterPlot(clusterArray1,clusterArray2,clusterArray3);
	}
	if(flightType=='cargoFlight'){
	clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3);
	}
		
		
 
 
 
 }
 
 function clusterPlot(clusterArray1,clusterArray2,clusterArray3){
 
	Highcharts.chart('container7', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
        //color: 'rgba(223, 83, 83, .5)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
       // color: 'rgba(223, 83, 83, .5)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
        //color: 'rgba(223, 83, 83, .5)',
        data: clusterArray3

    },
	
	
	]
});

 }
 
  function clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3){
 
	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
        color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
       color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
        color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	
	
	]
});

 }
 
 function clusterPlot4ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4){

 
	Highcharts.chart('container7', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    }
	
	]
});
 
 }
 function clusterPlot4ForCargoFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4){
 
	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    }
	
	]
});

 }
 
 
 function clusterPlot5ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5){
  
	Highcharts.chart('container7', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
    
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    },
	{
        name: 'Cluster5',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray5

    }
	
	]
});

 
 }
  function clusterPlot5ForCargo(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5){
 	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
       name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
       name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    },
	{
        name: 'Cluster5',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray5

    }
	
	]
});

 
 
 }