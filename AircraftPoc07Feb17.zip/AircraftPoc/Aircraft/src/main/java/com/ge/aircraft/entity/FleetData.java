/*
 * Copyright (c) 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
 
package com.ge.aircraft.entity;

/**
 * 
 * @author predix -
 */
import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the FLEET_DATA database table.
 * 
 */
@Entity
@Table(name="FLEET_DATA")
@NamedQuery(name="FleetData.findAll", query="SELECT f FROM FleetData f")
public class FleetData implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="FLEET_DATA_FLEETID_GENERATOR", sequenceName="FLEET_SEQ")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="FLEET_DATA_FLEETID_GENERATOR")
	@Column(name="FLEET_ID")
	private long fleetId;

	private String airspeed;

	@Column(name="ARM_RETARDANT_TANK_DOOR")
	private String armRetardantTankDoor;

	@Column(name="BEACON_START_STOP_RECORDING")
	private String beaconStartStopRecording;

	@Column(name="ELAPSED_TIME")
	private String elapsedTime;

	@Column(name="ELEVATOR_POSITION")
	private String elevatorPosition;

	@Column(name="FLAP_POSITION")
	private String flapPosition;

	@Column(name="GEAR_UP_AND_LOCKED")
	private String gearUpAndLocked;

	@Column(name="LEFT_AILERON_POSITION")
	private String leftAileronPosition;

	@Column(name="PEAK_VALLEY_INDICATOR")
	private String peakValleyIndicator;

	@Column(name="PRESSURE_ALTITUDE")
	private String pressureAltitude;

	@Column(name="RECORD_TYPE")
	private String recordType;

	@Column(name="RETARDANT_DOOR_OPEN")
	private String retardantDoorOpen;

	@Column(name="RETARDANT_TANK_FLOAT")
	private String retardantTankFloat;

	@Column(name="ROLL_ACCELERATION")
	private String rollAcceleration;

	@Column(name="STRAIN_GAUGE_1")
	private String strainGauge1;

	@Column(name="STRAIN_GAUGE_2")
	private String strainGauge2;

	@Column(name="STRAIN_GAUGE_3")
	private String strainGauge3;

	@Column(name="STRAIN_GAUGE_4")
	private String strainGauge4;

	@Column(name="STRAIN_GAUGE_5")
	private String strainGauge5;

	@Column(name="STRAIN_GAUGE_6")
	private String strainGauge6;

	@Column(name="STRAIN_GAUGE_7")
	private String strainGauge7;

	@Column(name="STRAIN_GAUGE_8")
	private String strainGauge8;

	@Column(name="\"TIMESTAMP\"")
	private String timestamp;

	@Column(name="TRIGGER_CHANNEL")
	private String triggerChannel;

	@Column(name="VERTICAL_ACCELERATION")
	private String verticalAcceleration;

	//bi-directional many-to-one association to FlightMaster
	@ManyToOne
	@JoinColumn(name="FLIGHT_ID")
	private FlightMaster flightMaster;

	public FleetData() {
	}

	public long getFleetId() {
		return this.fleetId;
	}

	public void setFleetId(long fleetId) {
		this.fleetId = fleetId;
	}

	public String getAirspeed() {
		return this.airspeed;
	}

	public void setAirspeed(String airspeed) {
		this.airspeed = airspeed;
	}

	public String getArmRetardantTankDoor() {
		return this.armRetardantTankDoor;
	}

	public void setArmRetardantTankDoor(String armRetardantTankDoor) {
		this.armRetardantTankDoor = armRetardantTankDoor;
	}

	public String getBeaconStartStopRecording() {
		return this.beaconStartStopRecording;
	}

	public void setBeaconStartStopRecording(String beaconStartStopRecording) {
		this.beaconStartStopRecording = beaconStartStopRecording;
	}

	public String getElapsedTime() {
		return this.elapsedTime;
	}

	public void setElapsedTime(String elapsedTime) {
		this.elapsedTime = elapsedTime;
	}

	public String getElevatorPosition() {
		return this.elevatorPosition;
	}

	public void setElevatorPosition(String elevatorPosition) {
		this.elevatorPosition = elevatorPosition;
	}

	public String getFlapPosition() {
		return this.flapPosition;
	}

	public void setFlapPosition(String flapPosition) {
		this.flapPosition = flapPosition;
	}

	public String getGearUpAndLocked() {
		return this.gearUpAndLocked;
	}

	public void setGearUpAndLocked(String gearUpAndLocked) {
		this.gearUpAndLocked = gearUpAndLocked;
	}

	public String getLeftAileronPosition() {
		return this.leftAileronPosition;
	}

	public void setLeftAileronPosition(String leftAileronPosition) {
		this.leftAileronPosition = leftAileronPosition;
	}

	public String getPeakValleyIndicator() {
		return this.peakValleyIndicator;
	}

	public void setPeakValleyIndicator(String peakValleyIndicator) {
		this.peakValleyIndicator = peakValleyIndicator;
	}

	public String getPressureAltitude() {
		return this.pressureAltitude;
	}

	public void setPressureAltitude(String pressureAltitude) {
		this.pressureAltitude = pressureAltitude;
	}

	public String getRecordType() {
		return this.recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getRetardantDoorOpen() {
		return this.retardantDoorOpen;
	}

	public void setRetardantDoorOpen(String retardantDoorOpen) {
		this.retardantDoorOpen = retardantDoorOpen;
	}

	public String getRetardantTankFloat() {
		return this.retardantTankFloat;
	}

	public void setRetardantTankFloat(String retardantTankFloat) {
		this.retardantTankFloat = retardantTankFloat;
	}

	public String getRollAcceleration() {
		return this.rollAcceleration;
	}

	public void setRollAcceleration(String rollAcceleration) {
		this.rollAcceleration = rollAcceleration;
	}

	public String getStrainGauge1() {
		return this.strainGauge1;
	}

	public void setStrainGauge1(String strainGauge1) {
		this.strainGauge1 = strainGauge1;
	}

	public String getStrainGauge2() {
		return this.strainGauge2;
	}

	public void setStrainGauge2(String strainGauge2) {
		this.strainGauge2 = strainGauge2;
	}

	public String getStrainGauge3() {
		return this.strainGauge3;
	}

	public void setStrainGauge3(String strainGauge3) {
		this.strainGauge3 = strainGauge3;
	}

	public String getStrainGauge4() {
		return this.strainGauge4;
	}

	public void setStrainGauge4(String strainGauge4) {
		this.strainGauge4 = strainGauge4;
	}

	public String getStrainGauge5() {
		return this.strainGauge5;
	}

	public void setStrainGauge5(String strainGauge5) {
		this.strainGauge5 = strainGauge5;
	}

	public String getStrainGauge6() {
		return this.strainGauge6;
	}

	public void setStrainGauge6(String strainGauge6) {
		this.strainGauge6 = strainGauge6;
	}

	public String getStrainGauge7() {
		return this.strainGauge7;
	}

	public void setStrainGauge7(String strainGauge7) {
		this.strainGauge7 = strainGauge7;
	}

	public String getStrainGauge8() {
		return this.strainGauge8;
	}

	public void setStrainGauge8(String strainGauge8) {
		this.strainGauge8 = strainGauge8;
	}

	public String getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getTriggerChannel() {
		return this.triggerChannel;
	}

	public void setTriggerChannel(String triggerChannel) {
		this.triggerChannel = triggerChannel;
	}

	public String getVerticalAcceleration() {
		return this.verticalAcceleration;
	}

	public void setVerticalAcceleration(String verticalAcceleration) {
		this.verticalAcceleration = verticalAcceleration;
	}

	public FlightMaster getFlightMaster() {
		return this.flightMaster;
	}

	public void setFlightMaster(FlightMaster flightMaster) {
		this.flightMaster = flightMaster;
	}

}
