/*
 * Copyright (c) 2017 General Electric Company. All rights reserved.
 *
 * The copyright to the computer software herein is the property of
 * General Electric Company. The software may be used and/or copied only
 * with the written permission of General Electric Company or in accordance
 * with the terms and conditions stipulated in the agreement/contract
 * under which the software has been supplied.
 */
 
package com.ge.aircraft.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ge.aircraft.entity.FleetData;

/**
 * 
 * @author predix -
 */
public interface IFlightFleetRepository extends JpaRepository<FleetData, Long>{
	

	/*String GET_FLIGHT_DETAILS = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId  and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3 and a.triggerChannel=?4 and a.timestamp between ?5 and ?6 ";
*/
	
	String GET_FLIGHT_DETAILS = "select a.fleetId,a.airspeed,a.armRetardantTankDoor,a.beaconStartStopRecording,a.elapsedTime,a.elevatorPosition,"
			+ "a.flapPosition,a.gearUpAndLocked,a.leftAileronPosition,a.peakValleyIndicator,a.pressureAltitude,a.recordType,a.retardantDoorOpen,"
			+ "a.retardantTankFloat,a.rollAcceleration,a.strainGauge1,a.strainGauge2,a.strainGauge3,a.strainGauge4,a.strainGauge5,a.strainGauge6,"
			+ "a.strainGauge7,a.strainGauge8,a.timestamp,a.triggerChannel,a.verticalAcceleration,b.startDate,b.startTime,b.flightId from FleetData a,"
			+ "FlightMaster b where a.flightMaster.flightId = b.flightId ";
	//List<FlightMaster> findByStartDate(String startdate);

	/*@Query(GET_FLIGHT_DETAILS)
	List<Object[]> getFlightDetails(@Param("startDate")  String startDate, @Param("startTime")  String startTime,
			@Param("recordType")  String recordType, @Param("triggerChannel") String triggerChannel,  @Param("startTimes")  String startTimes,
			 @Param("endTime")  String endTime);*/
	
	@Query(GET_FLIGHT_DETAILS + " and a.flightMaster.startDate=?1 and a.flightMaster.startTime=?2 and a.recordType=?3 and a.triggerChannel=?4 and a.timestamp between ?5 and ?6")
	List<Object[]> getFlightDetails(String flightDate, String flightTime,
			String recordType, String triggerChannel, String startTime,
			String endTime);

	@Query(GET_FLIGHT_DETAILS)
	List<Object[]> getFlightDetailss();


}
