var app = angular.module('supplierApp', ['ui.router', 'ngAnimate', 'toaster', 'ngCookies', 'ui.select', 'ngSanitize', 'ui.bootstrap','am.multiselect','googlechart', 'CustomDropdownSelect']);

app.run(['$state', '$rootScope', '$stateParams', '$location', '$cookies', '$http',
    function($state, $rootScope, $stateParams, $location, $cookies, $http) {

        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;
        $rootScope.$on('$stateChangeStart', function(event, next, nextparams,
            current, currentparams) {
            //var favoriteCookie = $cookies['sc_token'];
            //$http.defaults.headers.common['Authorization'] = favoriteCookie;
            $("body,html").animate({
                scrollTop: 0
            }, "slow");
        });
    }
]);

app.config(['$stateProvider', '$urlRouterProvider',
    function($stateProvider, $urlRouterProvider) {

        $urlRouterProvider.otherwise('/home');
        $stateProvider.state('login', {
                url: '/login',
                templateUrl: 'js/views/login.html',
                controller: 'signInController'
            }).state('homePage', {
                url: '/home',
                templateUrl: 'js/views/homePage.html',
                controller: 'homeController'
			}).state('invoice', {
                url: '/invoice',
                templateUrl: 'js/views/invoice.html',
			 }).state('payment', {
                url: '/payment',
                templateUrl: 'js/views/payment.html',
               // controller: 'dashboardController'
            }).state('dashboard', {
                url: '/dashboard',
                templateUrl: 'js/views/dashboard.html',
                controller: 'dashboardController'
            }).state('homePreference', {
                url: '/home/:preference',
                templateUrl: 'js/views/homePage.html',
                controller: 'homeController'
            }).state('supplierInfo', {
                url: '/supplierInfo',
                templateUrl: 'js/views/supplierInfo.html',
                controller: 'supplierController'
            }).state('businessInfo', {
                url: '/businessInfo',
                templateUrl: 'js/views/businessInfo.html',
                controller: 'businessController'
            }).state('poSettings', {
                url: '/poSettings',
                templateUrl: 'js/views/PO-settings.html',
                controller: 'poSettingsController'
            }).state('compliance', {
                url: '/compliance',
                templateUrl: 'js/views/compliance.html',
                controller: 'complianceController'
                    //			,
                    //		resolve : {
                    //			complianceDetails : [ 'Compliance', function(Compliance) {
                    //				var promise = Compliance.getComplianceDetails();
                    //				promise.then(function() {
                    //				});
                    //				return promise;
                    //			} ]
                    //		}
            }).state('invitation', {
                url: '/invitation',
                templateUrl: 'js/views/SupplierInvitation.html',
                controller: 'invitationController'
                    // }).state('home', {
                    // 	url : '/',
                    // 	templateUrl : 'js/views/login.html',
                    // 	controller : 'signInController'
            }).state('error', {
                url: '/error',
                templateUrl: 'js/views/error.html',
            }).state('noaccess', {
                url: '/noaccess',
                templateUrl: 'js/views/no-access.html',
            }).state('supplierHome', {
                url: '/onboarding/supplierHome',
                templateUrl: 'js/views/onboarding/supplierHome.html',
                controller: 'onboardingHomeController'
            })/* .state('supplierDashboard', {
                url: '/onboarding/supplierDashboard',
                templateUrl: 'js/views/onboarding/supplierDashboard.html',
                controller: 'supplierDashboardController'
            }) */.state('supplierProfileAddress', {
                url: '/onboarding/supplierProfileAddress',
                controller: 'onboardingProfileAddress',
                templateUrl: 'js/views/onboarding/supplierProfileAddress.html',
            }).state('supplierProfileBank', {
                url: '/onboarding/supplierProfileBank',
                templateUrl: 'js/views/onboarding/supplierProfileBank.html',
                controller: 'onboardingProfileBank'
            }).state('test-upload', {
                url: '/onboarding/testupload',
                templateUrl: 'js/views/onboarding/testupload.html',
                controller: 'testOnboardingProfileBank'
            }).state('supplierProfileCompany', {
                url: '/onboarding/supplierProfileCompany',
                templateUrl: 'js/views/onboarding/supplierProfileCompany.html',
                controller: 'onboardingSupplierProfileCompanyController'
            }).state('supplierProfileContacts', {
                url: '/onboarding/supplierProfileContacts',
                templateUrl: 'js/views/onboarding/supplierProfileContacts.html',
                controller: 'onboardingSupplierProfileContactsController'

            }).state('supplierProfileDiversity', {
                url: '/onboarding/supplierProfileDiversity',
                templateUrl: 'js/views/onboarding/supplierProfileDiversity.html',
                controller: 'onboardingSupplierProfileDiversityController',

            }).state('supplierProfileDueDiligence', {
                url: '/onboarding/supplierProfileDueDiligence',
                templateUrl: 'js/views/onboarding/supplierProfileDueDiligence.html',
                controller: 'onboardingSupplierProfileDiligenceController',

            }).state('supplierReview', {
                url: '/onboarding/supplierReview',
                templateUrl: 'js/views/onboarding/supplierReview.html',
                controller: 'onboardingSupplierProfileReviewController'

            }).state('supplierCongrats', {
				controller: 'congratsController',
                url: '/onboarding/supplierCongrats',
                templateUrl: 'js/views/onboarding/supplierCongrats.html'

            }).state('supplierSearch', {
                url: '/search',
                params: {
                    query: null,
                    activeSearch:null,
                },
                controller: 'searchController',
                templateUrl: 'js/views/onboarding/search.html',
				resolve: searchController.resolve

            }).state('supplierTerms', {
                url: '/terms',
                controller: 'termsController',
                templateUrl: 'js/views/terms.html'

            }).state('geTerms', {
                url: '/geterms',
                controller: 'getermsController',
                templateUrl: 'js/views/geterms.html'

            }).state('knowledgeBase', {
                url: '/knowledgeBase',
                //controller: 'knowledgeBase',
                templateUrl: 'js/views/knowledgeBase.html'
            }).state('entityVerification', {
                url: '/entityVerification',
                templateUrl: 'js/views/entityVerification.html',
                controller: 'entityVerificationController'

            }).state('myData', {
                url: '/myData',
                templateUrl: 'js/views/myData.html',
                controller: 'myDataController',
				resolve: myDataController.resolve

            }).state('subscribe', {
                url: '/subscribe',
                params: {
                    obj: null,
                    supplierSubscribingTo: null,
                    activeSearch:null
                },
                controller: 'subscribeController',
                templateUrl: 'js/views/onboarding/subscribe.html'
            });
    }
]);
