 $(document).ready(function () {
	 
	
	 
	 $("#homeID").click(function(){
		 $("#mainPageDispaly").show();
		$("#poc1ID").hide();
	 });
	 
	 $("#poc4IDclick").click(function(){
		 //$("#mainPageDispaly").show();
		 $("#poc1ID").hide();
		 $("#mainPageDispaly").hide();
		 $("#singleParameterChart").hide();
	$("#crossParameterChart").hide();
	$("#stripChartForMulti").hide();
	$("#rightParameterMultiData").hide();
	$("#leftParameterMultiData").hide();
		$("#snippetForMultiparameter").hide();
	 });
	 
	  $("#poc3IDclick").click(function(){
		 //$("#mainPageDispaly").show();
		 $("#poc1ID").hide();
		  $("#mainPageDispaly").hide();
		  $("#singleParameterChart").hide();
	$("#crossParameterChart").hide();
	$("#stripChartForMulti").hide();
	$("#rightParameterMultiData").hide();
	$("#leftParameterMultiData").hide();
	$("#snippetForMultiparameter").hide();
	 });
	 
	  $("#poc5IDclick").click(function(){
		 //$("#mainPageDispaly").show();
		 $("#poc1ID").hide();
		  $("#mainPageDispaly").hide();
		  $("#singleParameterChart").hide();
	$("#crossParameterChart").hide();
	$("#stripChartForMulti").hide();
	$("#rightParameterMultiData").hide();
	$("#leftParameterMultiData").hide();
	//$('select.SlectBox')[0].sumo.unSelectAll();
	//$('select.SlectBox5')[0].sumo.unSelectAll();
	$("#snippetForMultiparameter").hide();
	 });
	 
	 $("#poc6IDclick").click(function(){
		 //$("#mainPageDispaly").show();
		 $("#poc1ID").hide();
		  $("#mainPageDispaly").hide();
		  $("#singleParameterChart").hide();
	$("#crossParameterChart").hide();
	$("#stripChartForMulti").hide();
	$("#rightParameterMultiData").hide();
	$("#leftParameterMultiData").hide();
	$("#snippetForMultiparameter").hide();
	 });
	 
	
	 
	  $("#poc1IDclick").click(function(){
		
		  $("#mainPageDispaly").hide();
	 });
	 
	 
	 
	 $("#loginId").click(function(){
		 
		$("#home").hide();
		
		$("#mainPageDispaly").show();
		 
	 });
	 
	 
	 $("#homecontainer" ).highcharts({
        title: {
            text: ""
        },
		    chart: {
        type: 'pie',
        options3d: {
            enabled: true,
            alpha: 45,
            beta: 0
        }
    },
        tooltip: {
            enabled: false
        },
			annotationsOptions: {
            enabledButtons: false   
        },
        plotOptions: {
            pie: {
                allowPointSelect: true,
                cursor: "pointer",
                dataLabels: {
                    enabled: true,
                    distance: -75,
                    color: "white"
                }
            },
            series: {
                allowPointSelect: true,
                point: {
                    events: {
                        select: function() {}
                    }
                }
            }
        },
		exporting: { enabled: false },
        series: [ {
            type: "pie",
            data: [
                {
                    name: "Structures<br>.Flight Segmentation<br>.Regression Analysis<br>.Cluster Analysis<br>.Rainflow Analysis",
                    color: "#3b62a0",
                    y: 40,
					 sliced: true,
					selected: true,
					events: {
                                    click: function() {
                                            //location.href = this.options.url;
											
											$("#mainPageDispaly").hide();
											$("#headerTabId").show();
											$("#poc1ID").show();
											$("#poc1IDclick").click();
											
                                        }
                                }
					   
					
                },
                {
                    name: "Engine<br>.EGT Analysis<br>.shutdowns",
                    color: "#5893c4",
                    y: 30
                },
                {
                    name: "Avionics<br>.Fly By Wire performance<br>.Nav Aids performance",
                    color: "#5893c4",
                    y: 30
                },
                {
                    name: "Hydraulics<br>.Particle Analysis<br>.Heat Analysis",
                    color:  "#5893c4",
                    y: 20
                },
                {
                    name: "Brakes<br>.Wear prediction",
                    color:  "#5893c4",
                    y: 20
                }
            ]
        } ]
    } );
	 

	 
	 
 });