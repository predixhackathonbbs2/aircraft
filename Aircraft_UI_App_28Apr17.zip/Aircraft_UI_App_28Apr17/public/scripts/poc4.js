var clusterData;
var airspeedArray;
var verticalAccelartion;
var clusterArray1;
var clusterArray2;
var clusterArray3;
var clusterArray4;
var clusterArray5;

var fireFlightMaxRange = '';
var cargoFlightMaxRange='';
var yasixToRangeMax = '';


$(document).ready(function () {
	
 
   $("#flightIdPoc4").change(function(){
	jQuery("#errorVaildcluster").text('');
		var flightType='fireFighter';
		var radioButtonid=$('input[name=chartPoc4]:checked').val();
		
		
	
	//	$("#loadingChart7").show();
		var flightId=$(this).val();
	//	loadClusterData(flightId,radioButtonid,flightType);
	
	//if-else added by Bhanu
		if(flightId == 0){
			$("#loadingChart7").hide();
			$("#container7").hide();
			
		}else{
           $("#loadingChart7").show();
		   $("#container7").show();
		 
		 
		
		if(radioButtonid==4){
		     loadclusterDataFor4clusterFireFighter(flightId,radioButtonid);
			// loadclusterDataFor4cargoFighter(flightId,radioButtonid);
			}else if(radioButtonid==5){
				 loadclusterDataFor5clusterFireFighter(flightId,radioButtonid);
			     //loadclusterDataFor5cargoFighter(flightId,radioButtonid);
			}else if(radioButtonid==3){
				var flightTypeData=['fireFighter','cargoFlight'];
				loadClusterData(flightId,radioButtonid,flightTypeData[0]);
				//loadClusterData(flightId,radioButtonid,flightTypeData[1]);
			 
		}
		 
		 
		 
		 
		   
		  // loadClusterData(flightId,radioButtonid,flightType);
		}
	
		
		
		}); 
		
		
		
		$("#flightIdPoc4DivForCargoFlight").change(function(){
			jQuery("#errorVaildcluster").text('');
			var flightType='cargoFlight';
			var radioButtonid=$('input[name=chartPoc4]:checked').val();
			var flightId1=$(this).val();
			
		
				//$("#loadingChart7").show();
				//loadClusterData(flightId1,radioButtonid,flightType);
				
				//if-else added by Bhanu
				if(flightId1 == 0){
				    $("#loadingChart7").hide();
					$("#container8").hide();
				}else{
				    $("#loadingChart7").show(); 
					$("#container8").show();
				   // loadClusterData(flightId1,radioButtonid,flightType);
				   if(radioButtonid==4){
						//loadclusterDataFor4clusterFireFighter(flightId,radioButtonid);
						 loadclusterDataFor4cargoFighter(flightId1,radioButtonid);
					}else if(radioButtonid==5){
					//loadclusterDataFor5clusterFireFighter(flightId,radioButtonid);
			     loadclusterDataFor5cargoFighter(flightId1,radioButtonid);
					}else if(radioButtonid==3){
						var flightTypeData=['fireFighter','cargoFlight'];
						//loadClusterData(flightId,radioButtonid,flightTypeData[0]);
				loadClusterData(flightId1,radioButtonid,flightTypeData[1]);
			 
				}
				   
				   
				   
				}
				
			
		
		
		});
		
		
		jQuery("input[name='chartPoc4']").click(function() {
			var radioButtonid=$('input[name=chartPoc4]:checked').val();
			var fireFighterflighId=$("#flightIdPoc4 option:selected").val();
		    var cargoFlighId=$("#flightIdPoc4DivForCargoFlight option:selected").val();
			
					
			
			$("#loadingChart7").show();
			if(radioButtonid==4){
		     loadclusterDataFor4clusterFireFighter(fireFighterflighId,radioButtonid);
			 loadclusterDataFor4cargoFighter(cargoFlighId,radioButtonid);
			}else if(radioButtonid==5){
				 loadclusterDataFor5clusterFireFighter(fireFighterflighId,radioButtonid);
			     loadclusterDataFor5cargoFighter(cargoFlighId,radioButtonid);
			}else if(radioButtonid==3){
				var flightTypeData=['fireFighter','cargoFlight'];
				loadClusterData(fireFighterflighId,radioButtonid,flightTypeData[0]);
				loadClusterData(cargoFlighId,radioButtonid,flightTypeData[1]);
			}
		
				
		});
		
		
		
   
 });
 
 function loadClusterData(flightId,radioId,flightType){

 	 var predixurl="https://mfg-regression-cluster-dynamic.run.aws-usw02-pr.ice.predix.io/getClusterAnalytics1";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId,
                type: "get", //send it through post method
                success: function(responseData) {
				
				clusterData=responseData;
				$("#loadingChart7").hide();
				//drawclusterChart(flightType);
				if(flightType=='fireFighter'){
	               drawclusterChart(flightType);
	            }
	            if(flightType=='cargoFlight'){
				  drawclusterChartForCargoFlight(flightType);
				}
			
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
 

 
 
 
  function loadclusterDataFor5clusterFireFighter(flightId,radioId){
 	 var predixurl="https://mfg-regression-cluster-dynamic.run.aws-usw02-pr.ice.predix.io/getClusterAnalytics1";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId,
                type: "get", //send it through post method
                success: function(responseData) {
				
				clusterData=responseData;
				$("#loadingChart7").hide();
				drawloadFor5clusterFireFighter(responseData);
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
 
 
 function loadclusterDataFor5cargoFighter(flightId,radioId){
 	 var predixurl="https://mfg-regression-cluster-dynamic.run.aws-usw02-pr.ice.predix.io/getClusterAnalytics1";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId,
                type: "get", //send it through post method
                success: function(responseData) {
				clusterData=responseData;
				$("#loadingChart7").hide();
				drawloadFor5clustercargo(responseData);
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
 
 
 function loadclusterDataFor4clusterFireFighter(flightId,radioId){
 	 var predixurl="https://mfg-regression-cluster-dynamic.run.aws-usw02-pr.ice.predix.io/getClusterAnalytics1";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId,
                type: "get", //send it through post method
                success: function(responseData) {
				
				clusterData=responseData;
				$("#loadingChart7").hide();
				drawloadFor4clusterFireFighter(responseData);
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
  function loadclusterDataFor4cargoFighter(flightId,radioId){
   var predixurl="https://mfg-regression-cluster-dynamic.run.aws-usw02-pr.ice.predix.io/getClusterAnalytics1";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId,
                type: "get", //send it through post method
                success: function(responseData) {
				
				$("#loadingChart7").hide();
				drawloadFor4clustercargo(responseData);
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
  
  
  }
  
  function drawloadFor5clustercargo(responseData){
  
		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		clusterArray4=new Array();
		clusterArray5=new Array();
		var obj = jQuery.parseJSON(responseData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='3'){
		   clusterArray4.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='4'){
		   clusterArray5.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

      	//clusterPlot5ForCargo(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
		var flightId = document.getElementById('flightIdPoc4').value;
	    //alert(flightId);
	    var cargoFlightId = document.getElementById('flightIdPoc4DivForCargoFlight').value;
	    //alert("Cargo ... " + cargoFlightId);
	
	
	/*if(flightType=='fireFighter'){
	  fireFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	  clusterPlot(clusterArray1,clusterArray2,clusterArray3,fireFlightMaxRange);
	}*/
	//cargoFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	if(cargoFlightId!=0 && flightId==0){
	  
	  clusterPlot5ForCargo(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
	}
	
	if(flightId!=0 && cargoFlightId!= 0){
	     //alert(fireFlightMaxRange + " @@@@@  " + cargoFlightMaxRange);
		 if(cargoFlightMaxRange == ''){
		    clusterPlot5ForCargo(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
		 }
	    if(fireFlightMaxRange > cargoFlightMaxRange){
	       yasixToRangeMax = fireFlightMaxRange;
		   clusterPlot5ForCargoAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5,yasixToRangeMax);
		 //  loadClusterData(flightId,3,'fireFighter');
	    }else{
	       yasixToRangeMax = cargoFlightMaxRange;
		   clusterPlot5ForCargoAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5,yasixToRangeMax);
		   loadclusterDataFor5clusterFireFighter(flightId,5);
	    }

	}
  
  
  }
  
  function drawloadFor5clusterFireFighter(responseData){
		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		clusterArray4=new Array();
		clusterArray5=new Array();
		var obj = jQuery.parseJSON(responseData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='3'){
		   clusterArray4.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='4'){
		   clusterArray5.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

      	//clusterPlot5ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
		
		var flightId = document.getElementById('flightIdPoc4').value;
	    //alert(flightId);
	    var cargoFlightId = document.getElementById('flightIdPoc4DivForCargoFlight').value;
	    //alert("Cargo ... " + cargoFlightId);
	
	
//	fireFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	if(flightId!=0 && cargoFlightId==0){
	  
	  clusterPlot5ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
	}
	/*if(flightType=='cargoFlight'){
	  cargoFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	  clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3,cargoFlightMaxRange);
	}*/
	
    
	if(flightId!=0 && cargoFlightId!=0){
	 //    alert(fireFlightMaxRange + " @@@@@  " + cargoFlightMaxRange);
		 if(fireFlightMaxRange == ''){
              clusterPlot5ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5);
		 }
	    if(fireFlightMaxRange > cargoFlightMaxRange){
	       yasixToRangeMax = fireFlightMaxRange;
		   clusterPlot5ForFireFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5,yasixToRangeMax);
		   loadclusterDataFor5cargoFighter(cargoFlightId,5);
	    }else{
	       yasixToRangeMax = cargoFlightMaxRange;
		   clusterPlot5ForFireFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5,yasixToRangeMax);
		  // loadClusterData(cargoFlightId,3,'cargoFlight');
	    }

	}
 
	
  
  }
  
 
	function drawloadFor4clusterFireFighter(responseData){

		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		clusterArray4=new Array();
		var obj = jQuery.parseJSON(responseData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='3'){
		   clusterArray4.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

      	//clusterPlot4ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
		
			var flightId = document.getElementById('flightIdPoc4').value;
	//alert(flightId);
	var cargoFlightId = document.getElementById('flightIdPoc4DivForCargoFlight').value;
	//alert("Cargo ... " + cargoFlightId);
	
	
//	fireFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	if(flightId!=0 && cargoFlightId==0){
	  
	  clusterPlot4ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
	}
	/*if(flightType=='cargoFlight'){
	  cargoFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	  clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3,cargoFlightMaxRange);
	}*/
	
    
	if(flightId!=0 && cargoFlightId!=0){
	//     alert(fireFlightMaxRange + " @@@@@  " + cargoFlightMaxRange);
		 if(fireFlightMaxRange == ''){
              clusterPlot4ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
		 }
	    if(fireFlightMaxRange > cargoFlightMaxRange){
	       yasixToRangeMax = fireFlightMaxRange;
		   clusterPlot4ForFireFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,yasixToRangeMax);
		   loadclusterDataFor4cargoFighter(cargoFlightId,4);
	    }else{
	       yasixToRangeMax = cargoFlightMaxRange;
		   clusterPlot4ForFireFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,yasixToRangeMax);
		  // loadClusterData(cargoFlightId,3,'cargoFlight');
	    }

	}
 
	


}
 
 function drawloadFor4clustercargo(responseData){
 	clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		clusterArray4=new Array();
		var obj = jQuery.parseJSON(responseData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='3'){
		   clusterArray4.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}

//clusterPlot4ForCargoFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
	var flightId = document.getElementById('flightIdPoc4').value;
	//alert(flightId);
	var cargoFlightId = document.getElementById('flightIdPoc4DivForCargoFlight').value;
	//alert("Cargo ... " + cargoFlightId);
	
	
	/*if(flightType=='fireFighter'){
	  fireFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	  clusterPlot(clusterArray1,clusterArray2,clusterArray3,fireFlightMaxRange);
	}*/
	//cargoFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	if(cargoFlightId!=0 && flightId==0){
	  
	  clusterPlot4ForCargoFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
	}
	
	if(flightId!=0 && cargoFlightId!= 0){
	//     alert(fireFlightMaxRange + " @@@@@  " + cargoFlightMaxRange);
		 if(cargoFlightMaxRange == ''){
		    clusterPlot4ForCargoFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4);
		 }
	    if(fireFlightMaxRange > cargoFlightMaxRange){
	       yasixToRangeMax = fireFlightMaxRange;
		   clusterPlot4ForCargoFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,yasixToRangeMax);
		 //  loadClusterData(flightId,3,'fireFighter');
	    }else{
	       yasixToRangeMax = cargoFlightMaxRange;
		   clusterPlot4ForCargoFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,yasixToRangeMax);
		   loadclusterDataFor4clusterFireFighter(flightId,4);
	    }

	}
 
 }
 
 
 
 function drawclusterChart(flightType){
		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		var obj = jQuery.parseJSON(clusterData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}
	/*Array.prototype.max = function() {
                return Math.max.apply(null, this);
            };
 
    Array.prototype.min = function() {
                return Math.min.apply(null, this);
           };
   */ 
	
	var flightId = document.getElementById('flightIdPoc4').value;
	//alert(flightId);
	var cargoFlightId = document.getElementById('flightIdPoc4DivForCargoFlight').value;
	//alert("Cargo ... " + cargoFlightId);
	
	
//	fireFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	if(flightType=='fireFighter' && cargoFlightId==0){
	  
	  clusterPlot(clusterArray1,clusterArray2,clusterArray3);
	}
	/*if(flightType=='cargoFlight'){
	  cargoFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	  clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3,cargoFlightMaxRange);
	}*/
	
    
	if(flightId!=0 && cargoFlightId!=0){
//alert(fireFlightMaxRange + " @@@@@  " + cargoFlightMaxRange);
		 if(fireFlightMaxRange == ''){
		    clusterPlot(clusterArray1,clusterArray2,clusterArray3);
		 }
	    if(fireFlightMaxRange > cargoFlightMaxRange){
	       yasixToRangeMax = fireFlightMaxRange;
		   clusterPlotAgain(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax);
		   loadClusterData(cargoFlightId,3,'cargoFlight');
	    }else{
	       yasixToRangeMax = cargoFlightMaxRange;
		   clusterPlotAgain(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax);
		  // loadClusterData(cargoFlightId,3,'cargoFlight');
	    }

	   // clusterPlot(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax);
	  //  clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax);
	}
 
 
 
 }
  
 function drawclusterChartForCargoFlight(flightType){
		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		var obj = jQuery.parseJSON(clusterData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}
	/*Array.prototype.max = function() {
                return Math.max.apply(null, this);
            };
 
    Array.prototype.min = function() {
                return Math.min.apply(null, this);
           };
    */
	
	var flightId = document.getElementById('flightIdPoc4').value;
	//alert(flightId);
	var cargoFlightId = document.getElementById('flightIdPoc4DivForCargoFlight').value;
	//alert("Cargo ... " + cargoFlightId);
	
	
	/*if(flightType=='fireFighter'){
	  fireFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	  clusterPlot(clusterArray1,clusterArray2,clusterArray3,fireFlightMaxRange);
	}*/
	//cargoFlightMaxRange = parseFloat(obj.verticalAcceleration.max());
	if(flightType=='cargoFlight' && flightId==0){
	  
	  clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3);
	}
	
	if(flightId!=0 && cargoFlightId!= 0){
	//     alert(fireFlightMaxRange + " @@@@@  " + cargoFlightMaxRange);
		 if(cargoFlightMaxRange == ''){
		    clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3);
		 }
	    if(fireFlightMaxRange > cargoFlightMaxRange){
	       yasixToRangeMax = fireFlightMaxRange;
		   clusterPlotForCargoFlightAgain(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax);
		 //  loadClusterData(flightId,3,'fireFighter');
	    }else{
	       yasixToRangeMax = cargoFlightMaxRange;
		   clusterPlotForCargoFlightAgain(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax);
		   loadClusterData(flightId,3,'fireFighter');
	    }

	  //  clusterPlot(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax);
	    //clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax);
	}
 
 
 
 }
 
 function clusterPlot(clusterArray1,clusterArray2,clusterArray3){
    Highcharts.chart('container7', {
	
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
        //color: 'rgba(223, 83, 83, .5)',
        //data: clusterArray1
		data: clusterArray3

    },
	{
        name: 'Cluster2',
       // color: 'rgba(223, 83, 83, .5)',
//data: clusterArray2
		data: clusterArray1

    },
	{
        name: 'Cluster3',
        //color: 'rgba(223, 83, 83, .5)',
        //data: clusterArray3
		data: clusterArray2

    },
	
	
	]
});

       var chart = $('#container7').highcharts();
       fireFlightMaxRange = chart.yAxis[0].max;
//	   alert(fireFlightMaxRange);

 }
 
 function clusterPlotAgain(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax){
    Highcharts.chart('container7', {
	
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
	    max:  yasixToRangeMax,
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
        //color: 'rgba(223, 83, 83, .5)',
        //data: clusterArray1
		data: clusterArray3

    },
	{
        name: 'Cluster2',
       // color: 'rgba(223, 83, 83, .5)',
//data: clusterArray2
		data: clusterArray1

    },
	{
        name: 'Cluster3',
        //color: 'rgba(223, 83, 83, .5)',
        //data: clusterArray3
		data: clusterArray2

    },
	
	
	]
});

       var chart = $('#container7').highcharts();
       fireFlightMaxRange = chart.yAxis[0].max;
	//   alert(fireFlightMaxRange);

 }
 
  function clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3){
 
	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        //data: clusterArray1
		data: clusterArray3

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        //data: clusterArray2
		data: clusterArray1

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        //data: clusterArray3
		data: clusterArray2

    },
	
	
	]
});

       var chart = $('#container8').highcharts();
       cargoFlightMaxRange = chart.yAxis[0].max;
	//   alert(cargoFlightMaxRange);

 }
 function clusterPlotForCargoFlightAgain(clusterArray1,clusterArray2,clusterArray3,yasixToRangeMax){
 
	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
	    max:  yasixToRangeMax,
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        //data: clusterArray1
		data: clusterArray3

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        //data: clusterArray2
		data: clusterArray1

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        //data: clusterArray3
		data: clusterArray2

    },
	
	
	]
});

       var chart = $('#container8').highcharts();
       cargoFlightMaxRange = chart.yAxis[0].max;
	//   alert(cargoFlightMaxRange);

 }
 
 function clusterPlot4ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4){

 
	Highcharts.chart('container7', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    }
	
	]
});
 var chart = $('#container7').highcharts();
       fireFlightMaxRange = chart.yAxis[0].max;
	//   alert(fireFlightMaxRange);
 }
 
  function clusterPlot4ForFireFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,yasixToRangeMax){

 
	Highcharts.chart('container7', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
	     max:  yasixToRangeMax,
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    }
	
	]
});
 var chart = $('#container7').highcharts();
       fireFlightMaxRange = chart.yAxis[0].max;
	//   alert(fireFlightMaxRange);
 }
 function clusterPlot4ForCargoFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4){
 
	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    }
	
	]
});
var chart = $('#container8').highcharts();
       cargoFlightMaxRange = chart.yAxis[0].max;
	//   alert(cargoFlightMaxRange);
 }
function clusterPlot4ForCargoFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,yasixToRangeMax){
 
	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
	 max:  yasixToRangeMax,
        title: {
            text: 'Vertical Acceleartion'
        }
    },
   
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    }
	
	]
});
var chart = $('#container8').highcharts();
       cargoFlightMaxRange = chart.yAxis[0].max;
	//   alert(cargoFlightMaxRange);
 }
 
 
 function clusterPlot5ForFireFlight(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5){
      
	Highcharts.chart('container7', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
    
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    },
	{
        name: 'Cluster5',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray5

    }
	
	]
});
 var chart = $('#container7').highcharts();
       fireFlightMaxRange = chart.yAxis[0].max;
	//   alert(fireFlightMaxRange);
 
 }
 function clusterPlot5ForFireFlightAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5,yasixToRangeMax){
      
	Highcharts.chart('container7', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
	 max:  yasixToRangeMax,
        title: {
            text: 'Vertical Acceleartion'
        }
    },
    
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    },
	{
        name: 'Cluster5',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray5

    }
	
	]
});
 var chart = $('#container7').highcharts();
       fireFlightMaxRange = chart.yAxis[0].max;
	//   alert(fireFlightMaxRange);
 
 }
  function clusterPlot5ForCargo(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5){
 	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
       name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
       name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    },
	{
        name: 'Cluster5',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray5

    }
	
	]
});

 var chart = $('#container8').highcharts();
       cargoFlightMaxRange = chart.yAxis[0].max;
	 //  alert(cargoFlightMaxRange);
 
 }
 function clusterPlot5ForCargoAgain(clusterArray1,clusterArray2,clusterArray3,clusterArray4,clusterArray5,yasixToRangeMax){
 	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
	max:  yasixToRangeMax,
        title: {
            text: 'Vertical Acceleartion'
        }
    },
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
       // color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
       name: 'Cluster2',
      // color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
       name: 'Cluster3',
       // color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	{
        name: 'Cluster4',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray4

    },
	{
        name: 'Cluster5',
        //color: 'rgba(255,0,255,0.3)',
        data: clusterArray5

    }
	
	]
});

 var chart = $('#container8').highcharts();
       cargoFlightMaxRange = chart.yAxis[0].max;
	//   alert(cargoFlightMaxRange);
 
 }