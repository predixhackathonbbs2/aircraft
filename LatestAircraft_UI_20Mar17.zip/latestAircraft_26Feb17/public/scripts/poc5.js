

var jsonDatapoc5;

var strainActualvalpoc5;
var strainPredictvalpoc5;
var fireFighterGraphJson;
var cargoGraphJson
var firefighterRSquared;
var regressionParameterArray;
$(document).ready(function () {
$("#container9").hide();
$("#container10").hide();
$("#tableDivForFireFighter").hide();
$("#tableDivForCargoFlight").hide();
$("#formulaFireFighterType").hide();
$("#formulaForCargoType").hide();

jsonDatapoc5={
   "flightId" : 101,
   "elapseTime": [10,20,30,40,50,60.09,70.90,80,89,90.78,100,110],
   "ActualValue": [1051.34,1054.56,1056.76,1034.45,1087.56,1111.09,1112.90,1056.89,1034.78,1036.90],
   "PredictedValue": [1056.072,1015.059,1022.86,1027.82,1040.525,1071.742,1054.215,1071.742,1023.887,1116.086],
   "VerticalAcceleration":[-0.167,2.542,-0.065,0.9501],
   "Airspeed":[-14.6693,2.5421,-2.962,0.0314],
   "RollAcceleration":[-1.989,2.912,-0.683,0.524],
   "PressureAltitude":[10.211,3.915,2.608,0.0477],
   "Const" : [845.4938,76.7374,11.0180,0.000107],
   "RSquared" :0.67964812454667545
};
$('.SlectBox2').SumoSelect();
$("#regressionMultiData").change(function(){
regressionParameterArray=new Array();
  var data1;
  var data2;
  var staringaugeinput;
  var equation;
  var eq_final;
  var finalEquation;
  var splitval;
  var  parameter =$("#regressionMultiData").val();
  var splitvalforTable;
  splitval=parameter.toString().split(",");
	
	for(var i=0;i<splitval.length;i++){
	if(i==0){
	equation='a'+[i+1]+'*'+splitval[i];
	}else{
	equation=equation+'+'+'a'+[i+1]+'*'+splitval[i];
	}
		staringaugeinput='S1 =';
		finalEquation=staringaugeinput+equation+'+c';
		$("#firefighterEquation").html(finalEquation);
	}
	
	for(var i=0;i<splitval.length;i++){
	if(i==0){
	equation='b'+[i+1]+'*'+splitval[i];
	}else{
	equation=equation+'+'+'b'+[i+1]+'*'+splitval[i];
	}
		staringaugeinput='S1 =';
		finalEquation=staringaugeinput+equation+'+c';
		$("#cargofighterEquation").html(finalEquation);
	}
	
	
	var  parameter1 =$("#regressionMultiData").val();
	splitvalforTable=parameter1.toString().split(",");
	
	for(var i=0;i<splitval.length;i++){
	regressionParameterArray.push(splitval[i])
	}
	
	
	if($("#FireFighterflightId").val()!=0){	
	loadFirefighterTable(jsonDatapoc5,regressionParameterArray);
	}
	if($("#FireFighterflightId").val()!=0){	
	loadcargoFlightTable(jsonDatapoc5,regressionParameterArray);
	}

});

$("#FireFighterflightId").change(function(){

 $("#olsSummaryDataForfirecraft").html('RSquared='+jsonDatapoc5.RSquared.toFixed(2));
 
var flightid=$(this).val();
$("#tableDivForFireFighter").show();
loadFirefighterTable(jsonDatapoc5,regressionParameterArray);
loadFirefighterChartData(jsonDatapoc5);
$("#formulaFireFighterType").show();
});




$("#cargoflightId").change(function(){
$("#olsSummaryDataForcargo").html('RSquared='+jsonDatapoc5.RSquared.toFixed(2));
$("#tableDivForCargoFlight").show();
var flightid=$(this).val();
loadcargoFlightTable(jsonDatapoc5,regressionParameterArray);
loadCargoChartData(jsonDatapoc5);
$("#formulaForCargoType").show();
});



});

function loadFirefighterflight(flightId){
var predixurl="https://predix-aircraft-demo-clusteranalysisnew.run.aws-usw02-pr.ice.predix.io/getClusterAnalytics";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId,
                type: "get", //send it through post method
                success: function(responseData) {
				
				//jsonData=responseData;
				$("#loadingChart7").hide();
				drawclusterChart(flightType);
			
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});

}


function loadFirefighterTable(jsonDataPoc5,arr){
 $('#fireFighterTableIfPoc5 tr').slice(1).remove();
for(var i=0;i<arr.length;i++){
if(arr[i]=='verticalAcceleration'){
 $("#fireFighterTableIfPoc5").append('<tr><td style="color:green">'+arr[i]+'</td><td>'+jsonDatapoc5.VerticalAcceleration[0]+
 '</td><td>'+jsonDatapoc5.VerticalAcceleration[1]+'</td><td>'+jsonDatapoc5.VerticalAcceleration[2]+'</td><td>'+jsonDatapoc5.VerticalAcceleration[3]+'</td></tr>')
 } 
 if(arr[i]=='airspeed'){
 $("#fireFighterTableIfPoc5").append('<tr><td style="color:green">'+arr[i]+'</td><td>'+jsonDatapoc5.Airspeed[0]+
 '</td><td>'+jsonDatapoc5.Airspeed[1]+'</td><td>'+jsonDatapoc5.Airspeed[2]+'</td><td>'+jsonDatapoc5.Airspeed[3]+'</td></tr>')
 }  
	if(arr[i]=='rollAcceleration'){
 $("#fireFighterTableIfPoc5").append('<tr><td style="color:green">'+arr[i]+'</td><td>'+jsonDatapoc5.RollAcceleration[0]+
 '</td><td>'+jsonDatapoc5.RollAcceleration[1]+'</td><td>'+jsonDatapoc5.RollAcceleration[2]+'</td><td>'+jsonDatapoc5.RollAcceleration[3]+'</td></tr>')
 } 
 
 if(arr[i]=='pressureAltitude'){
 $("#fireFighterTableIfPoc5").append('<tr><td style="color:green">'+arr[i]+'</td><td>'+jsonDatapoc5.PressureAltitude[0]+
 '</td><td>'+jsonDatapoc5.PressureAltitude[1]+'</td><td>'+jsonDatapoc5.PressureAltitude[2]+'</td><td>'+jsonDatapoc5.PressureAltitude[3]+'</td></tr>')
 }
 
 
}

}

function loadcargoFlightTable(jsonDataPoc5,arr){
 $('#cargoTableIfPoc5 tr').slice(1).remove();
for(var i=0;i<arr.length;i++){
if(arr[i]=='verticalAcceleration'){
 $("#cargoTableIfPoc5").append('<tr><td style="color:green">'+arr[i]+'</td><td>'+jsonDatapoc5.VerticalAcceleration[0]+
 '</td><td>'+jsonDatapoc5.VerticalAcceleration[1]+'</td><td>'+jsonDatapoc5.VerticalAcceleration[2]+'</td><td>'+jsonDatapoc5.VerticalAcceleration[3]+'</td></tr>')
 } 
 if(arr[i]=='airspeed'){
 $("#cargoTableIfPoc5").append('<tr><td style="color:green">'+arr[i]+'</td><td>'+jsonDatapoc5.Airspeed[0]+
 '</td><td>'+jsonDatapoc5.Airspeed[1]+'</td><td>'+jsonDatapoc5.Airspeed[2]+'</td><td>'+jsonDatapoc5.Airspeed[3]+'</td></tr>')
 }  
	if(arr[i]=='rollAcceleration'){
 $("#cargoTableIfPoc5").append('<tr><td style="color:green">'+arr[i]+'</td><td>'+jsonDatapoc5.RollAcceleration[0]+
 '</td><td>'+jsonDatapoc5.RollAcceleration[1]+'</td><td>'+jsonDatapoc5.RollAcceleration[2]+'</td><td>'+jsonDatapoc5.RollAcceleration[3]+'</td></tr>')
 } 
 
 if(arr[i]=='pressureAltitude'){
 $("#cargoTableIfPoc5").append('<tr><td style="color:green">'+arr[i]+'</td><td>'+jsonDatapoc5.PressureAltitude[0]+
 '</td><td>'+jsonDatapoc5.PressureAltitude[1]+'</td><td>'+jsonDatapoc5.PressureAltitude[2]+'</td><td>'+jsonDatapoc5.PressureAltitude[3]+'</td></tr>')
 }
 
}
}

function loadFirefighterChartData(jsonDataPoc5){
	strainActualvalpoc5=new Array();
	strainPredictvalpoc5=new Array();
	 for(var i=0;i<jsonDatapoc5.elapseTime.length;i++)
	{
		strainActualvalpoc5.push([parseFloat(jsonDatapoc5.elapseTime[i]),parseFloat(jsonDatapoc5.ActualValue[i])]);
		strainPredictvalpoc5.push([parseFloat(jsonDatapoc5.elapseTime[i]),parseFloat(jsonDatapoc5.PredictedValue[i])]);
	}
	
     drawChartForFireFighter(strainActualvalpoc5,strainPredictvalpoc5);
 
 
 
	
	
}


function loadCargoChartData(jsonDataPoc5){
	strainActualvalpoc5=new Array();
	strainPredictvalpoc5=new Array();
	 for(var i=0;i<jsonDatapoc5.elapseTime.length;i++)
	{
		strainActualvalpoc5.push([parseFloat(jsonDatapoc5.elapseTime[i]),parseFloat(jsonDatapoc5.ActualValue[i])]);
		strainPredictvalpoc5.push([parseFloat(jsonDatapoc5.elapseTime[i]),parseFloat(jsonDatapoc5.PredictedValue[i])]);
	}
	
     drawChartForFireCargo(strainActualvalpoc5,strainPredictvalpoc5);
	
	
}


function drawChartForFireFighter(strainActualvalpoc5,strainPredictvalpoc5){
	$("#container9").show();
	Highcharts.chart('container9', {

    title: {
        text: 'Analysis'
    },

    subtitle: {
        text: ''
    },

    yAxis: {
        title: {
            text: 'StarinGauge Value'
        }
    },
	xAxis: {
        title: {
            text: 'ElapseTime'
        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },
    series: [
	{
        name: 'Actual',
        data: strainActualvalpoc5
    },{
        name: 'Predict',
        data: strainPredictvalpoc5
    
    }]

});
	
}

function drawChartForFireCargo(strainActualvalpoc5,strainPredictvalpoc5){
	$("#container10").show();
	Highcharts.chart('container10', {

    title: {
        text: 'Analysis'
    },

    subtitle: {
        text: ''
    },

    yAxis: {
        title: {
            text: 'StarinGauge Value'
        }
    },
	xAxis: {
        title: {
            text: 'ElapseTime'
        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },
    series: [
	{
        name: 'Actual',
        data: strainActualvalpoc5
    },{
        name: 'Predict',
        data: strainPredictvalpoc5
    
    }]

});
	
}