var clusterData;
var airspeedArray;
var verticalAccelartion;
var clusterArray1;
var clusterArray2;
var clusterArray3;


$(document).ready(function () {
	
 
   $("#flightIdPoc4").change(function(){
       var flightType='fireFighter';
		var radioButtonid=$('input[name=chartPoc4]:checked').val();
		$("#loadingChart7").show();
		var flightId=$(this).val();
		loadClusterData(flightId,radioButtonid,flightType);
		}); 
		
		
		
		$("#flightIdPoc4DivForCargoFlight").change(function(){
			var flightType='cargoFlight';
			var radioButtonid=$('input[name=chartPoc4]:checked').val();
			$("#loadingChart7").show();
			var flightId=$(this).val();
			loadClusterData(flightId,radioButtonid,flightType);
		
		});
		
		
		jQuery("input[name='chartPoc4']").click(function() {
			var radioButtonid=$('input[name=chartPoc4]:checked').val();
			var fireFighterflighId=$("#flightIdPoc4 option:selected").text();
		    var cargoFlighId=$("#flightIdPoc4DivForCargoFlight option:selected").text();
		   alert(radioButtonid);
		   alert(fireFighterflighId);
		   alert(cargoFlighId);
				
		});
		
		
		
   
 });
 
 function loadClusterData(flightId,radioId,flightType){
 	 var predixurl="https://predix-aircraft-demo-clusteranalysisnew.run.aws-usw02-pr.ice.predix.io/getClusterAnalytics";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+radioId,
                type: "get", //send it through post method
                success: function(responseData) {
				
				clusterData=responseData;
				$("#loadingChart7").hide();
				drawclusterChart(flightType);
			
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});
 }
 
 
 
 function drawclusterChart(flightType){
 
		clusterArray1=new Array();
		clusterArray2=new Array();
		clusterArray3=new Array();
		var obj = jQuery.parseJSON(clusterData);
		airspeedArray=new Array();
		verticalAccelartion=new Array();
		
		for(var i=0;i<obj.airspeed.length;i++){
		   
		   if(obj["cluster number"][i]=='1'){
		   clusterArray1.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='2'){
		   clusterArray2.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		   else if(obj["cluster number"][i]=='0'){
		   clusterArray3.push([parseFloat(obj.airspeed[i]),parseFloat(obj.verticalAcceleration[i])]);
		   }
		}
	if(flightType=='fireFighter'){
	clusterPlot(clusterArray1,clusterArray2,clusterArray3);
	}
	if(flightType=='cargoFlight'){
	clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3);
	}
		
		
 
 
 
 }
 
 function clusterPlot(clusterArray1,clusterArray2,clusterArray3){
 
	Highcharts.chart('container7', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
    legend: {
        layout: 'vertical',
        align: 'left',
        verticalAlign: 'top',
        x: 100,
        y: 70,
        floating: true,
        backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF',
        borderWidth: 1
    },
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
        //color: 'rgba(223, 83, 83, .5)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
       // color: 'rgba(223, 83, 83, .5)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
        //color: 'rgba(223, 83, 83, .5)',
        data: clusterArray3

    },
	
	
	]
});

 }
 
  function clusterPlotForCargoFlight(clusterArray1,clusterArray2,clusterArray3){
 
	Highcharts.chart('container8', {
    chart: {
        type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: ''
    },
    subtitle: {
        text: ''
    },
    xAxis: {
        title: {
            enabled: true,
           text: 'Airspeed'
        },
        startOnTick: true,
        endOnTick: true,
        showLastLabel: true
    },
    yAxis: {
        title: {
            text: 'Vertical Acceleartion'
        }
    },
    legend: {
        layout: 'vertical',
        align: 'left',
        verticalAlign: 'top',
        x: 100,
        y: 70,
        floating: true,
        backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF',
        borderWidth: 1
    },
    plotOptions: {
        scatter: {
            marker: {
                radius: 5,
                states: {
                    hover: {
                        enabled: true,
                        lineColor: 'rgb(100,100,100)'
                    }
                }
            },
            states: {
                hover: {
                    marker: {
                        enabled: false
                    }
                }
            },
            tooltip: {
               // headerFormat: '<b>{series.name}</b><br>',
               // pointFormat: '{point.x} cm, {point.y} kg'
            }
        }
    },
    series: [{
        name: 'Cluster1',
        color: 'rgba(255,0,0,0.3)',
        data: clusterArray1

    },
	{
        name: 'Cluster2',
       color: 'rgba(0,255,0,0.3)',
        data: clusterArray2

    },
	{
        name: 'Cluster3',
        color: 'rgba(255,0,255,0.3)',
        data: clusterArray3

    },
	
	
	]
});

 }
 
 
 