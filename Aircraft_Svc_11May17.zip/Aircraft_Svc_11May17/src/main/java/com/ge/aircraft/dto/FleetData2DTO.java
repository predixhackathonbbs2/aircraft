package com.ge.aircraft.dto;

import java.math.BigDecimal;

public class FleetData2DTO {
	
	private long fleetId;

	private Double airspeed;

	private BigDecimal armRetardantTankDoor;

	private BigDecimal beaconStartStopRecording;

	private Double elapsedTime;

	private Double elevatorPosition;

	private Double flapPosition;

	private BigDecimal gearUpAndLocked;

	private Double leftAileronPosition;

	private String peakValleyIndicator;

	private Double pressureAltitude;

	private String recordType;

	private BigDecimal retardantDoorOpen;

	private BigDecimal retardantTankFloat;

	private Double rollAcceleration;

	private Double strainGauge1;

	private Double strainGauge2;

	private Double strainGauge3;

	private Double strainGauge4;

	private Double strainGauge5;

	private Double strainGauge6;

	private Double strainGauge7;

	private Double strainGauge8;
	
	private Double strainGauge9;

	private String timestamp;

	private BigDecimal triggerChannel;

	private Double verticalAcceleration;
	
	private long flightId;


	public long getFleetId() {
		return this.fleetId;
	}

	public void setFleetId(long fleetId) {
		this.fleetId = fleetId;
	}

	public Double getAirspeed() {
		return this.airspeed;
	}

	public void setAirspeed(Double airspeed) {
		this.airspeed = airspeed;
	}

	public BigDecimal getArmRetardantTankDoor() {
		return this.armRetardantTankDoor;
	}

	public void setArmRetardantTankDoor(BigDecimal armRetardantTankDoor) {
		this.armRetardantTankDoor = armRetardantTankDoor;
	}

	public BigDecimal getBeaconStartStopRecording() {
		return this.beaconStartStopRecording;
	}

	public void setBeaconStartStopRecording(BigDecimal beaconStartStopRecording) {
		this.beaconStartStopRecording = beaconStartStopRecording;
	}

	public Double getElapsedTime() {
		return this.elapsedTime;
	}

	public void setElapsedTime(Double elapsedTime) {
		this.elapsedTime = elapsedTime;
	}

	public Double getElevatorPosition() {
		return this.elevatorPosition;
	}

	public void setElevatorPosition(Double elevatorPosition) {
		this.elevatorPosition = elevatorPosition;
	}

	public Double getFlapPosition() {
		return this.flapPosition;
	}

	public void setFlapPosition(Double flapPosition) {
		this.flapPosition = flapPosition;
	}

	public BigDecimal getGearUpAndLocked() {
		return this.gearUpAndLocked;
	}

	public void setGearUpAndLocked(BigDecimal gearUpAndLocked) {
		this.gearUpAndLocked = gearUpAndLocked;
	}

	public Double getLeftAileronPosition() {
		return this.leftAileronPosition;
	}

	public void setLeftAileronPosition(Double leftAileronPosition) {
		this.leftAileronPosition = leftAileronPosition;
	}

	public String getPeakValleyIndicator() {
		return this.peakValleyIndicator;
	}

	public void setPeakValleyIndicator(String peakValleyIndicator) {
		this.peakValleyIndicator = peakValleyIndicator;
	}

	public Double getPressureAltitude() {
		return this.pressureAltitude;
	}

	public void setPressureAltitude(Double pressureAltitude) {
		this.pressureAltitude = pressureAltitude;
	}

	public String getRecordType() {
		return this.recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public BigDecimal getRetardantDoorOpen() {
		return this.retardantDoorOpen;
	}

	public void setRetardantDoorOpen(BigDecimal retardantDoorOpen) {
		this.retardantDoorOpen = retardantDoorOpen;
	}

	public BigDecimal getRetardantTankFloat() {
		return this.retardantTankFloat;
	}

	public void setRetardantTankFloat(BigDecimal retardantTankFloat) {
		this.retardantTankFloat = retardantTankFloat;
	}

	public Double getRollAcceleration() {
		return this.rollAcceleration;
	}

	public void setRollAcceleration(Double rollAcceleration) {
		this.rollAcceleration = rollAcceleration;
	}

	public Double getStrainGauge1() {
		return this.strainGauge1;
	}

	public void setStrainGauge1(Double strainGauge1) {
		this.strainGauge1 = strainGauge1;
	}

	public Double getStrainGauge2() {
		return this.strainGauge2;
	}

	public void setStrainGauge2(Double strainGauge2) {
		this.strainGauge2 = strainGauge2;
	}

	public Double getStrainGauge3() {
		return this.strainGauge3;
	}

	public void setStrainGauge3(Double strainGauge3) {
		this.strainGauge3 = strainGauge3;
	}

	public Double getStrainGauge4() {
		return this.strainGauge4;
	}

	public void setStrainGauge4(Double strainGauge4) {
		this.strainGauge4 = strainGauge4;
	}

	public Double getStrainGauge5() {
		return this.strainGauge5;
	}

	public void setStrainGauge5(Double strainGauge5) {
		this.strainGauge5 = strainGauge5;
	}

	public Double getStrainGauge6() {
		return this.strainGauge6;
	}

	public void setStrainGauge6(Double strainGauge6) {
		this.strainGauge6 = strainGauge6;
	}

	public Double getStrainGauge7() {
		return this.strainGauge7;
	}

	public void setStrainGauge7(Double strainGauge7) {
		this.strainGauge7 = strainGauge7;
	}

	public Double getStrainGauge8() {
		return this.strainGauge8;
	}

	public void setStrainGauge8(Double strainGauge8) {
		this.strainGauge8 = strainGauge8;
	}

	public String getTimestamp() {
		return this.timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public BigDecimal getTriggerChannel() {
		return this.triggerChannel;
	}

	public void setTriggerChannel(BigDecimal triggerChannel) {
		this.triggerChannel = triggerChannel;
	}

	public Double getVerticalAcceleration() {
		return this.verticalAcceleration;
	}

	public void setVerticalAcceleration(Double verticalAcceleration) {
		this.verticalAcceleration = verticalAcceleration;
	}

	public long getFlightId() {
		return flightId;
	}

	public void setFlightId(long flightId) {
		this.flightId = flightId;
	}

	/**
	 * @return the strainGauge9
	 */
	public Double getStrainGauge9() {
		return this.strainGauge9;
	}

	/**
	 * @param strainGauge9 the strainGauge9 to set
	 */
	public void setStrainGauge9(Double strainGauge9) {
		this.strainGauge9 = strainGauge9;
	}

	

}