

var jsonDatapoc5;
var strainActualvalpoc5;
var strainPredictvalpoc5;
var fireFighterGraphJson;
var cargoGraphJson
var firefighterRSquared;
var regressionParameterArray;
$(document).ready(function () {
$("#container9").hide();
$("#container10").hide();
$("#tableDivForFireFighter").hide();
$("#tableDivForCargoFlight").hide();
$("#formulaFireFighterType").hide();
$("#formulaForCargoType").hide();

/*jsonDatapoc5={
   "flightId" : 101,
   "elapseTime": [10,20,30,40,50,60.09,70.90,80,89,90.78,100,110],
   "ActualValue": [1051.34,1054.56,1056.76,1034.45,1087.56,1111.09,1112.90,1056.89,1034.78,1036.90],
   "PredictedValue": [1056.072,1015.059,1022.86,1027.82,1040.525,1071.742,1054.215,1071.742,1023.887,1116.086],
   "VerticalAcceleration":[-0.167,2.542,-0.065,0.9501],
   "Airspeed":[-14.6693,2.5421,-2.962,0.0314],
   "RollAcceleration":[-1.989,2.912,-0.683,0.524],
   "PressureAltitude":[10.211,3.915,2.608,0.0477],
   "Const" : [845.4938,76.7374,11.0180,0.000107],
   "RSquared" :0.67964812454667545
};*/
$('.SlectBox2').SumoSelect();
$("#regressionMultiData").change(function(){
$("#errorVaildForRegression").html('');
$("#FireFighterflightId").val(0);
regressionParameterArray=new Array();
  var data1;
  var data2;
  var staringaugeinput;
  var equation;
  var eq_final;
  var finalEquation;
  var splitval;
  var  parameter =$("#regressionMultiData").val();
  var splitvalforTable;
  splitval=parameter.toString().split(",");
	for(var i=0;i<splitval.length;i++){
	
								if(i==0){
								equation='a'+[i+1]+'*'+splitval[i];
								}
								if(i==1){
                                $("#firefighterEquation").text('S1 = c+'+equation+'+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==2){
                                $("#firefighterEquation1").text('+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==3){
                                $("#firefighterEquation2").text('+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==4){
                                $("#firefighterEquation3").text('+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==5){
                                $("#firefighterEquation4").text('+a'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==6){
                                $("#firefighterEquation5").text('+a'+[i+1]+'*'+splitval[i]);
                                }
								 if(i==7){
                                $("#firefighterEquation6").text('+a'+[i+1]+'*'+splitval[i]);
                                }
								 if(i==8){
                                $("#firefighterEquation7").text('+a'+[i+1]+'*'+splitval[i]);
                                }
								if(i==9){
                                $("#firefighterEquation8").text('+a'+[i+1]+'*'+splitval[i]);
                                }
								
		
		
	}
	
	for(var i=0;i<splitval.length;i++){
							if(i==0){
								equation='b'+[i+1]+'*'+splitval[i];
								}
								if(i==1){
                                $("#cargofighterEquation").text('S1 = c+'+equation+'+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==2){
                                $("#cargofighterEquation1").text('+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==3){
                                $("#cargofighterEquation2").text('+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==4){
                                $("#cargofighterEquation3").text('+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==5){
                                $("#cargofighterEquation4").text('+b'+[i+1]+'*'+splitval[i]);
                                }
                                if(i==6){
                                $("#cargofighterEquation5").text('+b'+[i+1]+'*'+splitval[i]);
                                }
								 if(i==7){
                                $("#cargofighterEquation6").text('+b'+[i+1]+'*'+splitval[i]);
                                }
								 if(i==8){
                                $("#cargofighterEquation7").text('+b'+[i+1]+'*'+splitval[i]);
                                }
								if(i==9){
                                $("#cargofighterEquation8").text('+b'+[i+1]+'*'+splitval[i]);
                                }
		
	}
	
	
	var  parameter1 =$("#regressionMultiData").val();
	splitvalforTable=parameter1.toString().split(",");
	
	for(var i=0;i<splitval.length;i++){
	regressionParameterArray.push(splitval[i])
	}
	
	
	if($("#FireFighterflightId").val()!=0){	
	loadFirefighterTable(jsonDatapoc5,regressionParameterArray);
	}
	if($("#FireFighterflightId").val()!=0){	
	loadcargoFlightTable(jsonDatapoc5,regressionParameterArray);
	}

});

$("#FireFighterflightId").change(function(){
 $("#loadingChart8").show();
var parameterRegression=$("#regressionMultiData").val();
var flightid=$(this).val();
var radioButtonid=$('input[name=straingaugeval]:checked').val();

if(parameterRegression==null){
jQuery("#errorVaildForRegression").text('please eneter Regression input');
}else{

getRegressionDynamicAnalysis(parameterRegression,flightid,radioButtonid,regressionParameterArray);

$("#tableDivForFireFighter").show();
$("#formulaFireFighterType").show();
}

});




$("#cargoflightId").change(function(){
	 $("#loadingChart8").show();
var parameterRegression=$("#regressionMultiData").val();
var flightid=$(this).val();
var radioButtonid=$('input[name=straingaugeval]:checked').val();
if(parameterRegression==null){
jQuery("#errorVaildForRegression").text('please eneter Regression input');
}else{

getRegressionDynamicCargoGlightAnalysis(parameterRegression,flightid,radioButtonid,regressionParameterArray)
$("#tableDivForCargoFlight").show();
$("#formulaForCargoType").show();
}
});

	jQuery("input[name='straingaugeval']").click(function() {
		var parameterRegression=$("#regressionMultiData").val();
		
			
			var radioButtonid=$('input[name=straingaugeval]:checked').val();
			

			var fireFighterflighId=$("#FireFighterflightId option:selected").text();
		    var cargoFlighId=$("#cargoflightId option:selected").text();
			
			
			if(fireFighterflighId!='--select---'){
				$("#loadingChart8").show();
				getRegressionDynamicAnalysis(parameterRegression,fireFighterflighId,radioButtonid,regressionParameterArray);
			}
			if(cargoFlighId!='--select---'){
				$("#loadingChart8").show();
				getRegressionDynamicCargoGlightAnalysis(parameterRegression,cargoFlighId,radioButtonid,regressionParameterArray);
			}
			
			
				
		});






});

function getRegressionDynamicAnalysis(regressionInput,flightId,radiobuttonval,regressionParameterArray){
var predixurl="https://mfg-regression-cluster-dynamic.run.aws-usw02-pr.ice.predix.io/getRegressionDynamicAnalysis1";

var urldtl=predixurl+"/"+flightId+"/"+radiobuttonval+"/"+regressionInput+"/80";

console.log(urldtl);
				$.ajax({
				url:urldtl,
				
                type: "get", //send it through post method
                success: function(responseData) {
				jsonDatapoc5=responseData;
				$("#loadingChart8").hide();
				loadFirefighterChartData(responseData);
				loadFirefighterTable(responseData,regressionParameterArray)
			
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});

}



function getRegressionDynamicCargoGlightAnalysis(regressionInput,flightId,radiobuttonval,regressionParameterArray){
var predixurl="https://mfg-regression-cluster-dynamic.run.aws-usw02-pr.ice.predix.io/getRegressionDynamicAnalysis1";
var urldtl=predixurl+"/"+flightId+"/"+radiobuttonval+"/"+regressionInput+"/80";
				$.ajax({
				url:urldtl,
                type: "get", //send it through post method
                success: function(responseData) {
				jsonDatapoc5=responseData;
				
				$("#loadingChart8").hide();
				//loadcargoChartData(responseData);
				loadCargoFlightTable(responseData,regressionParameterArray)
				loadCargoChartData(responseData);
			
				},
                error: function ( xhr, status, error) {
				$("#loadingChart7").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});


}


function loadFirefighterTable(jsonDataPoc5,arr){

 $('#fireFighterTableIfPoc5 tr').slice(1).remove();
 var obj1 = jQuery.parseJSON(jsonDataPoc5);
$("#olsSummaryDataForfirecraft").html('RSquared='+parseFloat(obj1.RSquared).toFixed(3));
 for(var i=0;i<obj1.mapList.length;i++){
 
 $("#fireFighterTableIfPoc5").append('<tr><td style="color:green">'+obj1.mapList[i].param+'</td><td>'+parseFloat(obj1.mapList[i].pVal).toFixed(3)+
 '</td><td>'+parseFloat(obj1.mapList[i].tVal).toFixed(3)+'</td><td>'+parseFloat(obj1.mapList[i].stdErr).toFixed(3)+'</td><td>'+parseFloat(obj1.mapList[i].coEff).toFixed(3)+'</td></tr>')
 }
 

}

function loadCargoFlightTable(jsonDataPoc5,arr){

 $('#cargoTableIfPoc5 tr').slice(1).remove();
 var obj1 = jQuery.parseJSON(jsonDataPoc5);

$("#olsSummaryDataForcargo").html('RSquared='+parseFloat(obj1.RSquared).toFixed(3));
 for(var i=0;i<obj1.mapList.length;i++){
 
 $("#cargoTableIfPoc5").append('<tr><td style="color:green">'+obj1.mapList[i].param+'</td><td>'+parseFloat(obj1.mapList[i].pVal).toFixed(3)+
 '</td><td>'+parseFloat(obj1.mapList[i].tVal).toFixed(3)+'</td><td>'+parseFloat(obj1.mapList[i].stdErr).toFixed(3)+'</td><td>'+parseFloat(obj1.mapList[i].coEff).toFixed(3)+'</td></tr>')
 }
 

}





function loadFirefighterChartData(jsonDataPoc5){
   var obj = jQuery.parseJSON(jsonDataPoc5);
	strainActualvalpoc5=new Array();
	strainPredictvalpoc5=new Array();
	
	 for(var i=0;i<obj.elapseTime.length;i++)
	{
		strainActualvalpoc5.push([parseFloat(obj.elapseTime[i]),parseFloat(obj.ActualValue[i])]);
		strainPredictvalpoc5.push([parseFloat(obj.elapseTime[i]),parseFloat(obj.PredictedValue[i])]);
	}
	
    drawChartForFireFighter(strainActualvalpoc5,strainPredictvalpoc5);
 

}


function loadCargoChartData(jsonDatacargo){
	 var obj = jQuery.parseJSON(jsonDatacargo);
	strainActualvalpoc5=new Array();
	strainPredictvalpoc5=new Array();
	 for(var i=0;i<obj.elapseTime.length;i++)
	{
		strainActualvalpoc5.push([parseFloat(obj.elapseTime[i]),parseFloat(obj.ActualValue[i])]);
		strainPredictvalpoc5.push([parseFloat(obj.elapseTime[i]),parseFloat(obj.PredictedValue[i])]);
	}
	
     drawChartForCargo(strainActualvalpoc5,strainPredictvalpoc5);
	
	
}


function drawChartForFireFighter(strainActualvalpoc5,strainPredictvalpoc5){
	$("#container9").show();
	Highcharts.chart('container9', {
		
		 chart: {
       // type: 'scatter',
        zoomType: 'xy'
    },

    title: {
        text: 'Analysis'
    },
	annotationsOptions: {
            enabledButtons: false   
        },

    subtitle: {
        text: ''
    },

    yAxis: {
        title: {
            text: 'StarinGauge Value'
        }
    },
	xAxis: {
        title: {
            text: 'ElapseTime'
        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },
    series: [
	{
        name: 'Actual',
        data: strainActualvalpoc5
    },{
        name: 'Predict',
        data: strainPredictvalpoc5
    
    }]

});
	
}

function drawChartForCargo(strainActualvalpoc5,strainPredictvalpoc5){
	
	$("#container10").show();
	Highcharts.chart('container10', {
 chart: {
        //type: 'scatter',
        zoomType: 'xy'
    },
    title: {
        text: 'Analysis'
    },
	annotationsOptions: {
            enabledButtons: false   
        },

    subtitle: {
        text: ''
    },

    yAxis: {
        title: {
            text: 'StarinGauge Value'
        }
    },
	xAxis: {
        title: {
            text: 'ElapseTime'
        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
    },
    series: [
	{
        name: 'Actual',
        data: strainActualvalpoc5
    },{
        name: 'Predict',
        data: strainPredictvalpoc5
    
    }]

});
	
}