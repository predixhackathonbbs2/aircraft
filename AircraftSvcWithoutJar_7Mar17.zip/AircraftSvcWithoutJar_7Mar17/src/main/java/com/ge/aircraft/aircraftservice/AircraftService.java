package com.ge.aircraft.aircraftservice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ge.aircraft.dto.FleetData2DTO;
import com.ge.aircraft.dto.FlightMasterDTO;
import com.ge.aircraft.entity.FleetData2;
import com.ge.aircraft.entity.FlightMaster;
import com.ge.aircraft.repository.IFlightFleet2Repository;
import com.ge.aircraft.repository.IFlightMasterRepository;

@RestController
public class AircraftService {

	@Autowired
	private IFlightMasterRepository flightMasterRepo;
	
	@Autowired
	private IFlightFleet2Repository filghtFleetrepo2;
	
		

	@RequestMapping(value = "/getFlightTimeStampDetails/{startdate}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FlightMasterDTO> getFlightTimeStampDetails(
			@PathVariable("startdate") String startdate) {
		
		List<FlightMasterDTO> aircraftLists = new ArrayList<FlightMasterDTO>();
		FlightMasterDTO flightTimeStamp = null;
		try {
			System.out.println("AircraftService.getFlightTimeStampDetails()");

			List<FlightMaster> dataList = (List<FlightMaster>) flightMasterRepo.findByStartDate(startdate);
			for (FlightMaster flightMstr : dataList) {
				flightTimeStamp = new FlightMasterDTO();
				BeanUtils.copyProperties(flightMstr, flightTimeStamp);
				aircraftLists.add(flightTimeStamp);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return aircraftLists;
	}

	

	@RequestMapping(value = "/view/getFlightDetailsWithDynamicfilter/{flightDate}/{flightTime}/{recordType}/{triggerChannel}/{startTime}/{endTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getFlightDetailsWithDynamicfilter(
			@PathVariable("flightDate") String flightDate,
			@PathVariable("flightTime") String flightTime,
			@PathVariable("recordType") String recordType,
			@PathVariable("triggerChannel") BigDecimal triggerChannel,
			@PathVariable("startTime") String startTime,
			@PathVariable("endTime") String endTime) {

		Map<String, Object> objMap = null;
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();

		if (startTime.equalsIgnoreCase("''")) {
			startTime = "";
		}
		if (endTime.equalsIgnoreCase("''")) {
			endTime = "";
		}

		try {
			System.out
					.println("AircraftService.getFlightDetailsWithDynamicfilter()");

			List<Object[]> retList = null;

			if (null != flightDate && null != flightTime && null != recordType) {
				if (recordType.equalsIgnoreCase("TR")) {

					if (!StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTREndTime(
								flightDate, flightTime, recordType,
								triggerChannel, endTime);
					} else if (!StringUtils.isNotBlank(endTime)
							&& StringUtils.isNotBlank(startTime)) {

						retList = filghtFleetrepo2.getFlDtlsTRStartTime(
								flightDate, flightTime, recordType,
								triggerChannel, startTime);
					} else if (!StringUtils.isNotBlank(startTime)
							&& !StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTRWithoutTime(
								flightDate, flightTime, recordType,
								triggerChannel);
					} else if (StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsTRWithBothTime(
								flightDate, flightTime, recordType,
								triggerChannel, startTime, endTime);

					}

				} else if (recordType.equalsIgnoreCase("PE")) {

					if (!StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEEndTime(
								flightDate, flightTime, recordType, endTime);
					} else if (!StringUtils.isNotBlank(endTime)
							&& StringUtils.isNotBlank(startTime)) {

						retList = filghtFleetrepo2.getFlDtlsPEStartTime(
								flightDate, flightTime, recordType, startTime);
					} else if (!StringUtils.isNotBlank(startTime)
							&& !StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEWithoutTime(
								flightDate, flightTime, recordType);
					} else if (StringUtils.isNotBlank(startTime)
							&& StringUtils.isNotBlank(endTime)) {
						retList = filghtFleetrepo2.getFlDtlsPEWithTime(
								flightDate, flightTime, recordType, startTime,
								endTime);
					}

				}

				for (int i = 0; i < retList.size(); i++) {

					objMap = new HashMap<String, Object>();
					objMap.put("fleetId", (retList.get(i))[0]);
					objMap.put("airspeed", (retList.get(i))[1]);
					objMap.put("armRetardantTankDoor", (retList.get(i))[2]);
					objMap.put("beaconStartStopRecording", (retList.get(i))[3]);
					objMap.put("elapsedTime", (retList.get(i))[4]);
					objMap.put("elevatorPosition", (retList.get(i))[5]);
					objMap.put("flapPosition", (retList.get(i))[6]);
					objMap.put("gearUpAndLocked", (retList.get(i))[7]);
					objMap.put("leftAileronPosition", (retList.get(i))[8]);
					objMap.put("peakValleyIndicator", (retList.get(i))[9]);
					objMap.put("pressureAltitude", (retList.get(i))[10]);
					objMap.put("recordType", (retList.get(i))[11]);

					objMap.put("retardantDoorOpen", (retList.get(i))[12]);
					objMap.put("retardantTankFloat", (retList.get(i))[13]);
					objMap.put("rollAcceleration", (retList.get(i))[14]);
					objMap.put("strainGauge1", (retList.get(i))[15]);
					objMap.put("strainGauge2", (retList.get(i))[16]);
					objMap.put("strainGauge3", (retList.get(i))[17]);
					objMap.put("strainGauge4", (retList.get(i))[18]);
					objMap.put("strainGauge5", (retList.get(i))[19]);
					objMap.put("strainGauge6", (retList.get(i))[20]);
					objMap.put("strainGauge7", (retList.get(i))[21]);
					objMap.put("strainGauge8", (retList.get(i))[22]);
					objMap.put("timestamp", (retList.get(i))[23]);
					objMap.put("triggerChannel", (retList.get(i))[24]);
					objMap.put("verticalAcceleration", (retList.get(i))[25]);
					objMap.put("startDate", (retList.get(i))[26]);
					objMap.put("startTime", (retList.get(i))[27]);
					objMap.put("flightId", (retList.get(i))[28]);

					list.add(objMap);

				}

			}
		}

		catch (Exception e) {
			e.printStackTrace();

		}

		return list;
	}
	

	
	@RequestMapping(value = "/view/getFlightPlottingData/{flightId}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FleetData2DTO> getFlightPlottingData(
			@PathVariable("flightId") long flightId) {

		List<FleetData2DTO> fleetData2DtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO fleetData2Dto = null;
		try {
			System.out
					.println("AircraftService.getFlightPlottingData() : start");
			List<FleetData2> FleetData2List = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingData(flightId);
			for (FleetData2 FleetData2 : FleetData2List) {
				fleetData2Dto = new FleetData2DTO();
				BeanUtils.copyProperties(FleetData2, fleetData2Dto);
				fleetData2Dto.setFlightId(flightId);
				fleetData2DtoList.add(fleetData2Dto);
			}
			System.out.println("AircraftService.getFlightPlottingData() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fleetData2DtoList;
	}

	@RequestMapping(value = "/view/getFlightPlottingDataElapsedTime/{flightId}/{startElapsedTime}/{endElapsedTime}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<FleetData2DTO> getFlightPlottingDataElapsedTime(
			@PathVariable("flightId") long flightId,
			@PathVariable("startElapsedTime") String startElapsedTime,
			@PathVariable("endElapsedTime") String endElapsedTime) {

		List<FleetData2DTO> fleetData2DtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO fleetData2Dto = null;
		try {
			System.out
					.println("AircraftService.getFlightPlottingDataElapsedTime() : start");

			List<FleetData2> fleetData2List = new ArrayList<FleetData2>();
			
			Double startElapsedTm;
			Double endElapsedTm;
			

			if (startElapsedTime != null && !startElapsedTime.equalsIgnoreCase("") && !startElapsedTime.equalsIgnoreCase("''")
					&& endElapsedTime != null && !endElapsedTime.equalsIgnoreCase("") && !endElapsedTime.equalsIgnoreCase("''")) {
				
				startElapsedTm = Double.valueOf(startElapsedTime);
				endElapsedTm = Double.valueOf(endElapsedTime);
				
				fleetData2List = (List<FleetData2>) filghtFleetrepo2
						.getFlightPlottingDataElapsedTime(flightId,	startElapsedTm, endElapsedTm);
			} else {
				fleetData2List = (List<FleetData2>) filghtFleetrepo2.getFlightPlottingData(flightId);
			}

			for (FleetData2 FleetData2 : fleetData2List) {
				fleetData2Dto = new FleetData2DTO();
				BeanUtils.copyProperties(FleetData2, fleetData2Dto);
				fleetData2Dto.setFlightId(flightId);
				fleetData2DtoList.add(fleetData2Dto);
			}
			System.out
					.println("AircraftService.getFlightPlottingDataElapsedTime() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fleetData2DtoList;
	}
	
	@RequestMapping(value = "/view/getFlightMinMaxElapsedTime/{flightId}", method = RequestMethod.GET, produces = "application/json")
    public @ResponseBody Map<String, Object> getFlightMinMaxElapsedTime(
                  @PathVariable("flightId") long flightId) {

           
           List<Object[]> retList = null;
           Map<String, Object> hm = new HashMap<>();
           try {
                  System.out
                               .println("AircraftService.getFlightPlottingData() : start");
           retList =  filghtFleetrepo2
                               .getFlightMinMaxElapsedTime(flightId);
                  
                  //objMap.put("strainGauge5", (retList.get(i))[19]);
                  Object result = null;
                  for (int i = 0; i < retList.size(); i++) {
                        hm.put("maxElapsedTime", (retList.get(i))[0]);
                        hm.put("minElapsedTime", (retList.get(i))[1]);
                                             
                  }
                  System.out
                               .println("BookingController.getFlightMinMaxElapsedTime() result" + result);
                  
                  
           
                  System.out.println("AircraftService.getFlightPlottingData() : end");
           } catch (Exception e) {
                  e.printStackTrace();
           }
           return hm;
    }
	
	//poc3
	@RequestMapping(value = "/view/getFlightSegments/{flightId}", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody List<Map<String, Object>> getFlightSegments(
			@PathVariable("flightId") long flightId) {

		List<FleetData2DTO> fleetDataDtoList = new ArrayList<FleetData2DTO>();
		FleetData2DTO fleetDataDto = null;
		
		Map<String, Object> objMap = null;
		List<Map<String, Object>> flightSegmentsDatList = new ArrayList<Map<String, Object>>();
		
		try {
			System.out.println("AircraftService.getFlightSegments() : start");
			List<FleetData2> fleetDataList = (List<FleetData2>) filghtFleetrepo2
					.getFlightPlottingData(flightId);
			for (FleetData2 fleetData : fleetDataList) {
				fleetDataDto = new FleetData2DTO();
				BeanUtils.copyProperties(fleetData, fleetDataDto);
				fleetDataDto.setFlightId(flightId);
				fleetDataDtoList.add(fleetDataDto);
			}
			
			//List<FleetData2DTO> takeOffDtoList = new ArrayList<FleetData2DTO>();
			List<FleetData2DTO> takeOffRangeData = null;
			
			//List<FleetData2DTO> landingDtoList = new ArrayList<FleetData2DTO>();
			List<FleetData2DTO> landingRangeData = null;
			

			
			//takeOffDtoList = getDummyDataList();
			//System.out.println("takeOffDtoList="+takeOffDtoList);
			
			Double startTakeoffElapsedTime = 0.0;
			Double endTakeoffElapsedTime = 0.0;
			Double startTakeoffPressureAltitude;
			Double endTakeoffPressureAltitude;
			
			int takeofflistSize = fleetDataDtoList.size();
			
			outer: for(int i=0; i<takeofflistSize; i++){	
				if(fleetDataDtoList.get(i).getAirspeed() >100){
					takeOffRangeData = new ArrayList<FleetData2DTO>();
					startTakeoffElapsedTime = fleetDataDtoList.get(i).getElapsedTime();
					startTakeoffPressureAltitude = fleetDataDtoList.get(i).getPressureAltitude();
					takeOffRangeData.add(fleetDataDtoList.get(i));
					i++;
					
					inner: for(int j=i; j<takeofflistSize; j++){
						if(fleetDataDtoList.get(j).getAirspeed() >100){
							endTakeoffElapsedTime = fleetDataDtoList.get(j).getElapsedTime();
							takeOffRangeData.add(fleetDataDtoList.get(j));
							if((endTakeoffElapsedTime-startTakeoffElapsedTime)<20){
								continue inner;
							}
							//Airspeed >100 continuously for a period of at least 20 seconds
							endTakeoffPressureAltitude = fleetDataDtoList.get(j).getPressureAltitude();
							if((endTakeoffPressureAltitude-startTakeoffPressureAltitude)>=200){
								//pressure altitude value has increased by at least 200 feet
								System.out.println("flight takeoff data range found--> startTakeoffElapsedTime="+startTakeoffElapsedTime + " : endTakeoffElapsedTime="+endTakeoffElapsedTime);
								break outer;
							}
							continue inner;
						}
						continue outer;
					}//end of inner for loop	
				}
			}//end of outer for loop
			
			System.out.println("takeOffRangeData="+takeOffRangeData);
			
			System.out.println("----------------------------------------------------------------------");
			
			//landingDtoList = getDummyDataListLanding();
			//System.out.println("landingDtoList="+landingDtoList);
			
			Double startLandingElapsedTime = 0.0;
			Double endLandingElapsedTime = 0.0;
			Double startLandingPressureAltitude;
			Double endLandingPressureAltitude;
			
			int landinglistSize = fleetDataDtoList.size();
			
			outerlanding: for(int i=0; i<landinglistSize; i++){				
				if(fleetDataDtoList.get(i).getAirspeed() <85){
					landingRangeData = new ArrayList<FleetData2DTO>();
					startLandingElapsedTime = fleetDataDtoList.get(i).getElapsedTime();
					startLandingPressureAltitude = fleetDataDtoList.get(i).getPressureAltitude();
					landingRangeData.add(fleetDataDtoList.get(i));
					i++;
					
					innerlanding: for(int j=i; j<landinglistSize; j++){
						if(fleetDataDtoList.get(j).getAirspeed() <85){
							endLandingElapsedTime = fleetDataDtoList.get(j).getElapsedTime();
							landingRangeData.add(fleetDataDtoList.get(j));
							if((endLandingElapsedTime-startLandingElapsedTime)<20){
								continue innerlanding;
							}
							//Airspeed <85 continuously for a period of at least 20 seconds
							endLandingPressureAltitude = fleetDataDtoList.get(j).getPressureAltitude();
							if((endLandingPressureAltitude-startLandingPressureAltitude)<=25){
								//pressure altitude value has changed by at most 25 feet
								System.out.println("flight landing data range found--> startLandingElapsedTime="+startLandingElapsedTime + " : endLandingElapsedTime="+endLandingElapsedTime);
								break outerlanding;
							}
							continue innerlanding;
						}
						continue outerlanding;
					}//end of inner for loop	
				}
			}//end of outer for loop
			
			System.out.println("landingRangeData="+landingRangeData);
			
			Double airborneFltSegmentDuration;
			airborneFltSegmentDuration = startLandingElapsedTime - startTakeoffElapsedTime;
			
			objMap = new HashMap<String, Object>();
			objMap.put("startTakeoffElapsedTime", startTakeoffElapsedTime);
			objMap.put("endTakeoffElapsedTime", endTakeoffElapsedTime);
			objMap.put("startLandingElapsedTime", startLandingElapsedTime);
			objMap.put("endLandingElapsedTime", endLandingElapsedTime);
			objMap.put("airborneFltSegmentDuration", airborneFltSegmentDuration);
			flightSegmentsDatList.add(objMap);
			
			
			System.out.println("AircraftService.getFlightSegments() : end");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return flightSegmentsDatList;
	}

	
}
