app.controller('businessController', function($scope, $filter, $http, $rootScope,constants,
		$state, Auth, $timeout, toaster, $cookies, $cookieStore, WorkFlow, supplier) {
	$scope.loader=true;
	$rootScope.businessInfoDone = false;
	$scope.showCommodity = false;
	$scope.showSubCommodity = false;
	$scope.supplierInfo = {};
	//commodities levels
	
	Auth.getRoles().then(function(roles){ 
    	if(!WorkFlow.getRequestId()){

    		toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
			
			if (Auth.isSupplierRole(roles.roles)){
	       		$state.go('supplierHome');
	    	}else{
	        	$state.go('homePage');
	    	}
	    	return;
	    }

	    if (Auth.isSupplierRole(roles.roles)){
	       	$state.go('supplierHome');
	    }

	}, function(data){
    	$scope.loader=false;
    });

	supplier.getCommoditiesFamilyList().then(function(data){
		$scope.commoditiesFamilyList = data;
	}, function() {
		$scope.loader=false;
		toaster.pop('error', "Commodities list", "server not responding");
	});
	
	$scope.onCommodityFamilyChangeCode=function(id){
		$scope.loader=true;
		if(id==undefined){
			$rootScope.commodityList = [];
			$rootScope.commoditySubList = [];
			$scope.supplierInfo.commodity = "";
			$scope.loader=false;
			return;
		}else{
			$scope.supplierInfo.commodityFamily=id;
		  	$scope.getCommoditySubList(id);
		}  	
	}
	$scope.loadNextCommodity = function(level, id){
		$scope.loader=true;
    	if(id==undefined){
    		$scope[level] = [];
    		$scope.supplierInfo.commodity = "";
    	 	$scope.loader=false;
			return;
		}else{
			supplier.getCommoditiesSubList(id).then(function(data){
				if(data.length <= 0){
					$scope.showCommodity = false;
					//$scope.showSubCommodity =false;
				}else{
					$scope.showSubCommodity = true;
					$scope[level] = data;
					$scope.loader=false;
				}
			}, function() {
				$scope.loader=false;
			});
		}
	} 
	$scope.getCommoditySubList=function(id){
		$scope.loader=true;
    	if(id==undefined){
    		$rootScope.commoditySubList = [];
    		$rootScope.commodityList = [];
    		$scope.supplierInfo.commodity = null;
    	 	$scope.loader=false;
			return;
		}else{
	    	$rootScope.commoditySubList=[];
	    	$scope.supplierInfo.commoditySubList = "";
	    	$scope.supplierInfo.commodity =null;
			supplier.getCommoditiesSubList(id).then(function(data){
				$rootScope.commoditySubList = data;
				if($rootScope.commoditySubList.length<=0){
					$scope.showSubCommodity = false;
				}else{
					$scope.showSubCommodity =true;
				}
				$scope.loader=false;
			}, function() {
				$scope.loader=false;
				toaster.pop('error', "Commodities sub list", "server not responding");
			});
		}
     }
     $scope.getCommoditiesList=function(id){
    	$scope.loader=true;
    	if(id==undefined){
    		$rootScope.commodityList = [];
    		$rootScope.commoditySubList = [];
    		$scope.supplierInfo.commodity = null;
    	 	$scope.loader=false;
			return;
		}else{
	 		supplier.getCommoditiesSubList(id).then(function(data){
	 			$scope.loader=false;
	 			$rootScope.commodityList = data;
	 			if($rootScope.commodityList.length<= 0){
	 			$scope.showCommodity = false;}
	 			else{
	 				$scope.showCommodity = true;
	 			}
			}, function() {
				$scope.loader=false;
				toaster.pop('error', "commodity list", "server not responding");
			});
		} 
     }
	//business level
	supplier.getBusinessList1().then(function(data){
		$scope.businessList1 = data;
	}, function() {
		$scope.loader=false; 
		toaster.pop('error', "Business Root list", "server not responding");
	});

	$scope.onbusinessList1ChangeCode=function(id){
		$scope.loader=true;
		$rootScope.businessTableList = [];
		if(id==undefined){
			$scope.loader=false;
			return;
		}else{
			$scope.getBusinessList2(id);
		}
	}
     $scope.getBusinessList2=function(id){
    	$scope.loader=true;
    	if(id==undefined){
    		$rootScope.businessList2 = [];
    		$rootScope.businessList3=[];
    		$rootScope.businessTableList = [];
    	 	$scope.loader=false;
			return;
		}else{
    		supplier.getBusinessSubList(id).then(function(data){
    			$rootScope.businessList2 = data;
    			$scope.loader=false;
    		}, function() {
    			$scope.loader=false;
    			toaster.pop('error', "Business sub list", "server not responding");
    		});
    	}
     }
     $scope.getBusinessList3=function(id){
    	$scope.loader=true;
    	if(id==undefined){
    		$rootScope.businessList3=[];
    		$rootScope.businessTableList = [];
    	 	$scope.loader=false;
			return;
		}else{
	 		supplier.getBusinessSubList(id).then(function(data){
	 			$rootScope.businessList3 = data;
	 			$scope.loader=false;
			}, function() {
				$scope.loader=false;
				toaster.pop('error', "Business sub list", "server not responding");
			}); 
		}
     }
    //$rootScope.businessTableList=[];
     $scope.getBusinessList4=function(id){
     	$scope.loader=true;
     	if(id==undefined){
     		$rootScope.businessTableList = [];
     		$scope.loader=false;
			return;
		}else{
	    	$rootScope.businessTableList=[];
	  		supplier.getBusinessSubListNew(id).then(function(data){			
	  			$rootScope.businessTableList = data;
	  			if(WfModel.subscription != null){
	  				if(WfModel.subscription.erpId > 0){
						angular.forEach($rootScope.businessTableList, function(item, key){
							if(parseInt(WfModel.subscription.erpId[0]) == item.id){
								item.selected = true;	
								$scope.select(item);
							}
						})
					}
	  			}
	  			$scope.loader=false;
	 		}, function() {
	 			$scope.loader=false;
	 			toaster.pop('error', "Business sub list", "server not responding");
	 		}); 
	 	}
      }
	
	$scope.loadNextLevels = function(level, id){
		$scope.loader=true;
		if(id==undefined){
			$scope[level] = [];
			$scope.supplierInfo.businessLevel3 = '';
			$scope.loader=false;
			return;
		}else{
			supplier.getBusinessSubList(id).then(function(data){
				$scope[level] = data;
				$scope.loader=false;
			}, function() {
				$scope.loader=false;
				toaster.pop('error', "Business sub list", "server not responding");
			});
		}
	} 
	
	
	$scope.erpData = [{},{},{}];
	$scope.populateErpTable = function (item, postition) {
		$scope.erpData[postition]= item;
		
	}
	//FOR SELECTED ROW
	
 	$scope.select = function(item) {
 		$scope.erpId = [];
 		angular.forEach($rootScope.businessTableList, function(item, key){
 			item.selected = false
 		})
     	item.selected = true;
     	$scope.erpId.push(item.id);
   	}

	$scope.save = function(supplierInfo, next, form) {
		$scope.submitted = true;		
		
		if(form.$invalid) {
				toaster.pop('error', "", "Please fill all values");	
				return;
		}	
		
		if(!supplierInfo.commodityFamily && !supplierInfo.businessLevel1 && !supplierInfo.businessLevel2 && !supplierInfo.businessLevel3) {
			toaster.pop('error', "", "Please fill all values");	
			return;
		}
		if($scope.erpId == undefined){
			toaster.pop('error', "Business Level 4", "Please select one Erp");	
			return;
		}		
		$scope.loader=true;
		$cookieStore.put("commodityFamilyId", supplierInfo.commodityFamily);	

		WfModel.subscription = (WfModel.subscription==null)?{}:WfModel.subscription;
		// if(supplierInfo.commoditySubList == undefined || supplierInfo.commoditySubList == NaN || supplierInfo.commoditySubList == ""){
		// 	WfModel.subscription.commodities = [supplierInfo.commodityFamily];
		// }
		// else if(supplierInfo.commodity == undefined || supplierInfo.commodity == NaN){
		// 	WfModel.subscription.commodities = [supplierInfo.commodityFamily, supplierInfo.commoditySubList];
		// }else{
		// 	WfModel.subscription.commodities = [supplierInfo.commodityFamily, supplierInfo.commoditySubList, supplierInfo.commodity];	
		// }
		WfModel.subscription.commodityTier1Id = $scope.supplierInfo.commodityFamily?$scope.supplierInfo.commodityFamily:"";
		WfModel.subscription.commodityTier2Id = $scope.supplierInfo.commoditySubList?$scope.supplierInfo.commoditySubList:"";
		WfModel.subscription.commodityTier3Id = $scope.supplierInfo.commodity?$scope.supplierInfo.commodity: null;
		WfModel.subscription.businessLevels = [supplierInfo.businessLevel1, supplierInfo.businessLevel2, supplierInfo.businessLevel3];
		// var tempData = [];
		// for (var i = 0; i <$rootScope.businessTableList.length; i++){
		// 	//$rootScope.businessTableList[i].id = i;
		// 	tempData.push($rootScope.businessTableList[i].id);
		// }
		//WfModel.subscription.erpId = [$rootScope.businessTableList[0].id];	
		WfModel.subscription.erpId = $scope.erpId;	
		WfModel.supplier.prototype = supplierInfo.prototyping;			
		WorkFlow.setVariablesV2(WfModel).then(function(data) {
			$rootScope.businessInfoDone = true;
			if(next){
				$state.go('compliance');
			}
			toaster.pop('success', "Saved successfully");	
			$scope.loader=false;
		},function(data){
			$scope.loader=false;
			toaster.pop('error','WorkFlow API', "Server not Responding ");
		});
		

	}

	$scope.prevForBusinessInfo=function(){
		$state.go('supplierInfo');
	}
		
	/*	
	WorkFlow.getHistory(WorkFlow.getInstance()).then(function(workflowData) {
		if(workflowData.data.length>0){		
			console.log(workflowData.data[0].variables);
			$scope.supplierInfo = WorkFlow.makeModel(workflowData.data[0].variables);
			console.log($scope.supplierInfo);		
		}

	}, function(data) {
	});
	*/

	var WfModel = {};
	WorkFlow.getVariablesV2().then(function(workflowData) {
		$rootScope.businessInfoDone = false;
		$scope.loader = true;
		WfModel = workflowData.data;
		if(workflowData.data){	
			$scope.supplierInfo.prototyping = (WfModel.supplier.prototype)?WfModel.supplier.prototype:false; 
			//$scope.supplierInfo.commodity = supplier.getDiligence(WfModel.dueDiligences, 'commodityFamily');				
			if(WfModel.subscription) {
				// // if(WfModel.subscription.commodities.length < 2){
				// 	$scope.supplierInfo.commodityFamily = parseInt(WfModel.subscription.commodities[0]);
				// // }else if(WfModel.subscription.commodities.length < 3){
				// 	$scope.supplierInfo.commodityFamily = parseInt(WfModel.subscription.commodities[0]);
				// 	$scope.onCommodityFamilyChangeCode($scope.supplierInfo.commodityFamily);
				// 	$scope.loadNextCommodity('commoditySubList', $scope.supplierInfo.commodityFamily);
				// 	$scope.supplierInfo.commoditySubList = parseInt(WfModel.subscription.commodities[1]);
				// // }else{
				if(WfModel.subscription.commodityTier1Id != null && WfModel.subscription.commodityTier2Id != null && WfModel.subscription.commodityTier3Id != null){
					$scope.supplierInfo.commodityFamily = parseInt(WfModel.subscription.commodityTier1Id);
					$scope.onCommodityFamilyChangeCode($scope.supplierInfo.commodityFamily);
					$scope.loadNextCommodity('commoditySubList', $scope.supplierInfo.commodityFamily);
					$scope.supplierInfo.commoditySubList = parseInt(WfModel.subscription.commodityTier2Id);
					$scope.getCommoditiesList($scope.supplierInfo.commoditySubList);
					$scope.loadNextCommodity('commodity', $scope.supplierInfo.commoditySubList);
					$scope.supplierInfo.commodity = parseInt(WfModel.subscription.commodityTier3Id);
				}
				
				if(WfModel.subscription.businessLevels.length > 0){
					$scope.supplierInfo.businessLevel1 = parseInt(WfModel.subscription.businessLevels[0]);
					$scope.onbusinessList1ChangeCode($scope.supplierInfo.businessLevel1);
					$scope.loadNextLevels('businessList2', $scope.supplierInfo.businessLevel1);
					$scope.supplierInfo.businessLevel2 = parseInt(WfModel.subscription.businessLevels[1]);
					$scope.getBusinessList3($scope.supplierInfo.businessLevel2);
					$scope.loadNextLevels('businessList3', $scope.supplierInfo.businessLevel2)
					$scope.supplierInfo.businessLevel3 = parseInt(WfModel.subscription.businessLevels[2]);
					$scope.getBusinessList4($scope.supplierInfo.businessLevel3);	
				}
				
			}
		}
		$rootScope.supplierInfoDone = true;
		$scope.loader=false;
		
	}, function(data) {
		$scope.loader=false;
		$rootScope.businessInfoDone = false;
	});

});

