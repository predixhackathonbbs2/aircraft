

var jsonObj;
var testData;
var testDataMultiple;
var charts;
var flightId ;
var xaxis;
var yaxis ;
var title;
var scatterText;
var graphData2;
var flightIdOuter;
var minelapseTimeOuter;
var maxelapseTimeOuter;
var sumoObj;
var yaxisArray;
var xaxisArray;
var scatterArray1;
var testDataMultipleLineGraph;
var multipleArrayChartData;
var chartCategories12;
var multiLineArrayAxis;
var chartTitlesArray;
var textTitleSingleGraph;
var dynamicFlightId
 var avg=0;

 $(document).ready(function () {
$("#xaxisId").hide();
$("#xaxisdataval").hide();
$("#yaxisId").hide();
$("#yaxisdataval").hide();
$("#radiochartId").hide();
$("#multigraph").hide(); 
$("#scatterGraph2").hide();
$("#multigraphForMultiline").hide();
$("#radiochartIdData").hide();
$("#showchartIdForMultiLine").hide();
$("#container1").hide();
$("#container2").hide();
$("#container3").hide();
$("#container4").hide();
$("#container5").hide();




$("#poc2IDclick").click(function(){
loadDynamicflightId();
$("#liId1").addClass('active');
$("#liId2").removeClass('active');
$("#liId3").removeClass('active');
$("#liId4").removeClass('active');

$("#flightIdLabelDiv").show();
$("#flighIdSelectDiv").show();

$("#xaxisId").hide();
$("#xaxisdataval").hide();
$("#yaxisId").hide();
$("#yaxisdataval").hide();
	
	if($("#liId1").hasClass('active')){
	$("#sigleGraph").show();
	
	}
	
	
	
	$("#multigraph").hide(); 
	$("#multigraphForMultiline").hide();
	$("#showchartIdForMultiLine").hide();
	$("#scatterGraph2").hide();
	$("#sigleGraph").show();
	
	
$("#radiochartId").hide();
$("#radiochartIdData").hide();
$("#container1").hide();
$("#container2").hide();
$("#container3").hide();
$("#container4").hide();
$("#container5").hide();
$("#flightId").val(0);
$("#flightIdGraph2").val(0);
$("#flightId1").val(0);
$("#flightIdForMultiLine").val(0);
$("#loadingChart5").show();





});






/****************************For Grpah1 Click Event ***************/
$("#graphID").click(function(){
$('#flightId').find('option:not(:first)').remove();
for (var i = 0; i < dynamicFlightId.length; i++) {
					$('#flightId').append($('<option>', { 
						value: JSON.stringify(dynamicFlightId[i].flightId),
						text : JSON.stringify(dynamicFlightId[i].flightId)
				}));
 }
	 $("#sigleGraph").show();
	$("#flighIdSelectDiv").show();
	$("#flightIdLabelDiv").show();
	$("#radiochartId").hide();
	$("#flightId").val(0);
	$("#yaxisData").val(0);
	$('input[name="chart"]').attr('checked', false);
	$("#xaxisId").hide();
	$("#xaxisdataval").hide();
	$("#radiochartIdData").hide();
	$("#yaxisId").hide();
	$("#yaxisdataval").hide();
	$("#scatterGraph2").hide();
	$("#multigraph").hide();
	$("#container4").hide();
	$("#container3").hide();
	$("#container5").hide();
	$("#multigraphForMultiline").hide();

}); 
/****************************For Showing the seleted Tab***************/
$("#graphTab a").click(function(e){
    	e.preventDefault();
    	$(this).tab('show');	
 });

/******************FightId Change for Single Graph *************/
$("#flightId").change(function(){
	
		$("#container1").hide();
		$("#xaxisId").hide();
		$("#xaxisdataval").hide();
		$("#yaxisId").hide();
		$("#yaxisdataval").hide();
		$("#radiochartId").hide();
		var flightIdVal=$(this).val();
		$("#loadingChart").show();
		getYaxisData(flightIdVal);
		
		$("#yaxisData").val(0);
		$('input[name="chart"]').attr('checked', false);
});
/******************END Of FightId Change for Single Graph *************/
/******************Start Y-Axis  Change for Single Graph *************/
$("#yaxisData").change(function(){
			yaxisArray = [];
		    xaxisArray = [];
			var textTitle;
			var yaxisText=$("#yaxisData :selected").text();
			
			scatterArray1 = new Array(); 
			$("#radiochartId").show();
			var xaxisval;
			if($("#graphID").parent().hasClass("active")){  
			   xaxisval=$("#elapseTime").val();
			}else if($("#graph2ID").parent().hasClass("active")){
			  xaxisval=$("#multipleXaxis").val();
			}
			if ($("#flightId").val() != 0 &&  xaxisval != 0 && $("#yaxisData").val() != 0) {
                    flightId = $("#flightId").val();
                    xaxis = xaxisval;
                    yaxis = $("#yaxisData").val();
                    myJsonString = JSON.stringify(testData);
                    for (var i = 0; i < testData.length; i++) {
                        //console.log(testData[i][yaxis]);
						yaxisArray.push(parseFloat(testData[i][yaxis]));
						//xaxisArray.push(parseFloat(testData[i].elapsedTime));
						xaxisArray.push(parseFloat(testData[i][xaxis]));
						scatterArray1.push([parseFloat(testData[i][xaxis]),parseFloat(testData[i][yaxis])]);
					
                    }
					
                }
				chartData=[{ name: yaxis, type: 'line', data: yaxisArray}];
				textTitleSingleGraph="Elapsed Time Vs"+" "+yaxisText;
				
				//setLineChart(xaxisArray,yaxis,chartData,textTitleSingleGraph);
				scatterChartDraw(scatterArray1,yaxis,textTitleSingleGraph);
				setLineChart1(scatterArray1,yaxis,textTitleSingleGraph);
		});
		
		
		/*--------Radio Button For Line Chart-------------------------*/
		$("#linechartID").click(function (event) {
			$("#container2").hide();
			$("#container1").show();
			chartData=[{ name: yaxis, type: 'line', data: yaxisArray }];
			//setLineChart(xaxisArray,yaxis,chartData,textTitleSingleGraph); 
			setLineChart1(scatterArray1,yaxis,textTitleSingleGraph);
		}); 
		
		/*--------Radio Button For Scatter Chart-------------------------*/
		$("#scatterchartID").click(function (event) {
		$("#container1").hide();
		$("#container2").show();
		//chartData=[{ name: yaxis,type: 'scatter', data: yaxisArray }];
		scatterChartDraw(scatterArray1,yaxis,textTitleSingleGraph);
		}); 
		
		
	/****************************For Grpah2 Click Event ***************/
$("#graph2ID").click(function(){
$('#flightIdGraph2').find('option:not(:first)').remove();
		for (var i = 0; i < dynamicFlightId.length; i++) {
					$('#flightIdGraph2').append($('<option>', { 
						value: JSON.stringify(dynamicFlightId[i].flightId),
						text : JSON.stringify(dynamicFlightId[i].flightId)
				}));
          }


	$("#sigleGraph").hide();
	$("#scatterGraph2").show();
	$("#xaxisdivGraph2").hide();
	$("#xaxisdatavalGraph2").hide();
	$("#yaxisdivGraph2").hide();
	$("#yaxisdatavalForGraph2").hide();
	$("#startelapsetimediv").hide();
	$("#startelapsetimetext").hide();
	$("#endelapsetimediv").hide();
	$("#endelapsetimetext").hide();
	$("#flightIdGraph2").val(0);
	$("#radiochartId").hide();
	$("#multigraph").hide();
	 $("#radiochartIdData").hide();
	//$('select.SlectBox')[0].sumo.reload();
	jQuery("#errorVaildxaxis").text('');
	jQuery("#errorVaildyaxis").text('');
	jQuery("#errorValidateparameter").text('');
	jQuery("#errorelapseTime").text('');
	$("#multigraphForMultiline").hide();
	$("#container1").hide();
	$("#container2").hide();
	$("#container4").hide();
	$("#container3").hide();
	$("#container5").hide();
	

}); 	
		
		
			
/******************FightId Change for Single Graph2 Scatter Graph *************/	
		
	$("#flightIdGraph2").change(function(){
		$("#container4").hide();
		var flightIdVal=$(this).val();
		$("#loadingChart1").show();
		getMaxElapseTimeForFlightId(flightIdVal);
		
		});	
		
		
		
		
			 
	$("#xaxisDatagraph2").change(function(){
			validateData();
			if($("#xaxisDatagraph2").val()=='0'){
				$("#container4").hide();
			}else{
			jQuery("#errorVaildxaxis").text('');
			jQuery("#errorValidateparameter").text('');
			jQuery("#errorelapseTime").text('');
			flightIdOuter=$("#flightIdGraph2").val();
			minelapseTimeOuter=$("#minelapseTime").val();
			maxelapseTimeOuter=$("#maxelapseTime").val();
			$("#yaxisDataGraph2").val(0);
			$("#container4").hide();
			getScatterChartForGraph2(flightIdOuter,minelapseTimeOuter,maxelapseTimeOuter);
			
			}
			
			
	});
			
			
	/******************Y-Axis  Change for Scatter Chart *************/ 
$("#yaxisDataGraph2").change(function(){
		if($("#yaxisDataGraph2").val()=='0'){
			 $("#container4").hide();
			  return false;
		}
		if($("#xaxisDataGraph2").val()=='0'){
			 $("#container4").hide();
			  return false;
		}
		if($("#xaxisDatagraph2").val()==$("#yaxisDataGraph2").val()){
			    jQuery("#errorVaildyaxis").text('Same parameter not allowed;please select another parameter');
				 $("#container4").hide();
				 return false;
		}
		validateData();
			var yaxisArrayGarph2 = [];
			var xaxisArrayGraph2 = [];
			 var flightId;
			 var minelapseTime;
			 var maxelapseTime;
			 var scatterArrayGraph1 = new Array(); 
			 var xaxisid;
			 var yaxisid;
			 var textTitle;
			 var xaxixgraph2Text;
			 var yaxisgraph2Text;
			flightId=$("#flightIdGraph2").val();
			minelapseTime=$("#minelapseTime").val();
			maxelapseTime=$("#maxelapseTime").val();
			xaxisid=$("#xaxisDatagraph2").val();
			yaxisid=$("#yaxisDataGraph2").val();
			xaxixgraph2Text=$("#xaxisDatagraph2 :selected").text();
			yaxisgraph2Text=$("#yaxisDataGraph2 :selected").text();
			textTitle=xaxixgraph2Text+" "+"vs"+" "+yaxisgraph2Text;
			
			if(minelapseTime!=minelapseTimeOuter || maxelapseTime!=maxelapseTimeOuter){
		
			 $("#loadingChart2").show();
			 var predixurl="https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/view/getFlightPlottingDataElapsedTime";
			 
			 $.ajax({
				url:predixurl+"/"+flightId+"/"+minelapseTime+"/"+maxelapseTime,
               type: "get", 
              success: function(responseData) {
			 
			  $("#loadingChart2").hide();						
				for (var i = 0; i < responseData.length; i++) {
					yaxisArrayGarph2.push(parseFloat(responseData[i][yaxisid]));
					xaxisArrayGraph2.push(parseFloat(responseData[i][xaxisid]));
					scatterArrayGraph1.push([parseFloat(responseData[i][xaxisid]),parseFloat(responseData[i][yaxisid])]);
              }
				$("#container4").show();
			   scatterchartForGraph2(scatterArrayGraph1,xaxisid,yaxisid,textTitle);
		
				},
               error: function ( xhr, status, error) {
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				$("#loadingChart2").hide();
				}
				});
	
			}else{
			    for (var i = 0; i < graphData2.length; i++) {
					yaxisArrayGarph2.push(parseFloat(graphData2[i][yaxisid]));
					xaxisArrayGraph2.push(parseFloat(graphData2[i][xaxisid]));
					scatterArrayGraph1.push([parseFloat(graphData2[i][xaxisid]),parseFloat(graphData2[i][yaxisid])]);
               }
				$("#container4").show();
			   scatterchartForGraph2(scatterArrayGraph1,xaxisid,yaxisid,textTitle);
			}		
			
			
	 
});
		
		
jQuery('#minelapseTime').on('input', function() {
				$("#xaxisDatagraph2").val(0);
				$("#yaxisDataGraph2").val(0);
			});
jQuery('#maxelapseTime').on('input', function() {
				$("#xaxisDatagraph2").val(0);
				$("#yaxisDataGraph2").val(0);
			});		
		
		
		
/****************************For Grpah3 Click Event For Multi Graph***************/
$("#graph3ID").click(function(e){
	$('#flightId1').find('option:not(:first)').remove();	
	for(var i = 0; i < dynamicFlightId.length; i++) {
					$('#flightId1').append($('<option>', { 
						value: JSON.stringify(dynamicFlightId[i].flightId),
						text : JSON.stringify(dynamicFlightId[i].flightId)
				}));
     }
		
		
		$("#flightIdForMultiLine").val(0);
	    $("#flightId1").val(0);
		$("#flighIdSelectDiv").hide();
		$("#flightIdLabelDiv").hide();
		$("#xaxisIdMulti").hide();
		$("#xaxisdatavalMulti").hide();
		$("#yaxisIdMulti").hide();
	    $("#yaxisdatavalMulti").hide();
		$("#xaxisId").hide();
		$("#xaxisdataval").hide();
		$("#yaxisId").hide();
		$("#yaxisdataval").hide();
		$("#radiochartId").hide();
    	$("#multigraph").show();
		$("#container1").hide();
		$("#container2").hide();
		$("#container4").hide();
		$("#container3").hide();
		$("#container5").hide();
		 $("#radiochartIdData").hide();
		$("#scatterGraph2").hide();
		$("#xaxisdatavalgraph1").hide();
		jQuery("#errorVaildxaxis").text('');
		jQuery("#errorVaildyaxis").text('');
		jQuery("#errorValidateparameter").text('');
		jQuery("#errorelapseTime").text('');	
		$("#multigraphForMultiline").hide();
		
		
				
    });
		
	/****************************For FLIGHTID Change Event For Multi Graph***************/
$("#flightId1").change(function(){
			$("#container3").hide();
			$("#xaxisIdMulti").hide();
			$("#xaxisdatavalMulti").hide();
			$("#yaxisIdMulti").hide();
			$("#yaxisdatavalMulti").hide();
		    var flightIdVal=$(this).val();
		    $("#loadingChart3").show();
		    getYaxisDataForMultiple(flightIdVal);
			$('.SlectBox').SumoSelect();
			$('select.SlectBox')[0].sumo.unSelectAll();
			$("#container3").hide();	
	});		
		
		
		/****************************For SelectBox mutiple checkbox click Event For Multi Graph***************/		
/*$("#langOpt").change(function(){
	var yaxisVal;
	var flightId;
	var yaxisVal;
	var arrayyaxis;
	if($(this).val()!=0){
		var multipleYaxisArrya=[];
		var multiplexaxisArray = [];
		var chartCategories11;
	
		flightId = $("#flightId1").val();
		xaxis = $("#elapseTime1").val();
		yaxisVal=$("#langOpt").val();
		if(yaxisVal != null){
			arrayyaxis=yaxisVal.toString().split(",");
			for(var i = 0; i < arrayyaxis.length; i++){	
				var yaxisArray = [];
				for (var j = 0; j < testDataMultiple.length; j++) {
					 yaxisArray.push(parseFloat(testDataMultiple[j][arrayyaxis[i]]));
					if(i==0){
						multiplexaxisArray.push(parseFloat(testDataMultiple[j].elapsedTime));
					 }
				}
				multipleYaxisArrya.push({name: arrayyaxis[i], data: yaxisArray });	

			
           				
			}			
		}		
		
	 chartCategories11 = multiplexaxisArray;	
	setMultipleLineChart(chartCategories11,multipleYaxisArrya);  
      //$("#radiochartId").hide();
	   
   	
	}else{
			$("#radiochartId").hide();
	}
	
	});*/
	/*$("#langOpt").change(function(){
	var yaxisVal;
	var flightId;
	var yaxisVal;
	var arrayyaxis;
	if($(this).val()!=0){
		var multipleYaxisArrya=[];
		var multiplexaxisArray = [];
		var chartCategories11;
	
		flightId = $("#flightId1").val();
		xaxis = $("#elapseTime1").val();
		yaxisVal=$("#langOpt").val();
		if(yaxisVal != null){
			arrayyaxis=yaxisVal.toString().split(",");
			for(var i = 0; i < arrayyaxis.length; i++){	
				var yaxisArray = [];
				for (var j = 0; j < testDataMultiple.length; j++) {
					yaxisArray.push([parseFloat(testDataMultiple[j].elapsedTime),parseFloat(testDataMultiple[j][arrayyaxis[i]])]);
				
				}
				multipleYaxisArrya.push({name: arrayyaxis[i], data: yaxisArray });	

			
           				
			}			
		}		
		
	 chartCategories11 = multiplexaxisArray;	
	setMultipleLineChart(chartCategories11,multipleYaxisArrya);  
      //$("#radiochartId").hide();
	   
   	
	}else{
			$("#radiochartId").hide();
	}
	
	});	*/
	
	
	$("#langOpt").change(function(){
	var yaxisVal;
	var flightId;
	var yaxisVal;
	var arrayyaxis;
	var parameterAvg=0;
	var thersHoldVal=250;
	var averageArrayPush=[];
	var arrayData;

	if($(this).val()!=0){
		var multipleYaxisArrya=[];
		var multiplexaxisArray = [];
		var chartCategories11;
	
		flightId = $("#flightId1").val();
		xaxis = $("#elapseTime1").val();
		yaxisVal=$("#langOpt").val();
		if(yaxisVal != null){
			arrayyaxis=yaxisVal.toString().split(",");
			for(var i = 0; i < arrayyaxis.length; i++){	
				var yaxisArray = [];
				for (var j = 0; j < testDataMultiple.length; j++) {
					
					//averageArrayPush.push(parseFloat(testDataMultiple[j][arrayyaxis[i]]));
					
				   // arrayData=JSON.stringify(averageArrayPush);
					
					//calculateAverage(arrayData);
					
					//console.log(calculateAverage(averageArrayPush)+"++++++++++++++++");
					
					/*if(calculateAverage(averageArrayPush)<=thersHoldVal){
			
						alert("called");
					}else{
						
							alert("else called");
					}*/
					
				
					yaxisArray.push([parseFloat(testDataMultiple[j].elapsedTime),parseFloat(testDataMultiple[j][arrayyaxis[i]])]);
				
				}
				multipleYaxisArrya.push({name: arrayyaxis[i], data: yaxisArray });	

				
			
			
           				
			}		

					
		}		
		
	 chartCategories11 = multiplexaxisArray;	
	setMultipleLineChart(chartCategories11,multipleYaxisArrya);  
      //$("#radiochartId").hide();
	   
   	
	}else{
			$("#radiochartId").hide();
	}
	
	});
	
	
		
		
		/****************************For Grpah4 Click Event ***************/
$("#graph4ID").click(function(){
$('#flightIdForMultiLine').find('option:not(:first)').remove();
for (var i = 0; i < dynamicFlightId.length; i++) {
$('#flightIdForMultiLine').append($('<option>', { 
value: JSON.stringify(dynamicFlightId[i].flightId),
text : JSON.stringify(dynamicFlightId[i].flightId)
}));
}
	$("#container1").hide();
	$("#container2").hide();
	$("#container4").hide();
	$("#container3").hide();
	$("#container5").hide();
	$("#radiochartIdData").hide();
	$("#multigraphForMultiline").show();
	$("#multiflightIdMultiLine").show();
	$("#flightIdForMultiLine").show();
	$("#xaxisIdMultiLine").hide();
	$("#xaxisIdMultiLine").hide();
	$("#xaxisdatavalMultiLine").hide();
	$("#yaxisIdMultiLine").hide();
	$("#yaxisdatavalMultiLine").hide();
	$("#multigraph").hide();
	$("#sigleGraph").hide();
	$("#showchartIdForMultiLine").hide();
	$("#radiochartId").hide();
	$("#scatterGraph2").hide();
	$("#flightIdForMultiLine").val(0);
		

}); 
		
		/****************************For FLIGHTID Change Event For Multi LINE Graph***************/
$("#flightIdForMultiLine").change(function(){			
		    var flightIdVal=$(this).val();
		    $("#loadingChart4").show();
		    getYaxisDataForMultiLineGraph(flightIdVal);
			$('.SlectBox1').SumoSelect();
			$('select.SlectBox1')[0].sumo.unSelectAll();
			//$("#container5").hide();
			
			if($('#container3').highcharts() === undefined){
				
			}else{
				$('#container3').highcharts().destroy();
			}
	});		
	
	/****************************For SelectBox mutiple checkbox click Event For Multi Line Graph***************/		
$("#selectdata").change(function(){
	
	var yaxisVal;
	var flightId;
	var yaxisVal;
	var arrayyaxis;
	var yaxisArray;
	if($(this).val()!=0){
	$("#container1").hide();
	$("#container2").hide();
	$("#container3").hide();
	var multipleYaxisArrya=[];
	var multiplexaxisArray = [];
	chartCategories12;
	multipleArrayChartData=[];
	flightId = $("#flightId1").val();
	xaxis = $("#elapseTime1").val();
	yaxisVal=$("#selectdata").val();
	chartTitlesArray=[];
		if(yaxisVal != null){
			arrayyaxis=yaxisVal.toString().split(",");
			for(var i = 0; i < arrayyaxis.length; i++){	
				 yaxisArray = [];
				for (var j = 0; j < testDataMultipleLineGraph.length; j++) {
					 yaxisArray.push([parseFloat(testDataMultipleLineGraph[j].elapsedTime),parseFloat(testDataMultipleLineGraph[j][arrayyaxis[i]])]);
				}
				multipleArrayChartData.push(yaxisArray);
				chartTitlesArray.push(arrayyaxis[i]);
		
			}	
			
		}		
	 chartCategories12 = multiplexaxisArray;	
      $("#radiochartId").hide(); 
	  
	}else{
		$("#radiochartId").hide();
	}
	});
	
	$("#showChart").click(function (event) {
		$("#container5").empty();
		$("#container4").empty();
		$("#container3").empty();
		$("#container2").empty();
		$("#container1").empty();
		$("#container5").show();
		$('#container5').bind('mousemove touchmove touchstart', function (e) {
			 var chart, point, i, event;
            			 
			 for (i = 0; i < Highcharts.charts.length; i = i + 1) {
				 chart = Highcharts.charts[i];
				 if(chart=== undefined){
				 }else{
				 
				 
				 
				 event = chart.pointer.normalize(e.originalEvent); // Find coordinates within the chart
				 point = chart.series[0].searchPoint(event, true); // Get the hovered point				 
				 if (point) {
					point.highlight(e);
				 }
			 }
			 }
         });
         /**
         * Override the reset function, we don't need to hide the tooltips and crosshairs.
         */
         Highcharts.Pointer.prototype.reset = function () {
			return undefined;
         };
         
         /**
         * Highlight a point by showing tooltip, setting hover state and draw crosshair
         */
         Highcharts.Point.prototype.highlight = function (event) {
			 this.onMouseOver(); // Show the hover marker
			 this.series.chart.tooltip.refresh(this); // Show the tooltip
			 this.series.chart.xAxis[0].drawCrosshair(event, this); // Show the crosshair
         };
		formMultipleChart(chartCategories12,multipleArrayChartData,chartTitlesArray);
}); 
	
	
 });///End OF Document Ready Function/////

 
 function calculateAverage(parameterArray){
	
	
	 var sum =0;
	 for( var i = 0; i < parameterArray.length; i++ ){
			sum += parameterArray[i];
		}
	console.log(sum);
		avg = sum / parameterArray.length;
	
	
	 console.log(avg);
	 
	 
 }
 

 
 ///All  Function Declare Here.
function getYaxisData(flightIdVal){
			
				var predixurl="https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/view/getFlightPlottingData";
				$.ajax({
				url:predixurl+"/"+flightIdVal,
                type: "get", 
                success: function(responseData) {
				testData=responseData;
				$("#loadingChart").hide();
				$("#xaxisId").show();
				$("#xaxisdataval").show();
				$("#yaxisId").show();
				$("#yaxisdataval").show();
				},
 
                error: function ( xhr, status, error) {
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				$("#loadingChart").hide();
				}
 				});
		
	}
function scatterChartDraw(scatterArray1,yaxisval,texttitle){
Highcharts.chart('container2', {
chart: {
type: 'scatter',
zoomType: 'xy'
},
title: {
	text: texttitle
},
xAxis: {
title: {
enabled: true,
text: 'Elapsed Time'
},
labels:{
			format: '{value} sec'
},
startOnTick: true,
endOnTick: true,
showLastLabel: true
},
yAxis: {
title: {
text: yaxisval
}
},
series: [
{
name: texttitle,
//color: 'rgba(223, 83, 83, .5)',
data: scatterArray1
}
],
annotations: [{
            title: {
               // text: '<span style="">drag me anywhere <br> dblclick to remove</span>',
                style: {
                    color: 'red'
                }
            },
           // anchorX: "left",
          //  anchorY: "top",
          //  allowDragX: true,
         //   allowDragY: true,
        //    x: 515,
         //   y: 155
        }, {
            //title: 'drag me <br> horizontaly',
            //anchorX: "left",
          //  anchorY: "top",
           // allowDragY: false,
          //  allowDragX: true,
           // xValue: 4,
          //  yValue: 10,
          //  shape: {
            //    type: 'path',
           //     params: {
               //     d: ['M', 0, 0, 'L', 110, 0],
               //     stroke: '#c55'
               // }
            //}
        }
		
		]







});			
}



function setLineChart1(scatterArray1,yaxisval,texttitle){
Highcharts.chart('container1', {
chart: {
type: 'line',
zoomType: 'xy'
},
title: {
	text: texttitle
},
xAxis: {
title: {
enabled: true,
text: 'Elapsed Time'
},
labels:{
			format: '{value} sec'
},
startOnTick: true,
endOnTick: true,
showLastLabel: true
},
yAxis: {
title: {
text: yaxisval
}
},
series: [
{
name: texttitle,
//color: 'rgba(223, 83, 83, .5)',
data: scatterArray1
}
]});			
}







function setLineChart(xaxisArray,yaxis,chartData,textTitle){
	 Highcharts.chart('container1', {
		chart: {
        type: 'line',
        zoomType: 'xy'
    },

    title: {
        text: textTitle
    },

   
	 xAxis: {
        title: {
            text: 'Elapsed Time'
        },
		categories: xaxisArray,
		labels: {
			format: '{value} sec'
		}
    },

    yAxis: {
        title: {
            text: yaxis
        }
    },
   

    plotOptions: {
        series: {
            pointStart: 0
        }
    },

    series: chartData,
	annotations: [{
            title: {
                text: '<span style="">drag me anywhere <br> dblclick to remove</span>',
                style: {
                    color: 'red'
                }
            },
            anchorX: "left",
            anchorY: "top",
            allowDragX: true,
            allowDragY: true,
            x: 515,
            y: 155
        }, {
            title: 'drag me <br> horizontaly',
            anchorX: "left",
            anchorY: "top",
            allowDragY: false,
            allowDragX: true,
            xValue: 4,
            yValue: 10,
            shape: {
                type: 'path',
                params: {
                    d: ['M', 0, 0, 'L', 110, 0],
                    stroke: '#c55'
                }
            }
        }, {
            title: 'on point <br> drag&drop <br> disabled',
            linkedTo: 'high',
            allowDragY: false,
            allowDragX: false,
            anchorX: "center",
            anchorY: "center",
            shape: {
                type: 'circle',
                params: {
                    r: 40,
                    stroke: '#c55'
                }
            }
        }, {
            x: 100,
            y: 200,
            title: 'drag me <br> verticaly',
            anchorX: "left",
            anchorY: "top",
            allowDragY: true,
            allowDragX: false,
            shape: {
                type: 'rect',
                params: {
                    x: 0,
                    y: 0,
                    width: 55,
                    height: 40
                }
            }
        }]
	

});
 }
 function getMaxElapseTimeForFlightId(flightIdVal){
				var predixurl="https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/view/getFlightMinMaxElapsedTime";
				$.ajax({
				url:predixurl+"/"+flightIdVal,
                type: "get", 
                success: function(responseData) {
				$("#loadingChart1").hide();
				var obj = jQuery.parseJSON(JSON.stringify(responseData));
				$("#loadingChart").hide();
				$("#maxelapseTime").val(obj.maxElapsedTime);
				$("#minelapseTime").val(obj.minElapsedTime);
				$("#startelapsetimediv").show();
				$("#startelapsetimetext").show();
				$("#endelapsetimediv").show();
				$("#endelapsetimetext").show();
				$("#xaxisdivGraph2").show();
				$("#xaxisdatavalGraph2").show();
				$("#xaxisDatagraph2").val(0);
				$("#yaxisDataGraph2").val(0);
				},
 
                error: function ( xhr, status, error) {
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				$("#loadingChart").hide();
				}
 				});
		
	}
	
	function validateData(){

			if($("#minelapseTime").val()==''){
				jQuery("#errorelapseTime").text("StartElapse Time can not be blank");
				$("#yaxisDataGraph2").val(0);
				$("#xaxisDatagraph2").val(0);
			   return false;
			}else if($("#maxelapseTime").val()==''){
				jQuery("#errorelapseTime").text("End Elapse Time can not be blank");
				$("#yaxisDataGraph2").val(0);
				$("#xaxisDatagraph2").val(0);
			   return false;
			}else if(parseInt($("#minelapseTime").val())>parseInt($("#maxelapseTime").val())){
			  jQuery("#errorelapseTime").text("Start Elapsed Time can not be greater than End Elapsed Time!");
			  $("#yaxisDataGraph2").val(0);
			  $("#xaxisDatagraph2").val(0);
			   return false;
			}else if($("#xaxisDatagraph2").val()=='0'){
			 jQuery("#errorVaildxaxis").text('Please select X-axis.');
			  $("#yaxisDataGraph2").val(0);
			  $("#xaxisDatagraph2").val(0);
			  return false;
			}
			else if($("#yaxisDataGraph2").val()=='0'){
			// jQuery("#errorVaildyaxis").text('Please select Y-axis.');
			  $("#yaxisDataGraph2").val(0);
			 $("#container4").hide();
			  return false;
			}
			else if($("#xaxisDatagraph2").val()==$("#yaxisDataGraph2").val()){
			    jQuery("#errorValidateparameter").text('Same parameter not allowed;please select another parameter');
				$("#yaxisDataGraph2").val(0);
				//$("#xaxisDatagraph2").val(0);
				 return false;
			}else{
			jQuery("#errorVaildxaxis").text('');
			jQuery("#errorVaildyaxis").text('');
			jQuery("#errorValidateparameter").text('');
			jQuery("#errorelapseTime").text('');
			
			}	
			
		}
		
	
	function getScatterChartForGraph2(flightId,minelapseTime,maxelapseTime,textTitle){
				$("#loadingChart2").show();
			var predixurl="https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/view/getFlightPlottingDataElapsedTime";
				$.ajax({
				url:predixurl+"/"+flightId+"/"+minelapseTime+"/"+maxelapseTime,
                type: "get", 
                success: function(responseData) {
				//console.log("Chart Data"+JSON.stringify(responseData)); 
				graphData2=responseData;
				//alert(graphData2);
				$("#loadingChart2").hide();
				$("#yaxisDataGraph2").show();
				$("#yaxisdivGraph2").show();
				$("#yaxisdatavalForGraph2").show();
				
				
				},
                error: function ( xhr, status, error) {
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				$("#loadingChart2").hide();
		
				}
				});
	
	}
	
function scatterchartForGraph2(scatterArrayGraph1,xaxisid,yaxisid,textTitle){
Highcharts.chart('container4', {
chart: {
type: 'scatter',
zoomType: 'xy'
},
title: {
	text: textTitle
},
xAxis: {
title: {
enabled: true,
text: xaxisid
},
labels:{

},
startOnTick: true,
endOnTick: true,
showLastLabel: true
},
yAxis: {
title: {
text: yaxisid
}
},
series: [
{
name: textTitle,
//color: 'rgba(223, 83, 83, .5)',
data: scatterArrayGraph1
}
]});			
 }
 
 
 
 function getYaxisDataForMultiple(flightIdVal){

				var predixurl="https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/view/getFlightPlottingData";
				$.ajax({
				url:predixurl+"/"+flightIdVal,
			
 
                type: "get", //send it through post method
 
                success: function(responseData) {
				testDataMultiple=responseData;
				$("#loadingChart3").hide();
				$("#xaxisIdMulti").show();
				$("#xaxisdatavalMulti").show();
				$("#yaxisIdMulti").show();
				$("#yaxisdatavalMulti").show();
				},
 
                error: function ( xhr, status, error) {
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				$("#loadingChart").hide();
		
				}
				});
				
	}
	
	function setMultipleLineChart(chartCategories11,multipleYaxisArrya){
		$("#container3").show();
		Highcharts.chart('container3', {
		chart: {
			zoomType: 'xy'
			},
			title: {
			text: 'Elapse Time Vs Multiple Parameter'
		},
   xAxis: {
		title: {
		enabled: true,
		text: 'Elapsed Time'
		},
		labels: {
		format: '{value} sec'
		}
	},
	yAxis: [{ 
        labels: {
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        },
        title: {
          
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        },
        opposite: false

    }, { 
        title: {
           text: '',
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        },
        labels: {
           
            style: {
                color: Highcharts.getOptions().colors[0]
            }
        }

    }, {
        title: {
           text: '',
            style: {
                color: Highcharts.getOptions().colors[1]
            }
        },
        labels: {
         
            style: {
                color: Highcharts.getOptions().colors[1]
            }
			
        },
        opposite: true
    }],
    tooltip: {
        shared: true
    },
    legend: {
        layout: 'vertical',
        align: 'left',
        x: 80,
        verticalAlign: 'top',
        y: 55,
        floating: true,
        backgroundColor: (Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'
    },
    series: multipleYaxisArrya
	});
	}  
	
	function getYaxisDataForMultiLineGraph(flightIdVal){
	
				var predixurl="https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/view/getFlightPlottingData";
				$.ajax({
				url:predixurl+"/"+flightIdVal,
                type: "get", //send it through post method
                success: function(responseData) {
				testDataMultipleLineGraph=responseData;
				$("#loadingChart4").hide();
				$("#xaxisIdMultiLine").show();
				$("#yaxisIdMultiLine").show();
				$("#xaxisdatavalMultiLine").show();
				$("#yaxisdatavalMultiLine").show();
				$("#showchartIdForMultiLine").show();		
				$("#container5").hide();
				},
                error: function ( xhr, status, error) {
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				$("#loadingChart4").hide();
				}
				});
				
	}
	
	
	function formMultipleChart(chartCategories11,multipleYaxisArrya,chartTitlesArray){
		$("#container5").show();
			$.each(multipleYaxisArrya, function (i, dataset) { 
					var chartTitle = chartTitlesArray[i];
					$('<div class="chart">').appendTo('#container5').highcharts({
						chart: {
							marginLeft: 40, 
							spacingTop: 20,
							spacingBottom: 20,
							type: 'line',
							zoomType: 'xy'
						},
						title: {
							text: chartTitle,
							align: 'left',
							margin: 0,
							x: 30
						},
						credits: {
							enabled: false
						},
						legend: {
							enabled: false
						},
						xAxis: {
							crosshair: true,
							events: {
								setExtremes: syncExtremes
							},
							title: {
								enabled: true,
								text: 'Elapsed Time'
							},
							labels: {
								format: '{value} sec'
							}
						},
						yAxis: {
							title: {
								text: null
							}
						},
						series: [{
							data: dataset,
							name: chartTitle,
							color: Highcharts.getOptions().colors[i],
							fillOpacity: 0.3
						}]
					});
					
					
				});
	}
	
	function syncExtremes(e) {
			 var thisChart = this.chart;         
			 if (e.trigger !== 'syncExtremes') { // Prevent feedback loop
				 Highcharts.each(Highcharts.charts, function (chart) {
					 if (chart !== undefined && chart !== thisChart) {
						 if (chart.xAxis[0].setExtremes) { // It is null while updating
							chart.xAxis[0].setExtremes(e.min, e.max, undefined, false, { trigger: 'syncExtremes' });
						 }
					 }
				 });
			 }

         }    

function loadDynamicflightId(){
	var predixurl="https://predix-aircraft-demo3.run.aws-usw02-pr.ice.predix.io/getFlightIds";
				$.ajax({
				url:predixurl,
                type: "get", //send it through post method
                success: function(responseData) {
				dynamicFlightId=responseData;
				$("#loadingChart5").hide();
				$('#flightId').find('option:not(:first)').remove();
			for (var i = 0; i < dynamicFlightId.length; i++) {
					$('#flightId').append($('<option>', { 
						value: JSON.stringify(dynamicFlightId[i].flightId),
						text : JSON.stringify(dynamicFlightId[i].flightId)
				}));
           }
				},
                error: function ( xhr, status, error) {
				$("#loadingChart5").hide();
				console.log( " xhr.responseText: " + xhr.responseText + " //status: " + status + " //Error: "+error );
				}
				});



}		 