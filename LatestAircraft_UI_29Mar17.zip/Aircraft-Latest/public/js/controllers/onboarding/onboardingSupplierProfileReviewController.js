app.controller('onboardingSupplierProfileReviewController', function ($scope, $filter, $http, $rootScope, constants,
        $state, Auth, $timeout, toaster, $cookies, $cookieStore, WorkFlow, supplier) {

    $rootScope.supplierProfileReviewDone = true;
    $scope.loader = false;
    var WfModel = {};
    $scope.supplier = {};

    if (!WorkFlow.getRequestId()) {
        toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
        //$state.go('supplierHome');
        return;
    }
    var RequestId = WorkFlow.getRequestId();
    console.log("RequestId:" + RequestId);
//    $http.get("/app/js/controllers/onboarding/testReview.json").then(function(workflowData){
//       console.log("R:",workflowData.data);
//       $scope.companyAccounts = workflowData.data.companyInformation;
//       $scope.bankAccounts = workflowData.data.bankInformation;
//       $scope.contacts = workflowData.data.contactInformation;
//       $scope.certifications = workflowData.data.certifications;
//       $scope.complaince = workflowData.data.complianceInformation;
//    });
    $scope.loader = true;
//    $http.get(constants.SUPPLIER_REVIEW_REQUEST + RequestId).then(function (workflowData) {
    WorkFlow.getNewSupplierReview(RequestId).then(function (workflowData) {
        $scope.loader = false;
        $scope.companyAccounts = workflowData.companyInformation;
        $scope.bankAccounts = workflowData.bankInformation;
        $scope.contacts = workflowData.contactInformation;
        $scope.certifications = workflowData.certifications;
        $scope.complaince = workflowData.complianceInformation;
        var temp = workflowData.addressInformation;//{"LEGAL":["person:meage:30"],"TEST":["person:youage:25"]};
        var arr = [];
        for(var key in temp) {
            var obj = {};
            obj.key = key;
            obj.value = temp[key];
            arr.push(obj);
            console.log(arr);
        }
        $scope.addressInformation = arr;
    }, function (error) {
        $scope.loader = false;  
        console.log("error::",error);
        toaster.pop('error', "Review API", "Review API not working");
        return;
    });

    /*New versions*/
//    WorkFlow.getVariablesV2().then(function(workflowData) {
//
//        WfModel = workflowData.data;
////        $scope.bankAccounts = (WfModel.supplier.banks) ? (WfModel.supplier.banks) : null;
////        $scope.companyAccounts = WfModel.supplier;
////        $scope.contacts=WfModel.supplier.contacts;
//        $scope.dueDiligence = (WfModel.dueDiligence) ? (WfModel.dueDiligence) : {};
////        $scope.certifications = (WfModel.supplier.certifications) ? (WfModel.supplier.certifications) : {};
//        $scope.diversities = (WfModel.supplier.diversity) ? (WfModel.supplier.diversity) : {};
//
//        $scope.addresses = {};
//        var addresses = (WfModel.supplier.addresses) ? (WfModel.supplier.addresses) : null;
//        angular.forEach(addresses, function(address, index) {
//            if (address.addressTypes.indexOf("LEGAL") != -1) {
//                if (!$scope.addresses.legalentity) {
//                    $scope.addresses.legalentity = [];
//                }
//                $scope.addresses.legalentity.push(address.location);
//            }
//            if (address.addressTypes.indexOf("ORDER_FULLFILLING") != -1) {
//                if (!$scope.addresses.orderFulfilmentAddress) {
//                    $scope.addresses.orderFulfilmentAddress = [];
//                }
//                $scope.addresses.orderFulfilmentAddress.push(address.location);
//            }
//            if (address.addressTypes.indexOf("MANUFACTURING") != -1) {
//                if (!$scope.addresses.manufacturingAddress) {
//                    $scope.addresses.manufacturingAddress = [];
//                }
//                $scope.addresses.manufacturingAddress.push(address.location);
//            }
//			if (address.addressTypes.indexOf("SHIP_FROM_ALT") != -1) {
//                if (!$scope.addresses.alternateShip) {
//                    $scope.addresses.alternateShip = [];
//                }
//                $scope.addresses.alternateShip.push(address.location);
//            }
//        });
//
//        if($scope.dueDiligence){
//            $scope.ndaDocumentId= $scope.dueDiligence.ndaDocumentId;
//            var getId=document.getElementById('downloadUrlForFile_ndaDocument');
//            getId.href= constants.FILE_DOWNLOAD+ $scope.dueDiligence.ndaDocumentId;
//            supplier.getlistFileUploaded($scope.ndaDocumentId).then(function(data) {
//                $scope.fileNameNdaDocument=data.FileName;
//            }, function(data) {});
//        }
//
//        if($scope.certifications){
//            // angular.forEach($scope.certifications, function(value, key){
//            //     $scope.certificationData = value;
//            // })
//        }
//        if($scope.diversities){
//            // angular.forEach($scope.diversities, function(value, key){
//            //     $scope.diversitiesCertData = value;
//            // })
//        }
//        // supplier.diversityRules(WfModel.requestId).then(function(data) {
//        //     $scope.diversities = data;
//        //     angular.forEach($scope.diversities.data, function(value1, key1) {
//        //         angular.forEach(WfModel.supplier.diversities, function(value2, key2) {
//        //             if (value1.id == value2.id) {
//        //                 value2.label = value1.diversity;
//        //             }
//        //         });
//        //     });
//        //     $scope.supplierInfoDiversity = WfModel.supplier.diversities;
//
//        // }, function(data) {});
//    });

    $scope.maskNumber = function (number) {
        number = (number) ? number + "" : "";
        return number.replace(/\d(?=\d{4})/g, "*");
    }

    $scope.goToSection = function (page) {
        console.log(page);
        if (page === "contacts") {
            $state.go('supplierProfileContacts');
        } else if (page === "addresses") {
            $state.go('supplierProfileAddress');
        }
    }

    //return;

    // Need to remove below section once we are done with new version of code
    /**************/


    $scope.reviewSubmit = function () {
        $scope.loader = true;
        WorkFlow.completeWorkflowV2().then(function (data) {
            $scope.completed = data.completed;
            if ($scope.completed === false) {
                toaster.pop('error', data.fault[0]);
                $state.go('supplierReview');
                $scope.loader = false;
                return;
            } else {
                $scope.loader = false;
                toaster.pop('success', "WorkFlow Completed successfully");
                $state.go('supplierCongrats');
            }
        }, function (data) {
            $scope.loader = false;
            toaster.pop('error', "WorkFlow Complete call failed");

        });
    }




    //		if(WorkFlow.getInstance()) {
    /*WorkFlow.getVariablesV2().then(function(workflowData) {
     
     WfModel = workflowData.data;
     $scope.bankAccounts=WfModel.supplier.banks;
     if(workflowData.data){
     WfModel.supplier = (WfModel.supplier==null)?{}:WfModel.supplier;
     $scope.supplierNumber = WfModel.supplier.registrationId;
     $scope.supplierInfoAddress=WfModel.supplier.addresses;
     $scope.contacts=WfModel.supplier.contacts;
     $scope.companyAccounts=WfModel.supplier;
     //$scope.bankAccounts=WfModel.supplier.bankAccounts;
     debugger;
     $scope.supplier.isCertification = supplier.getDiligence(WfModel.dueDiligences, 'isCertification');
     $scope.supplier.certificationName = supplier.getDiligence(WfModel.dueDiligences, 'certificationName');
     $scope.supplier.certificationNumber = supplier.getDiligence(WfModel.dueDiligences, 'certificationNumber');
     $scope.supplier.is3tg = supplier.getDiligence(WfModel.dueDiligences, 'is3tg');
     $scope.supplier.Email3tg = supplier.getDiligence(WfModel.dueDiligences, 'Email3tg');
     $scope.supplier.isBroker = supplier.getDiligence(WfModel.dueDiligences, 'isBroker');
     $scope.supplier.brokerCountries = supplier.getDiligence(WfModel.dueDiligences, 'brokerCountries');
     
     supplier.diversityRules(WfModel.supplier.countryId).then(function(data) {
     $scope.diversities = data;
     //if(workflowData.data){
     angular.forEach($scope.diversities.data, function(value1, key1) {
     angular.forEach(WfModel.supplier.diversities, function(value2, key2) {
     //debugger;
     if(value1.id==value2.id) {
     value2.label = value1.diversity;
     }
     });
     });
     $scope.supplierInfoDiversity = WfModel.supplier.diversities;
     //}
     
     }, function(data) {
     });
     
     
     
     
     }
     }); */


});
